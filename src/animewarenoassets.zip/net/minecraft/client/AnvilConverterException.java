package net.minecraft.client;

public class AnvilConverterException extends Exception
{
    public AnvilConverterException(String exceptionMessage)
    {
        super(exceptionMessage);
    }
}
