
/*
 * This client was created by Hypnomacka partly using QickDaffys code and code from his discord server(snippets channel)
 */

package animeware;

import java.io.File;

import org.lwjgl.LWJGLException;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;

import animeware.cosmetic.CapeManager;
import animeware.cosmetic.CosmeticController;
import animeware.cosmetic.CosmeticManager;
import animeware.cosmetic.impl.Cape;
import animeware.event.EventManager;
import animeware.event.EventTarget;
import animeware.event.impl.ClientTick;
import animeware.event.impl.EventUpdate;
import animeware.gui.alt.AltManager;
import animeware.hud.mod.Freelook;
import animeware.hud.mod.HudManager;
import animeware.login.Users;
import animeware.mods.ModManager;
import animeware.ui.ClickGUI;
import animeware.ui.notifications.Notification;
import animeware.util.backend.AntiCheat;
import animeware.util.config.Config;
import animeware.util.config.test.Configuration;
import animeware.util.config.test.ConfigurationAPI;
import animeware.util.font.FontUtil;
import animeware.util.misc.WebhookUtil;
import animeware.util.websockets.SocketClient;
import animeware.util.websockets.user.CheckName;
import net.minecraft.client.Minecraft;

public class Animeware {
	
	//public static boolean SwordAnim = false;
	public String NAME = "NightSky", VERSION = "(b-4.0-BfNm-f/master)", AUTHOR = "hypnomacka", NAMEVER = NAME + " " + VERSION;
	public static Animeware INSTANCE = new Animeware();
	public Minecraft mc = Minecraft.getMinecraft();
	String mcname = Minecraft.getMinecraft().getSession().getUsername();
	private DiscordRP discordRP = new DiscordRP();
	public Configuration config1, configSaving = ConfigurationAPI.newConfiguration(new File("/test.aw"));
	
	public static boolean evening;
	public static boolean morning;
	
	public static boolean Cape1;
	public static boolean Cape;
	public static boolean PlanetsCape;
	public static boolean QuavCape;
	public static boolean ReptyllCape;
	public static boolean SwordCape;
	public static boolean EmeraldCape;
	public static boolean LCape;
	public static boolean NitroCape;
	public static boolean DarkCape;
	public static boolean CosmeticEasterEggs;
	public static boolean Susanoo;
	public static boolean CosmeticWitchHat;
	public static boolean SkinChanger;
	public static boolean CrystalWings;
	
	public static boolean GradientBlack;
	public static boolean GradientBlue;
	public static boolean GradientGreen;
	public static boolean GradientPurple;
	public static boolean GradientRed;
	public static boolean tanjirocape;
	public static boolean kocho2cape;
	public static boolean kocho3cape;
	public static boolean dseyes2cape;
	public static boolean dseyescape;
	public static boolean wintercape;
	
	public static boolean glasses;
	public static boolean retardEyes;
	
	public static boolean DevCape;
	public static boolean QuickCape;
	public static boolean OwnerCape;	
	public static boolean YTCape;
	
	public static boolean CosmeticWings;	
	public static boolean GalaxyWings;	
	public static boolean Halo;	
	public static boolean TopHat;
	
	public static boolean ModArmorStatus;
	public static boolean SwordAnim;
	public static boolean Hitbox;
	public static boolean ModBossbar;
	public static boolean TNTTimer;
	public static boolean ScrollZoom;
	public static boolean BlockOverlay;
	public static boolean ToggleSprint;
	public static boolean FPSMod;
	public static boolean BlockOverlayPurple;
	public static boolean BlockOverlayRed;
	public static boolean BlockOverlayWhite;
	public static boolean BlockOverlayBlue;
	public static boolean BlockOverlayCyan;
	public static boolean BlockOverlayChroma;
	public static boolean random;
	public static boolean direction;
	public static boolean DynamicFOV;
	public static boolean blur;
	public static boolean itemphys;
	public static boolean MoreParticles;
	public static boolean SmallSword;
	public static boolean SwordSpin;
	public static boolean ban;
	public static boolean watermark;
	public static boolean night;	
	public static boolean day;
	
	public static boolean timechanger;
	public static boolean freelook;
	public static boolean notification;
	public static boolean nickhider;
	public static boolean Winter;
	public static boolean HitColor;
	public static boolean HitColorRed;
	public static boolean HitColorBlue;
	public static boolean HitColorCyan;
	public static boolean HitColorPurple;
	public static boolean HitColorChroma;
	
	private int previousF5 = 0;
	
	public EventManager eventManager;
	public Config config;
	public ModManager modManager;
	public HudManager hudManager; 
	public AltManager altManager;
	public Users users;
	public CosmeticController cosmeticController;
	public Cape cape;
	public CapeManager capeManager;
	public Notification notif;
	public CosmeticManager cosManager;
	//public static NetworkClient networkClient;
	//public ParticleEngine particleEngine;
	public static boolean hasSent = false;
	
	public float cameraYaw = 0f;
	public float cameraPitch = 0f;
	
	public static String encryptionString = "austinsexyforehead9VsTDGMOvDsEOByAZn9b6XFTE1hrPRUTDqQyy0NSCgbF2UVAKBTMCboHfUIOagja5FI3r5edsS9ek9dw";
	
	public void startup() throws LWJGLException {
		eventManager = new EventManager();
		config = new Config();
		config1 = new Configuration(null);
		modManager = new ModManager();
		hudManager = new HudManager(null);
		altManager = new AltManager();
		users = new Users();
		cosmeticController = new CosmeticController();
		cape = new Cape(null);
		capeManager = new CapeManager();
		cosManager = new CosmeticManager();
		if(mc.gameSettings.FREELOOK.isPressed()) {
		//notif = new Notification(NotificationType.INFO, "Test", "Test", 200);
		//notif.render();
		//notif.show();
		}
		//AntiCheat.checkVape();

		if(this.Hitbox) {
			mc.getRenderManager().setDebugBoundingBox(true);
		} else {
			mc.getRenderManager().setDebugBoundingBox(false);
		}
		
		//if(AntiCheat.getHWID().equals("")) {
			//this.ban = true;
		//}
		
		if(AntiCheat.checkVape() == true) {
			this.ban = true;
			if(this.ban == true) {
				WebhookUtil.sendFlag(DiscordRP.getDiscordName(null) + " - " + (Minecraft.getMinecraft().getSession().getUsername()) + " was banned");
			}
		}
		//networkClient = new NetworkClient("127.0.0.1", 7331);	
		
		SocketClient.sendRequest(mcname + " just booted up " + NAMEVER);
		
		
		//networkClient.addClient
		
		/*try {
            networkClient.connect();
            //System.out.println("idk");
        } catch (Exception exception) {
            exception.printStackTrace();
        }*/
		//System.out.println(networkClient.host.toString());
		System.out.println();
		//networkClient.onUpdate(null);
		
	     /*if(AntiCheat.checkSigma() == true) {
			Animeware.ban = true;
			WebhookUtil.sendFlag(DiscordRP.getDiscordName(null) + " - " + (Minecraft.getMinecraft().getSession().getUsername()) + " has: Sigma");
			System.out.println(DiscordRP.getDiscordName(null) + " - " + (Minecraft.getMinecraft().getSession().getUsername()) + " has: Sigma");
		}
        if(AntiCheat.checkZeroDay() == true) {
			Animeware.ban = true;
			WebhookUtil.sendFlag(DiscordRP.getDiscordName(null) + " - " + (Minecraft.getMinecraft().getSession().getUsername()) + " has: ZeroDay");
			System.out.println(DiscordRP.getDiscordName(null) + " - " + (Minecraft.getMinecraft().getSession().getUsername()) + " has: ZeroDay");
		}
        if(AntiCheat.checkImpact() == true) {
			Animeware.ban = true;
			WebhookUtil.sendFlag(DiscordRP.getDiscordName(null) + " - " + (Minecraft.getMinecraft().getSession().getUsername()) + " has: Impact");
			System.out.println(DiscordRP.getDiscordName(null) + " - " + (Minecraft.getMinecraft().getSession().getUsername()) + " has: Impact");
		}*/
		//AntiCheat.doAnticheat();
		//HackDelete.removeCheats();
		
		//System.out.println(HWID.getHWID());
		
		/*MicrosoftAuthenticator authenticator = new MicrosoftAuthenticator();
        MicrosoftAuthResult result = null;
        try {
            result = authenticator.loginWithWebview();
            System.out.printf("Logged in with '%s'%n", result.getProfile().getName());
            Minecraft.getMinecraft().session = new Session(result.getProfile().getName(),result.getProfile().getId(), result.getAccessToken(),"legacy");
 
 
 
        } catch (MicrosoftAuthenticationException e) {
            e.printStackTrace();
        }*/
		
		//SocketClient.sendRequest("LE TESTO");
		
		/*if(mc.isFullScreen()) {
			System.setProperty("org.lwjgl.opengl.Window.undecorated", "true");
			
			Display.setDisplayMode(Display.getDesktopDisplayMode());
			Display.setLocation(0, 0);
			Display.setFullscreen(false);
			Display.setResizable(false);
		} else {
			System.setProperty("org.lwjgl.opengl.Window.undecorated", "false");
			Display.setDisplayMode(new DisplayMode(mc.displayWidth, mc.displayHeight));
			Display.setResizable(true);
		}*/
		//Animeware.Susanoo = true;
				
		Animeware.INSTANCE.getDiscordRP().update("Starting...", "Animeware " + VERSION);
		
		discordRP.start();
		
		System.out.println("Starting... " + NAMEVER + " by " + AUTHOR);
		
		//System.out.println();
		
		//config.loadModConfig();
		
		
		
		Display.setTitle(NAMEVER);
		
		FontUtil.bootstrap();
		
	    
		
		eventManager.register(this);
		

	}
	
	
	
	public void shutdown() {
		System.out.println("Shutting down " + NAMEVER);
		
		//CheckName.DoShutDownCheck();
		//config1.saveConfig();
		
		discordRP.shutdown();
		//config.saveModConfig();
		/*try {
            networkClient.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
        }*/
        eventManager.unregister(this);
	}
	
	public float getCameraYaw()
	{
		return Freelook.freelooking ? cameraYaw : mc.thePlayer.rotationYaw;
	}

	public float getCameraPitch()
	{
		return Freelook.freelooking ? cameraPitch : mc.thePlayer.rotationPitch;
	}
	public boolean overrideMouse()
	{
		if (mc.inGameHasFocus && Display.isActive())
		{
			if (!Freelook.freelooking)
			{
				return true;
			}

			// CODE
			mc.mouseHelper.mouseXYChange();
			float f1 = mc.gameSettings.mouseSensitivity * 0.6F + 0.2F;
			float f2 = f1 * f1 * f1 * 8.0F;
			float f3 = (float) mc.mouseHelper.deltaX * f2;
			float f4 = (float) mc.mouseHelper.deltaY * f2;

			cameraYaw += f3 * 0.15F;
			cameraPitch += f4 * 0.15F;

			if (cameraPitch > 90) cameraPitch = 90;
			if (cameraPitch < -90) cameraPitch = -90;
		}

		return false;
	}
	
	@EventTarget
	public void onTick(ClientTick event) {
		//String address = "Ip";
		//address = Minecraft.getMinecraft().getCurrentServerData().serverIP;
		
		
		if(mc.gameSettings.CLICK_GUI.isPressed()) {
			//mc.displayGuiScreen(new ClickGUI());
			mc.displayGuiScreen(new ClickGUI());
		}
		if(mc.gameSettings.FREELOOK.isKeyDown() && freelook == true) {
			
			Freelook.freelooking = true;
			//Freelook.freelooking = !Freelook.freelooking;
			//mc.gameSettings.thirdPersonView = 1;
			//cameraYaw = mc.thePlayer.rotationYaw;
			//cameraPitch = mc.thePlayer.rotationPitch;
			if(Freelook.freelooking) {
				//previousF5 = mc.gameSettings.thirdPersonView;
				mc.gameSettings.thirdPersonView = 1;
				//mc.thePlayer.rotationYaw = 180F;
				//mc.thePlayer.rotationPitch = 180F;
				//HudManager.getFreelook().getCameraYaw();
				//HudManager.getFreelook().getCameraPitch();
			
		} else if(!mc.gameSettings.FREELOOK.isKeyDown()) {
			Freelook.freelooking = false;
			mc.gameSettings.thirdPersonView = 0;
			mc.gameSettings.thirdPersonView = previousF5;
		}
			
	}
		if (Keyboard.getEventKey() == mc.gameSettings.keyBindTogglePerspective.getKeyCode())
		{
			Freelook.freelooking = false;
		}
		//if(mc.gameSettings.FREELOOK.isPressed()) {
			//mc.displayGuiScreen(new ClickGUI());
			//mc.displayGuiScreen(new ClickGUI());
		//}
		/*if(mc.gameSettings.COSMETIC_GUI.isPressed()) {
			//mc.displayGuiScreen(new ClickGUI());
			mc.displayGuiScreen(new CosmeticGui());
		}*/
	}
	public static final Animeware getInstance() {
		return INSTANCE;
	}
	public Users getUsers() {
		return users;
	}
	public void setUsers(Users users) {
		this.users = users;
	}
	public DiscordRP getDiscordRP() {
		return discordRP;
	}
	
	@EventTarget
	private void onUpdate(EventUpdate e) {
		
		if(mc.theWorld != null && mc.theWorld !=null) {
			if(!this.hasSent) {
				/*System.out.println(SocketClient.client.request("start_animeware", mc.thePlayer.getGameProfile().getName() + ":true"));
				System.out.println(SocketClient.client.request("start_animeware", mc.thePlayer.getGameProfile().getName() + ":isowner"));
				System.out.println(SocketClient.client.request("start_animeware", mc.thePlayer.getGameProfile().getName() + ":isdev"));
				System.out.println(SocketClient.client.request("start_animeware", mc.thePlayer.getGameProfile().getName() + ":ispurple"));*/
				CheckName.DoCheckName();
				this.hasSent = true;
				
				//if(QuickCape == true) {
					//System.out.println(SocketClient.client.request("start_animeware_cape1", mc.thePlayer.getGameProfile().getName() + ":owns1"));
					//System.out.println(SocketClient.client.request("start_animeware_cape2", mc.thePlayer.getGameProfile().getName() + ":owns2"));
				//}
				/*if(PlanetsCape == true) {
					//System.out.println(SocketClient.client.request("start_animeware_cape1", mc.thePlayer.getGameProfile().getName() + ":owns1"));
					System.out.println(SocketClient.client.request("start_animeware_cape2", mc.thePlayer.getGameProfile().getName() + ":owns2"));
				}*/
				//System.out.println(SocketClient.client.request("start_animeware_cape1", mc.thePlayer.getGameProfile().getName() + ":owns1"));
				//System.out.println(SocketClient.client.request("start_animeware_cape2", mc.thePlayer.getGameProfile().getName() + ":owns2"));
				/*System.out.println(SocketClient.client.request("isWearingCape3", mc.thePlayer.getGameProfile().getName() + ":owns"));
				System.out.println(SocketClient.client.request("isWearingCape4", mc.thePlayer.getGameProfile().getName() + ":owns"));
				System.out.println(SocketClient.client.request("isWearingCape5", mc.thePlayer.getGameProfile().getName() + ":owns"));
				System.out.println(SocketClient.client.request("isWearingCape6", mc.thePlayer.getGameProfile().getName() + ":owns"));
				System.out.println(SocketClient.client.request("isWearingCape7", mc.thePlayer.getGameProfile().getName() + ":owns"));
				System.out.println(SocketClient.client.request("isWearingCape8", mc.thePlayer.getGameProfile().getName() + ":owns"));
				System.out.println(SocketClient.client.request("isWearingCape9", mc.thePlayer.getGameProfile().getName() + ":owns"));
				System.out.println(SocketClient.client.request("isWearingCape10", mc.thePlayer.getGameProfile().getName() + ":owns"));
				System.out.println(SocketClient.client.request("isWearingCape11", mc.thePlayer.getGameProfile().getName() + ":owns"));
				System.out.println(SocketClient.client.request("isWearingCape12", mc.thePlayer.getGameProfile().getName() + ":owns"));
				System.out.println(SocketClient.client.request("isWearingCape13", mc.thePlayer.getGameProfile().getName() + ":owns"));
				System.out.println(SocketClient.client.request("isWearingCape14", mc.thePlayer.getGameProfile().getName() + ":owns"));
				System.out.println(SocketClient.client.request("isWearingCape15", mc.thePlayer.getGameProfile().getName() + ":owns"));
				System.out.println(SocketClient.client.request("isWearingCape16", mc.thePlayer.getGameProfile().getName() + ":owns"));
				System.out.println(SocketClient.client.request("isWearingCape17", mc.thePlayer.getGameProfile().getName() + ":owns"));
				System.out.println(SocketClient.client.request("isWearingCape18", mc.thePlayer.getGameProfile().getName() + ":owns"));
				System.out.println(SocketClient.client.request("isWearingCape19", mc.thePlayer.getGameProfile().getName() + ":owns"));
				System.out.println(SocketClient.client.request("isWearingCape20", mc.thePlayer.getGameProfile().getName() + ":owns"));
				System.out.println(SocketClient.client.request("isWearingCape20", mc.thePlayer.getGameProfile().getName() + ":owns"));
				System.out.println(SocketClient.client.request("isWearingCape21", mc.thePlayer.getGameProfile().getName() + ":owns"));
				System.out.println(SocketClient.client.request("isWearingCape22", mc.thePlayer.getGameProfile().getName() + ":owns"));
				System.out.println(SocketClient.client.request("isWearingCape23", mc.thePlayer.getGameProfile().getName() + ":owns"));
				System.out.println(SocketClient.client.request("isWearingCape24", mc.thePlayer.getGameProfile().getName() + ":owns"));*/
				
				
			}
		}

	}

}
