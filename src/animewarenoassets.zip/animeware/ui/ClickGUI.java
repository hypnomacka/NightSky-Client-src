package animeware.ui;

import java.awt.Color;
import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;

import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import animeware.Animeware;
import animeware.hud.HUDConfigScreen;
import animeware.hud.mod.HudManager;
import animeware.hud.mod.HudMod;
import animeware.ui.comp.Changelog;
import animeware.ui.comp.CosmeticButton;
import animeware.ui.comp.CosmeticsCGButton;
import animeware.ui.comp.HomeCGButton;
import animeware.ui.comp.LogoButtonWhite;
import animeware.ui.comp.ModButton;
import animeware.ui.comp.ServersCGButton;
import animeware.ui.comp.SettingsCGButton;
import animeware.ui.comp.ToggleableCGButton;
import animeware.ui.comp.setting.BooleanSetting;
import animeware.ui.comp.setting.ModeSetting;
import animeware.ui.comp.setting.NumberSetting;
import animeware.ui.comp.setting.Setting;
import animeware.ui.particle.ParticleEngine;
import animeware.ui.profile.ProfileCGui;
import animeware.util.render.ColorMode;
import animeware.util.render.RenderUtil;
import animeware.util.render.RoundedUtils;
import net.arikia.dev.drpc.DiscordUser;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.server.MinecraftServer;

public class ClickGUI extends GuiScreen {
	
	public static boolean CosmeticGUI;
	public static boolean ProfileGUI;
	public static boolean ClickGUI;
	//public boolean ServersGUI;
	
	public boolean isCGOn = false;
	public boolean cgon;
	
	private int field_146445_a;
    private int field_146444_f;
    
    float anim = 0.0F;
    
    private float currentScroll;
    //private final int x = 10, y = 10, width = 100, height = 300;

    
    //int y = 0;
    
    HudMod m;
    
    //int NameWidth = mc.fontRendererObj.getStringWidth(m.name);
	 
	private static String TntTime = "TntTimer";
	
	ArrayList<CosmeticButton> cosButtons = new ArrayList<>();
	ArrayList<ModButton> modButtons = new ArrayList<>();
	//ArrayList<ModButtonBlue> bluemodButtons = new ArrayList<>();
	//ArrayList<ModButton1> modButtons1 = new ArrayList<>();
	//ArrayList<ButtonList> buttonList = new ArrayList<>();
	//protected List<GuiButton> buttonList = Lists.<GuiButton>newArrayList();
	//ArrayList<ClassicButton> classicButtons = new ArrayList<>();
	
	public void checkMouseWheel(int mouseX, int mouseY) {
    	int mouseScroll = Mouse.getDWheel();
    	if(mouseScroll > 0) {
    		for(ModButton b : modButtons) {
    			b.y += 15;
    		}
    	} else if(mouseScroll < 0) {
    		for(ModButton b : modButtons) {
    			b.y -= 15;
    		}
    	}
    }
	public void checkMouseWheelCosmetic(int mouseX, int mouseY) {
    	int mouseScrollCos = Mouse.getDWheel();
    	if(mouseScrollCos > 0) {
    		for(CosmeticButton b : cosButtons) {
    			b.y += 15;
    		}
    	} else if(mouseScrollCos < 0) {
    		for(CosmeticButton b : cosButtons) {
    			b.y -= 15;
    		}
    	}
    }
	
	@Override
	public void initGui() {
		
		this.anim = 80.0F;
		super.initGui();
		//Minecraft.getMinecraft().entityRenderer.loadShader(new ResourceLocation("shaders/post/blur.json"));
		/*if(!GameSettings.ofFastRender) {
			GameSettings.ofFastRender = !GameSettings.ofFastRender;
		}*/
		this.field_146445_a = 0;
        this.buttonList.clear();
        int i = -16;
        int j = 98;
		//mc.entityRenderer.loadShader(new ResourceLocation("shaders/post/hyperium_blur.json"));
		
        //if(CosmeticGUI == true) {
        	/*this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 165, 225, 35, Animeware.INSTANCE.cosManager.darkCape));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 205, 225, 35, Animeware.INSTANCE.cosManager.deamoneyes));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 245, 225, 35, Animeware.INSTANCE.cosManager.deamoneyes2));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 285, 225, 35, Animeware.INSTANCE.cosManager.ecape));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 325, 225, 35, Animeware.INSTANCE.cosManager.gblack));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 365, 225, 35, Animeware.INSTANCE.cosManager.gblue));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 405, 225, 35, Animeware.INSTANCE.cosManager.ggreen));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 445, 225, 35, Animeware.INSTANCE.cosManager.gpurple));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 485, 225, 35, Animeware.INSTANCE.cosManager.gred));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 525, 225, 35, Animeware.INSTANCE.cosManager.kcape));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 565, 225, 35, Animeware.INSTANCE.cosManager.kcape2));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 605, 225, 35, Animeware.INSTANCE.cosManager.lcape));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 645, 225, 35, Animeware.INSTANCE.cosManager.ncape));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 685, 225, 35, Animeware.INSTANCE.cosManager.pcape));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 725, 225, 35, Animeware.INSTANCE.cosManager.quavcape));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 765, 225, 35, Animeware.INSTANCE.cosManager.quickcape));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 805, 225, 35, Animeware.INSTANCE.cosManager.rcape));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 845, 225, 35, Animeware.INSTANCE.cosManager.scape));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 885, 225, 35, Animeware.INSTANCE.cosManager.tcape));*/
    		/*this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 925, 225, 35, Animeware.INSTANCE.cosManager.reachDisp));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 965, 225, 35, Animeware.INSTANCE.cosManager.particles));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 1005, 225, 35, Animeware.INSTANCE.cosManager.mldg));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 1045, 225, 35, Animeware.INSTANCE.cosManager.head));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 1085, 225, 35, Animeware.INSTANCE.cosManager.bo));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 1125, 225, 35, Animeware.INSTANCE.cosManager.tnt));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 1165, 225, 35, Animeware.INSTANCE.cosManager.iphys));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 1205, 225, 35, Animeware.INSTANCE.cosManager.smallsword));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 1245, 225, 35, Animeware.INSTANCE.cosManager.swordspin));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 1285, 225, 35, Animeware.INSTANCE.cosManager.mp));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 1325, 225, 35, Animeware.INSTANCE.cosManager.sz));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 1365, 225, 35, Animeware.INSTANCE.cosManager.watermark));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 1405, 225, 35, Animeware.INSTANCE.cosManager.arrows));
    		this.cosButtons.add(new CosmeticButton(this.width/ 2 - 143, 1445, 225, 35, Animeware.INSTANCE.cosManager.lilplayer));*/
        //} else {
        	this.modButtons.add(new ModButton(this.width/ 2 - 143, 165, 225, 35, Animeware.INSTANCE.hudManager.thud));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 205, 225, 35, Animeware.INSTANCE.hudManager.fps));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 245, 225, 35, Animeware.INSTANCE.hudManager.bps));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 285, 225, 35, Animeware.INSTANCE.hudManager.cps));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 325, 225, 35, Animeware.INSTANCE.hudManager.keystrokes));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 365, 225, 35, Animeware.INSTANCE.hudManager.potionStat));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 405, 225, 35, Animeware.INSTANCE.hudManager.sip));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 445, 225, 35, Animeware.INSTANCE.hudManager.xyz));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 485, 225, 35, Animeware.INSTANCE.hudManager.bps));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 525, 225, 35, Animeware.INSTANCE.hudManager.ping));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 565, 225, 35, Animeware.INSTANCE.hudManager.pd));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 605, 225, 35, Animeware.INSTANCE.hudManager.biome));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 645, 225, 35, Animeware.INSTANCE.hudManager.time));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 685, 225, 35, Animeware.INSTANCE.hudManager.Armorstat));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 725, 225, 35, Animeware.INSTANCE.hudManager.hit));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 765, 225, 35, Animeware.INSTANCE.hudManager.mem));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 805, 225, 35, Animeware.INSTANCE.hudManager.timeChanger));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 845, 225, 35, Animeware.INSTANCE.hudManager.ts));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 885, 225, 35, Animeware.INSTANCE.hudManager.direction));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 925, 225, 35, Animeware.INSTANCE.hudManager.reachDisp));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 965, 225, 35, Animeware.INSTANCE.hudManager.particles));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 1005, 225, 35, Animeware.INSTANCE.hudManager.mldg));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 1045, 225, 35, Animeware.INSTANCE.hudManager.head));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 1085, 225, 35, Animeware.INSTANCE.hudManager.bo));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 1125, 225, 35, Animeware.INSTANCE.hudManager.tnt));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 1165, 225, 35, Animeware.INSTANCE.hudManager.iphys));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 1205, 225, 35, Animeware.INSTANCE.hudManager.smallsword));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 1245, 225, 35, Animeware.INSTANCE.hudManager.swordspin));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 1285, 225, 35, Animeware.INSTANCE.hudManager.mp));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 1325, 225, 35, Animeware.INSTANCE.hudManager.sz));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 1365, 225, 35, Animeware.INSTANCE.hudManager.watermark));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 1405, 225, 35, Animeware.INSTANCE.hudManager.arrows));
    		this.modButtons.add(new ModButton(this.width/ 2 - 143, 1445, 225, 35, Animeware.INSTANCE.hudManager.lilplayer));
        
        
		
		/*this.modButtons.add(new ModButton(510, 135, 25, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.thudblue));
		this.modButtons.add(new ModButton(540, 135, 28, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.thudcyan));
		this.modButtons.add(new ModButton(573, 135, 37, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.thudpurple));
		this.modButtons.add(new ModButton(615, 135, 22, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.thudred));
		this.modButtons.add(new ModButton(643, 135, 45, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.thudch));
		
		*/
		
		/*this.modButtons.add(new ModButton(510, 155, 25, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.fpsblue));
		this.modButtons.add(new ModButton(540, 155, 28, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.fpscyan));
		this.modButtons.add(new ModButton(573, 155, 37, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.fpspurple));
		this.modButtons.add(new ModButton(615, 155, 22, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.fpsred));
		this.modButtons.add(new ModButton(643, 155, 45, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.fpsch));
		
		this.modButtons.add(new ModButton(425, 355, 45, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.keystrokes));
		this.modButtons.add(new ModButton(510, 355, 25, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.keystrokesblue));
		this.modButtons.add(new ModButton(540, 355, 28, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.keystrokescyan));
		this.modButtons.add(new ModButton(573, 355, 37, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.keystrokespurple));
		this.modButtons.add(new ModButton(615, 355, 22, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.keystrokesred));
		this.modButtons.add(new ModButton(643, 355, 45, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.keystrokesCh));
		
		this.modButtons.add(new ModButton(425, 195, 23, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.cps));
		this.modButtons.add(new ModButton(510, 195, 25, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.cpsblue));
		this.modButtons.add(new ModButton(540, 195, 28, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.cpscyan));
		this.modButtons.add(new ModButton(573, 195, 37, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.cpspurple));
		this.modButtons.add(new ModButton(615, 195, 22, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.cpsred));
		this.modButtons.add(new ModButton(643, 195, 45, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.cpsch));
		
		this.modButtons.add(new ModButton(425, 215, 70, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.potionStat));
		this.modButtons.add(new ModButton(510, 215, 25, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.pStatBlue));
		this.modButtons.add(new ModButton(540, 215, 28, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.pStatCyan));
		this.modButtons.add(new ModButton(573, 215, 37, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.pStatPurple));
		this.modButtons.add(new ModButton(615, 215, 22, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.pStatRed));
		this.modButtons.add(new ModButton(643, 215, 45, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.pStatCh));
		
		this.modButtons.add(new ModButton(425, 235, 45, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.sip));
		this.modButtons.add(new ModButton(510, 235, 25, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.sipblue));
		this.modButtons.add(new ModButton(540, 235, 28, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.sipcyan));
		this.modButtons.add(new ModButton(573, 235, 37, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.sippurple));
		this.modButtons.add(new ModButton(615, 235, 22, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.sipred));
		this.modButtons.add(new ModButton(643, 235, 45, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.sipCh));
		
		this.modButtons.add(new ModButton(425, 255, 46, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.xyz));
		this.modButtons.add(new ModButton(510, 255, 25, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.xyzblue));
		this.modButtons.add(new ModButton(540, 255, 28, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.xyzcyan));
		this.modButtons.add(new ModButton(573, 255, 37, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.xyzpurple));
		this.modButtons.add(new ModButton(615, 255, 22, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.xyzred));
		this.modButtons.add(new ModButton(643, 255, 45, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.xyzCh));
		
		this.modButtons.add(new ModButton(425, 275, 45, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.bps));
		this.modButtons.add(new ModButton(510, 275, 25, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.bpsblue));
		this.modButtons.add(new ModButton(540, 275, 28, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.bpscyan));
		this.modButtons.add(new ModButton(573, 275, 37, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.bpspurple));
		this.modButtons.add(new ModButton(615, 275, 22, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.bpsred));
		this.modButtons.add(new ModButton(643, 275, 45, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.bpsCh));
		
		this.modButtons.add(new ModButton(425, 295, 25, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.ping));
		this.modButtons.add(new ModButton(510, 295, 25, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.pingblue));
		this.modButtons.add(new ModButton(540, 295, 28, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.pingcyan));
		this.modButtons.add(new ModButton(573, 295, 37, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.pingpurple));
		this.modButtons.add(new ModButton(615, 295, 22, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.pingred));
		this.modButtons.add(new ModButton(643, 295, 45, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.pingCh));
		
		this.modButtons.add(new ModButton(425, 315, 64, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.pd));
		this.modButtons.add(new ModButton(510, 315, 25, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.pdblue));
		this.modButtons.add(new ModButton(540, 315, 28, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.pdcyan));
		this.modButtons.add(new ModButton(573, 315, 37, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.pdpurple));
		this.modButtons.add(new ModButton(615, 315, 22, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.pdred));
		this.modButtons.add(new ModButton(643, 315, 45, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.pdCh));
		
		this.modButtons.add(new ModButton(425, 335, 35, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.biome));
		this.modButtons.add(new ModButton(510, 335, 25, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.biomeblue));
		this.modButtons.add(new ModButton(540, 335, 28, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.biomecyan));
		this.modButtons.add(new ModButton(573, 335, 37, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.biomepurple));
		this.modButtons.add(new ModButton(615, 335, 22, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.biomered));
		this.modButtons.add(new ModButton(643, 335, 45, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.biomech));
		
		this.modButtons.add(new ModButton(425, 175, 61, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.time));
		this.modButtons.add(new ModButton(510, 175, 25, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.timeBlue));
		this.modButtons.add(new ModButton(540, 175, 28, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.timeCyan));
		this.modButtons.add(new ModButton(573, 175, 37, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.timePurple));
		this.modButtons.add(new ModButton(615, 175, 22, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.timeRed));
		this.modButtons.add(new ModButton(643, 175, 45, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.timeCh));*/
		
		this.buttonList.add(new LogoButtonWhite(0, this.width / 2 - 188, this.height / 2 - 110, ""));
		this.buttonList.add(new HomeCGButton(1, this.width / 2 - 188, this.height / 2 - 70, ""));
		this.buttonList.add(new SettingsCGButton(2, this.width / 2 - 188, this.height / 2 - 40, ""));
		this.buttonList.add(new CosmeticsCGButton(3, this.width / 2 - 188, this.height / 2 - 5, ""));
		this.buttonList.add(new ToggleableCGButton(4, this.width / 2 - 188, this.height / 2 + 30, ""));
		this.buttonList.add(new ServersCGButton(5, this.width / 2 - 188, this.height / 2 + 60, ""));
		
		
		//this.buttonList.add(new WebsiteCGButton(6, this.width / 2 - 188, this.height / 2 + 150, ""));
		//this.buttonList.add(new InfoCGButton(7, this.width / 2 - 188, this.height / 2 + 190, ""));
		//this.buttonList.add(new LilButtonCG(10, this.width / 2 - 188, this.height / 2 + 185, ""));
		//this.buttonList.add(new ClickGUIButtonLightShort(8, this.width / 2 - 188, this.height / 2 + 195, ">>"));
		//this.buttonList.add(new ClickGUIButtonLightShort(9, this.width / 2 - 188, this.height / 2 + 195, "<<"));
		
		
		//this.buttonList.add(new SettingsCGButtonLil(1, 262, height / 3 - 50, ""));
		//this.modButtons.add(new ModButton(270, 300, 22, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.direction));
		//this.modButtons.add(new ModButton(270, 270, 22, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.ts));
		//this.modButtons.add(new ModButton(270, 225, 22, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.clock));	
		//this.modButtons.add(new ModButton(315, 225, 22, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.TNTTimer));
		//this.modButtons.add(new ModButton(270, 195, 57, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.OldAnimations));
		//this.modButtons.add(new ModButton(270, 240, 60, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.freelook));
	}
		//this.modButtons.add(new ModButton(370, 105, 25, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.thudblue));
		//this.modButtons.add(new ModButton(404, 105, 28, mc.fontRendererObj.FONT_HEIGHT + 3, Animeware.INSTANCE.hudManager.thudcyan));
		
		
		/*if(mc.isFullScreen()) {
			System.setProperty("org.lwjgl.opengl.Window.undecorated", "true");
			
			try {
				Display.setDisplayMode(Display.getDesktopDisplayMode());
			} catch (LWJGLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Display.setLocation(0, 0);
			try {
				Display.setFullscreen(false);
			} catch (LWJGLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Display.setResizable(false);
		} else {
			System.setProperty("org.lwjgl.opengl.Window.undecorated", "false");
			try {
				Display.setDisplayMode(new DisplayMode(mc.displayWidth, mc.displayHeight));
			} catch (LWJGLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Display.setResizable(true);
		}
	}*/
	/*@Override
	protected void actionPerformed(GuiButton button) throws IOException {
		if(button.id == 1) {
			mc.displayGuiScreen(new GuiMultiplayerIngame());
		}
	}*/
	
	
	
	
	@Override
	protected void actionPerformed(GuiButton button) throws IOException {
		if(button.id == 1) {
			mc.displayGuiScreen(new ClickGUI());
			
		}
		if(button.id == 2) {
			mc.displayGuiScreen(new HUDConfigScreen());
		}
		if(button.id == 3) {
			mc.displayGuiScreen(new CosmeticGUINew());
		}
		if(button.id == 4) {
			mc.displayGuiScreen(new ClickGUI2(null));
		}
		if(button.id == 5) {
			mc.displayGuiScreen(new GuiMultiplayerIngame());
		}
		if(button.id == 6) {
			try {
	 			  Desktop desktop = java.awt.Desktop.getDesktop();
	 			  URI oURL = new URI("http://hynomacka.ddns.net");
	 			  desktop.browse(oURL);
	 			} catch (Exception e) {
	 			  e.printStackTrace();
	 			}
		}
		if(button.id == 7) {
			mc.displayGuiScreen(new Changelog());
			//Animeware.Cape = !Animeware.Cape;
		}
		if(button.id == 8) {
			mc.displayGuiScreen(new CosmeticGUINew());
		}
		if(button.id == 9) {
			mc.displayGuiScreen(new ClickGUI());
		}
		if(button.id == 0) {
			mc.displayGuiScreen(new ProfileCGui(null));
		}
	}
	
	public ParticleEngine engine = new ParticleEngine();
	
	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
		
		//Minecraft.getMinecraft().entityRenderer.loadShader(new ResourceLocation("shaders/post/blur.json"));
		//FontUtil.normal.drawString("Animeware", 340, 135, ColorMode.getWhiteColor()); 
		GL11.glColor4f(1F, 1F, 1F, 1F);
		GlStateManager.enableAlpha();
		GlStateManager.enableBlend();
		/*mc.getTextureManager().bindTexture(new ResourceLocation ("Animeware/blur.png"));
		this.drawModalRectWithCustomSizedTexture(0, 0, 0, 0, this.width, this.height, this.width, this.height);*/
		//if(MinecraftServer.getServer().isSinglePlayer()) {
		
		//Playerdraw(370, 330, 25, 50, 0, mc.thePlayer);		
		
		ScaledResolution sr = new ScaledResolution(mc);
		/*Discord GUI:*/
		//RoundedUtils.drawSmoothRoundedRect(170, 60, sr.getScaledWidth() - 170, sr.getScaledHeight() - 100, 10, ColorMode.getClickGuiColor());
		//RoundedUtils.drawSmoothRoundedRect(200, 75, sr.getScaledWidth() - 460, sr.getScaledHeight() - 100, 12, ColorMode.getClickGuiMidColor());		
	    //Gui.drawRect(300, 75, sr.getScaledWidth() - 170, sr.getScaledHeight() - 100, ColorMode.getClickGuiInnerColor());
		//Gui.drawRect(195, 105, sr.getScaledWidth() - 170, sr.getScaledHeight() - 410, ColorMode.getClickGuiColor());
		
		//RoundedUtils.drawSmoothRoundedRect(200, 115, sr.getScaledWidth() - 665, sr.getScaledHeight() - 375, 13, ColorMode.getClickGuiInnerColor());
		//RoundedUtils.drawSmoothRoundedRect(203, 110, sr.getScaledWidth() - 663, sr.getScaledHeight() - 385, 14, ColorMode.getClickGuiInnerColor());
		//RoundedUtils.drawSmoothRoundedRect(203, 110, sr.getScaledWidth() - 663, sr.getScaledHeight() - 385, 24, ColorMode.getClickGuiInnerColor());
		//RoundedUtils.drawSmoothRoundedRect(203, 110, sr.getScaledWidth() - 663, sr.getScaledHeight() - 385, 14, ColorMode.getClickGuiInnerColor());
		//RoundedUtils.drawSmoothRoundedRect(203, 210, sr.getScaledWidth() - 663, sr.getScaledHeight() - 395, 14, ColorMode.getClickGuiInnerColor());
		
		/*NetworkPlayerInfo playerinfo =
				mc.getNetHandler().getPlayerInfo(player.getUniqueID());
		if(playerinfo != null) {
			mc.getTextureManager().bindTexture(playerinfo.getLocationSkin());
			GL11.glColor4f(1F, 1F, 1F, 1F);
			Gui.drawScaledCustomSizeModalRect((int) x -5, (int) y - 5, 8F, 8F, 8 , 8, 20, 20, 64F, 64F);
		}*/
		//RoundedUtils.drawSmoothRoundedRect(200, 125, sr.getScaledWidth() - 220, sr.getScaledHeight() - 373, 18, ColorMode.getClickGuiColor());     //mod bg 1
		/*RoundedUtils.drawSmoothRoundedRect(312, 125, sr.getScaledWidth() - 220, sr.getScaledHeight() - 373, 18, ColorMode.getClickGuiMidColor());     //text bg 
		RoundedUtils.drawSmoothRoundedRect(320, 150, sr.getScaledWidth() - 220, sr.getScaledHeight() - 130, 18, ColorMode.getClickGuiColor());       //side		
		RoundedUtils.drawSmoothRoundedRect(415, 120, sr.getScaledWidth() - 220, sr.getScaledHeight() - 130, 18, ColorMode.getClickGuiColor());      //main bg	
		RoundedUtils.drawSmoothRoundedRect(420, 125, sr.getScaledWidth() - 225, sr.getScaledHeight() - 135, 18, ColorMode.getClickGuiMidColor());  //main		
		RoundedUtils.drawSmoothRoundedRect(255, 120, sr.getScaledWidth() - 655, sr.getScaledHeight() - 130, 18, ColorMode.getClickGuiColor());      //second main bg
		RoundedUtils.drawSmoothRoundedRect(260, 125, sr.getScaledWidth() - 660, sr.getScaledHeight() - 135, 18, ColorMode.getClickGuiMidColor());  //second main
		RoundedUtils.drawSmoothRoundedRect(324, 342, sr.getScaledWidth() - 225, sr.getScaledHeight() - 135, 18, ColorMode.getClickGuiMidColor());  //discord
		
		RoundedUtils.drawSmoothRoundedRect(423, 127, sr.getScaledWidth() - 270, sr.getScaledHeight() - 169, 10, ColorMode.getMidDarkColor());     //mod bg 1*/
		     //mod bg 11
		
		//drawDefaultBackground();
		//this.engine.render(mouseX, mouseY);
	    //if (this.anim > 0.0F)
	      //this.anim -= 6.0F; 
	    //GL11.glEnable(3089);
	    //GLUtils.makeScissorBox((this.width / 2 - 220) + this.anim, (this.height / 2 - 114) + this.anim, (this.width / 2 + 170) - this.anim, (this.height / 2 + 110) - this.anim);
	    
		
		//GL11.glPushMatrix();
		
		RoundedUtils.drawSmoothRoundedRect((this.width / 2 - 190), (this.height / 2 - 110), (this.width / 2 + 190), (this.height / 2 + 110), 18.0F, new Color(25, 25, 30, 255).getRGB());
		RoundedUtils.drawSmoothRoundedRect((this.width / 2 - 190), (this.height / 2 - 110), (this.width / 2 - 150), (this.height / 2 + 110), 18.0F, new Color(50, 50, 55, 155).getRGB());	    
		RoundedUtils.drawSmoothRoundedRect((this.width / 2 + 90), (this.height / 2 - 110), (this.width / 2 + 190), (this.height / 2 + 110), 18.0F, new Color(50, 50, 55, 155).getRGB());
		RoundedUtils.drawSmoothRoundedRect((this.width / 2 - 185), (this.height / 2 - 78), (this.width / 2 - 155), (this.height / 2 - 76), 4.0F, new Color(100, 100, 105, 255).getRGB());
		
		/*RoundedUtils.drawSmoothRoundedRect((this.width / 2 - 140), (this.height / 2 - 105), (this.width / 2 + 80), (this.height / 2 - 70), 18.0F, new Color(50, 50, 55, 155).getRGB());
		RoundedUtils.drawSmoothRoundedRect((this.width / 2 - 140), (this.height / 2 - 105), (this.width / 2 - 105), (this.height / 2 - 70), 18.0F, new Color(70, 70, 75, 155).getRGB());*/
		//GL11.glPopMatrix();
		
		
		
		
		//this.mc.getTextureManager().bindTexture(new ResourceLocation("Animeware/logored.png"));
		//this.drawModalRectWithCustomSizedTexture(this.width / 2 - 100, this.height / 2 - 5, 0, 0, 250, 250, 250, 250);
	    
	    //int cc = 0, cm = 0, csc = 0;
	    //byte b;
	    //int i;
		//GlStateManager.pushMatrix();
		//GlStateManager.scale(0.8, 0.8, 0.8);
		//int defaultpos = 340
		//FontUtil.normal.drawString("A", 320, 135, ColorUtils.astolfoColors(0, 100, -700L));
	   /* this.bold.drawString("a", logo2 + 43, logoW, ColorUtils.astolfoColors(0, 100, -500L));
	    this.bold.drawString("-", logo2 + 50, logoW, ColorUtils.astolfoColors(0, 100, -600L));
	    this.bold.drawString("1", logo2 + 53, logoW, ColorUtils.astolfoColors(0, 100, -700L));
	    this.bold.drawString(".", logo2 + 57, logoW, ColorUtils.astolfoColors(0, 100, -700L));
	    this.bold.drawString("6", logo2 + 60, logoW, ColorUtils.astolfoColors(0, 100, -700L));*/
	    
	    
		/*FontUtil.normal.drawString("Animeware", 340, 135, ColorMode.getRedColor()); 
		FontUtil.normal.drawString("", 340, 135, ColorMode.getWhiteColor()); 
		FontUtil.normal.drawString((Minecraft.getMinecraft().getSession().getUsername()), 352, 373, ColorMode.getWhiteColor());*/
		
		
		
		//FontUtil.normal.drawString(this.dname(null), 352, 373, ColorMode.getWhiteColor());
		//FontUtil.normal.drawString("A", 340, 135, ColorUtils.astolfoColors(0, 100, 400L));
		//FontUtil.normal.drawString("n", 340 + 7, 135, ColorUtils.astolfoColors(0, 100, 300L));
		//FontUtil.normal.drawString("i", 340 + 13, 135, ColorUtils.astolfoColors(0, 100, 200L));
		//FontUtil.normal.drawString("m", 340 + 15, 135, ColorUtils.astolfoColors(0, 100, 100L));
		//FontUtil.normal.drawString("e", 340 + 23, 135, ColorUtils.astolfoColors(0, 100, 0L));
		//FontUtil.normal.drawString("w", 340 + 29, 135, ColorUtils.astolfoColors(0, 100, -100L));
		//FontUtil.normal.drawString("a", 340 + 36, 135, ColorUtils.astolfoColors(0, 100, -200L));
		//FontUtil.normal.drawString("r", 340 + 42, 135, ColorUtils.astolfoColors(0, 100, -300L));
		//FontUtil.normal.drawString("e", 340 + 46, 135, ColorUtils.astolfoColors(0, 100, -400L));
		//mc.getTextureManager().bindTexture(new ResourceLocation ("Animeware/text_white.png"));
		//this.drawModalRectWithCustomSizedTexture(345, 95, 0, 0, 250, 250, 250, 250);
		
		
		if(MinecraftServer.getServer().isSinglePlayer()) {
			NetworkPlayerInfo playerInfo = mc.getNetHandler().getPlayerInfo(mc.thePlayer.getUniqueID());
			if(playerInfo != null) {
				//mc.getTextureManager().bindTexture(playerInfo.getLocationSkin());
				GL11.glColor4f(1F, 1F, 1F, 1F);
				//Gui.drawScaledCustomSizeModalRect(330, 365, 8F, 8F, 8, 8, 20, 20, 64F, 64F);
			}
			} else if(Minecraft.getMinecraft().getCurrentServerData() != null) {
				NetworkPlayerInfo playerInfo = mc.getNetHandler().getPlayerInfo(mc.thePlayer.getUniqueID());
				if(playerInfo != null) {
					//mc.getTextureManager().bindTexture(playerInfo.getLocationSkin());
					GL11.glColor4f(1F, 1F, 1F, 1F);
					//Gui.drawScaledCustomSizeModalRect(330, 365, 8F, 8F, 8, 8, 20, 20, 64F, 64F);
			}
			} else {
				
			}
		
		
		/*this.buttonList.add(new ClassicButton(1, this.width / 2 - 92, this.height / 2 + 25, 200, 20, 
     	     	I18n.format("Singleplayer", new Object[0]))); */
								
		GL11.glDisable(GL11.GL_SCISSOR_TEST);
		checkMouseWheel(mouseX, mouseY);
		GL11.glPushMatrix();
		GL11.glPushAttrib(GL11.GL_SCISSOR_BIT);
		{
			RenderUtil.scissor(this.width / 2 - 190, this.height / 2 - 110, this.width / 2 + 190, this.height / 2 + 110);
			//RenderUtil.scissor2(this.width / 2 - 190, this.height / 2 - 110, 1920, 1080);
			//RenderUtil.scissor(this.width / 2 - 100, -300, 1920, 1080);
			GL11.glEnable(GL11.GL_SCISSOR_TEST);
		}		
		
		super.drawScreen(mouseX, mouseY, partialTicks);
		for(ModButton m : modButtons) {
			m.draw();		
		}
		GL11.glDisable(GL11.GL_SCISSOR_TEST);
		GL11.glPopAttrib();
		GL11.glPopMatrix();
		
		
	}
	//@Override
	public int dname(DiscordUser user) {
			return fontRendererObj.drawString(user.username + "#" + user.discriminator, 352, 373, ColorMode.getWhiteColor());	
		//System.out.println("-_-");
			//update("Starting", "");
	}
	 
	@Override
	public void draw() {

		GL11.glColor4f(1F, 1F, 1F, 1F);

			Playerdraw(15 + 15, 15 + 50, 25, 50, 0, null);
			
		super.draw();
	}
	public static void Playerdraw(int posX, int posY, int scale, float mouseX, float mouseY, EntityLivingBase ent)
    {
		if(MinecraftServer.getServer().isSinglePlayer()) {
        GlStateManager.enableColorMaterial();
        GlStateManager.pushMatrix();
        GlStateManager.translate((float)posX, (float)posY, 50.0F);
        GlStateManager.scale((float)(-65), (float)65, (float)65);
        GlStateManager.rotate(180.0F, 0.0F, 0.0F, 1.0F);
        float f = ent.renderYawOffset;
        float f1 = ent.rotationYaw;
        float f2 = ent.rotationPitch;
        float f3 = ent.prevRotationYawHead;
        float f4 = ent.rotationYawHead;
        GlStateManager.rotate(155.0F, 0.0F, 1.0F, 0.0F);
        RenderHelper.enableStandardItemLighting();
        GlStateManager.rotate(-135.0F, 0.0F, 1.0F, 0.0F);
        GlStateManager.rotate(-((float)Math.atan((double)(mouseY / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
        ent.renderYawOffset = (float)Math.atan((double)(mouseX / 40.0F)) * 20.0F;
        ent.rotationYaw = (float)Math.atan((double)(mouseX / 40.0F)) * 40.0F;
        ent.rotationPitch = -((float)Math.atan((double)(mouseY / 40.0F))) * 20.0F;
        ent.rotationYawHead = ent.rotationYaw;
        ent.prevRotationYawHead = ent.rotationYaw;
        GlStateManager.translate(0.0F, 0.0F, 0.0F);
        RenderManager rendermanager = Minecraft.getMinecraft().getRenderManager();
        rendermanager.setPlayerViewY(180.0F);
        rendermanager.setRenderShadow(false);
        rendermanager.renderEntityWithPosYaw(ent, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F);
        rendermanager.setRenderShadow(true);
        ent.renderYawOffset = f;
        ent.rotationYaw = f1;
        ent.rotationPitch = f2;
        ent.prevRotationYawHead = f3;
        ent.rotationYawHead = f4;
        GlStateManager.popMatrix();
        RenderHelper.disableStandardItemLighting();
        GlStateManager.disableRescaleNormal();
        GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
        GlStateManager.disableTexture2D();
        GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
    } else if(Minecraft.getMinecraft().getCurrentServerData() != null) {
    	GlStateManager.enableColorMaterial();
        GlStateManager.pushMatrix();
        GlStateManager.translate((float)posX, (float)posY, 50.0F);
        GlStateManager.scale((float)(-65), (float)65, (float)65);
        GlStateManager.rotate(180.0F, 0.0F, 0.0F, 1.0F);
        float f = ent.renderYawOffset;
        float f1 = ent.rotationYaw;
        float f2 = ent.rotationPitch;
        float f3 = ent.prevRotationYawHead;
        float f4 = ent.rotationYawHead;
        GlStateManager.rotate(155.0F, 0.0F, 1.0F, 0.0F);
        RenderHelper.enableStandardItemLighting();
        GlStateManager.rotate(-135.0F, 0.0F, 1.0F, 0.0F);
        GlStateManager.rotate(-((float)Math.atan((double)(mouseY / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
        ent.renderYawOffset = (float)Math.atan((double)(mouseX / 40.0F)) * 20.0F;
        ent.rotationYaw = (float)Math.atan((double)(mouseX / 40.0F)) * 40.0F;
        ent.rotationPitch = -((float)Math.atan((double)(mouseY / 40.0F))) * 20.0F;
        ent.rotationYawHead = ent.rotationYaw;
        ent.prevRotationYawHead = ent.rotationYaw;
        GlStateManager.translate(0.0F, 0.0F, 0.0F);
        RenderManager rendermanager = Minecraft.getMinecraft().getRenderManager();
        rendermanager.setPlayerViewY(180.0F);
        rendermanager.setRenderShadow(false);
        rendermanager.renderEntityWithPosYaw(ent, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F);
        rendermanager.setRenderShadow(true);
        ent.renderYawOffset = f;
        ent.rotationYaw = f1;
        ent.rotationPitch = f2;
        ent.prevRotationYawHead = f3;
        ent.rotationYawHead = f4;
        GlStateManager.popMatrix();
        RenderHelper.disableStandardItemLighting();
        GlStateManager.disableRescaleNormal();
        GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
        GlStateManager.disableTexture2D();
        GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
	} else {
		
	}
    }
    
	
	
	@Override
	protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
		super.mouseClicked(mouseX, mouseY, mouseButton);
		for(ModButton m : modButtons) {
			m.onClick(mouseX, mouseY, mouseButton);
		}
		for(CosmeticButton cos : cosButtons) {
			cos.onClick(mouseX, mouseY, mouseButton);
		}
	}
	private void drawRoundedRect(final int x, final int y, final int width, final int height, final int cornerRadius, final Color color) {
        Gui.drawRect(x, y + cornerRadius, x + cornerRadius, y + height - cornerRadius, color.getRGB());
        Gui.drawRect(x + cornerRadius, y, x + width - cornerRadius, y + height, color.getRGB());
        Gui.drawRect(x + width - cornerRadius, y + cornerRadius, x + width, y + height - cornerRadius, color.getRGB());
        this.drawArc(x + cornerRadius, y + cornerRadius, cornerRadius, 0, 90, color);
        this.drawArc(x + width - cornerRadius, y + cornerRadius, cornerRadius, 270, 360, color);
        this.drawArc(x + width - cornerRadius, y + height - cornerRadius, cornerRadius, 180, 270, color);
        this.drawArc(x + cornerRadius, y + height - cornerRadius, cornerRadius, 90, 180, color);
    }
    
    private void drawArc(final int x, final int y, final int radius, final int startAngle, final int endAngle, final Color color) {
        GL11.glPushMatrix();
        GL11.glEnable(3042);
        GL11.glDisable(3553);
        GL11.glBlendFunc(770, 771);
        GL11.glColor4f(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f);
        final WorldRenderer worldRenderer = Tessellator.getInstance().getWorldRenderer();
        worldRenderer.begin(6, DefaultVertexFormats.POSITION);
        worldRenderer.pos(x, y, 0.0).endVertex();
        for (int i = (int)(startAngle / 360.0 * 100.0); i <= (int)(endAngle / 360.0 * 100.0); ++i) {
            final double angle = 6.283185307179586 * i / 100.0 + Math.toRadians(180.0);
            worldRenderer.pos(x + Math.sin(angle) * radius, y + Math.cos(angle) * radius, 0.0).endVertex();
        }
        Tessellator.getInstance().draw();
        GL11.glEnable(3553);
        GL11.glDisable(3042);
        GL11.glPopMatrix();
    }
    
    private void drawCircle(final int x, final int y, final int width, final int height, final Color color) {
        this.drawArc(x + width, y + height / 2, width / 2, 0, 360, color);
    }
    
    @Override
    public void onGuiClosed() {
    	//Minecraft.getMinecraft().entityRenderer.loadShader(null);
        super.onGuiClosed();
      }
    
    
}
