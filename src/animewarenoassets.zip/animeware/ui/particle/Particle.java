package animeware.ui.particle;

import java.util.Random;
import net.minecraft.client.gui.ScaledResolution;

public class Particle {
  public float x;
  
  public float y;
  
  public float radius;
  
  public float speed;
  
  public float ticks;
  
  public float opacity;
  
  public Particle(ScaledResolution scaledResolution, float f, float f2) {
    this.x = (new Random()).nextFloat() * scaledResolution.getScaledWidth();
    this.y = (new Random()).nextFloat() * scaledResolution.getScaledHeight();
    this.ticks = (new Random()).nextFloat() * scaledResolution.getScaledHeight() / 2.0F;
    this.radius = f;
    this.speed = f2;
  }
}
