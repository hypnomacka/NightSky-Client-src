package animeware.ui.particle;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import javax.imageio.ImageIO;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.BufferUtils;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;

public final class GLUtils {
  private static final Random random = new Random();
  
  public static List<Integer> vbos = new ArrayList<>();
  
  public static List<Integer> textures = new ArrayList<>();
  
  private static final List depth = new ArrayList();
  
  public static void glScissor(int[] nArray) {
    glScissor(nArray[0], nArray[1], (nArray[0] + nArray[2]), (nArray[1] + nArray[3]));
  }
  
  public static void glScissor(float f, float f2, float f3, float f4) {
    int n = getScaleFactor();
    GL11.glScissor((int)(f * n), (int)((Minecraft.getMinecraft()).displayHeight - f4 * n), (int)((f3 - f) * n), (int)((f4 - f2) * n));
  }
  
  public static int getScaleFactor() {
    int n = 1;
    boolean bl = Minecraft.getMinecraft().isUnicode();
    Minecraft.getMinecraft();
    int n2 = Minecraft.getMinecraft().gameSettings.guiScale;
    if (n2 == 0)
      n2 = 1000; 
    while (n < n2 && (Minecraft.getMinecraft()).displayWidth / (n + 1) >= 320 && (Minecraft.getMinecraft()).displayHeight / (n + 1) >= 240)
      n++; 
    if (bl && n % 2 != 0 && n != 1)
      n--; 
    return n;
  }
  
  public static int getMouseX() {
    return Mouse.getX() * getScreenWidth() / (Minecraft.getMinecraft()).displayWidth;
  }
  
  public static int getMouseY() {
    return getScreenHeight() - Mouse.getY() * getScreenHeight() / (Minecraft.getMinecraft()).displayWidth - 1;
  }
  
  public static int getScreenWidth() {
    return (Minecraft.getMinecraft()).displayWidth / getScaleFactor();
  }
  
  public static int getScreenHeight() {
    return (Minecraft.getMinecraft()).displayHeight / getScaleFactor();
  }
  
  public static boolean isHovered(int n, int n2, int n3, int n4, int n5, int n6) {
    return (n5 >= n && n5 <= n + n3 && n6 >= n2 && n6 < n2 + n4);
  }
  
  public static int genVBO() {
    int n = GL15.glGenBuffers();
    vbos.add(Integer.valueOf(n));
    GL15.glBindBuffer(34962, n);
    return n;
  }
  
  public static int getTexture() {
    int n = GL11.glGenTextures();
    textures.add(Integer.valueOf(n));
    return n;
  }
  
  public static int applyTexture(int n, File file, int n2, int n3) throws IOException {
    applyTexture(n, ImageIO.read(file), n2, n3);
    return n;
  }
  
  public static int applyTexture(int n, BufferedImage bufferedImage, int n2, int n3) {
    int[] nArray = new int[bufferedImage.getWidth() * bufferedImage.getHeight()];
    bufferedImage.getRGB(0, 0, bufferedImage.getWidth(), bufferedImage.getHeight(), nArray, 0, bufferedImage.getWidth());
    ByteBuffer byteBuffer = BufferUtils.createByteBuffer(bufferedImage.getWidth() * bufferedImage.getHeight() * 4);
    int n4 = 0;
    while (n4 < bufferedImage.getHeight()) {
      int n5 = 0;
      while (n5 < bufferedImage.getWidth()) {
        int n6 = nArray[n4 * bufferedImage.getWidth() + n5];
        byteBuffer.put((byte)(n6 >> 16 & 0xFF));
        byteBuffer.put((byte)(n6 >> 8 & 0xFF));
        byteBuffer.put((byte)(n6 & 0xFF));
        byteBuffer.put((byte)(n6 >> 24 & 0xFF));
        n5++;
      } 
      n4++;
    } 
    byteBuffer.flip();
    applyTexture(n, bufferedImage.getWidth(), bufferedImage.getHeight(), byteBuffer, n2, n3);
    return n;
  }
  
  public static int applyTexture(int n, int n2, int n3, ByteBuffer byteBuffer, int n4, int n5) {
    GL11.glBindTexture(3553, n);
    GL11.glTexParameteri(3553, 10241, n4);
    GL11.glTexParameteri(3553, 10240, n4);
    GL11.glTexParameteri(3553, 10242, n5);
    GL11.glTexParameteri(3553, 10243, n5);
    GL11.glPixelStorei(3317, 1);
    GL11.glTexImage2D(3553, 0, 32856, n2, n3, 0, 6408, 5121, byteBuffer);
    GL11.glBindTexture(3553, 0);
    return n;
  }
  
  public static void cleanup() {
    GL15.glBindBuffer(34962, 0);
    GL11.glBindTexture(3553, 0);
    Iterator<Integer> iterator;
    for (iterator = vbos.iterator(); iterator.hasNext(); ) {
      int n = ((Integer)iterator.next()).intValue();
      GL15.glDeleteBuffers(n);
    } 
    for (iterator = textures.iterator(); iterator.hasNext(); ) {
      int n = ((Integer)iterator.next()).intValue();
      GL11.glDeleteTextures(n);
    } 
  }
  
  public static void glColor(float f, float f2, float f3, float f4) {
    GlStateManager.color(f, f2, f3, f4);
  }
  
  public static void glColor(Color color) {
    GlStateManager.color(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
  }
  
  public static void glColor(int n) {
    GlStateManager.color((n >> 16 & 0xFF) / 255.0F, (n >> 8 & 0xFF) / 255.0F, (n & 0xFF) / 255.0F, (n >> 24 & 0xFF) / 255.0F);
  }
  
  public static Color getHSBColor(float f, float f2, float f3) {
    return Color.getHSBColor(f, f2, f3);
  }
  
  public static Color getRandomColor(int n, float f) {
    float f2 = random.nextFloat();
    float f3 = ((random.nextInt(n) + n) / n + n);
    return getHSBColor(f2, f3, f);
  }
  
  public static Color getRandomColor() {
    return getRandomColor(1000, 0.6F);
  }
  
  public static void pre() {
    if (depth.isEmpty()) {
      GL11.glClearDepth(1.0D);
      GL11.glClear(256);
    } 
  }
  
  public static void mask() {
    depth.add(0, Integer.valueOf(GL11.glGetInteger(2932)));
    GL11.glEnable(6145);
    GL11.glDepthMask(true);
    GL11.glDepthFunc(513);
    GL11.glColorMask(false, false, false, true);
  }
  
  public static void render() {
    render(514);
  }
  
  public static void render(int n) {
    GL11.glDepthFunc(n);
    GL11.glColorMask(true, true, true, true);
  }
  
  public static void post() {
    GL11.glDepthFunc(((Integer)depth.get(0)).intValue());
    depth.remove(0);
  }
  
  public static double interpolate(double d, double d2, double d3) {
    return d2 + (d - d2) * d3;
  }
  
  public static void startSmooth() {
    GL11.glEnable(2848);
    GL11.glEnable(2881);
    GL11.glEnable(2832);
    GL11.glEnable(3042);
    GL11.glBlendFunc(770, 771);
    GL11.glHint(3154, 4354);
    GL11.glHint(3155, 4354);
    GL11.glHint(3153, 4354);
  }
  
  public static void endSmooth() {
    GL11.glDisable(2848);
    GL11.glDisable(2881);
    GL11.glEnable(2832);
  }
}
