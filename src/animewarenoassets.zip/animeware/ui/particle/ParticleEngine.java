package animeware.ui.particle;

import com.google.common.collect.Lists;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;

public class ParticleEngine {
  public CopyOnWriteArrayList<Particle> particles = Lists.newCopyOnWriteArrayList();
  
  public float lastMouseX;
  
  public float lastMouseY;
  
  public static void drawCircle(double d, double d2, float f, int n) {
    float f2 = (n >> 24 & 0xFF) / 255.0F;
    float f3 = (n >> 16 & 0xFF) / 255.0F;
    float f4 = (n >> 8 & 0xFF) / 255.0F;
    float f5 = (n & 0xFF) / 255.0F;
    GL11.glColor4f(f3, f4, f5, f2);
    GL11.glBegin(9);
    int n2 = 0;
    while (n2 <= 360) {
      GL11.glVertex2d(d + Math.sin(n2 * 3.141526D / 180.0D) * f, d2 + Math.cos(n2 * 3.141526D / 180.0D) * f);
      n2++;
    } 
    GL11.glEnd();
  }
  
  public static void disableRender2D() {
    GL11.glDisable(3042);
    GL11.glEnable(2884);
    GL11.glEnable(3553);
    GL11.glDisable(2848);
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    GlStateManager.shadeModel(7424);
    GlStateManager.disableBlend();
    GL11.glEnable(3553);
  }
  
  public static void enableRender2D() {
    GL11.glEnable(3042);
    GL11.glDisable(2884);
    GL11.glDisable(3553);
    GL11.glEnable(2848);
    GL11.glBlendFunc(770, 771);
    GL11.glLineWidth(1.0F);
  }
  
  public static void setColor(int n) {
    float f = (n >> 24 & 0xFF) / 255.0F;
    float f2 = (n >> 16 & 0xFF) / 255.0F;
    float f3 = (n >> 8 & 0xFF) / 255.0F;
    float f4 = (n & 0xFF) / 255.0F;
    GL11.glColor4f(f2, f3, f4, (f == 0.0F) ? 1.0F : f);
  }
  
  public static void drawLine(double d, double d2, double d3, double d4, float f, int n) {
    enableRender2D();
    setColor(n);
    GL11.glLineWidth(f);
    GL11.glBegin(1);
    GL11.glVertex2d(d, d2);
    GL11.glVertex2d(d3, d4);
    GL11.glEnd();
    disableRender2D();
  }
  
  public void render(float f, float f2) {
    GlStateManager.enableBlend();
    GlStateManager.disableAlpha();
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    ScaledResolution scaledResolution = new ScaledResolution(Minecraft.getMinecraft());
    float f3 = 0.0F;
    float f4 = 0.0F;
    while (this.particles.size() < scaledResolution.getScaledWidth() / 8.0F)
      this.particles.add(new Particle(scaledResolution, (new Random()).nextFloat() - 1.5F, (new Random()).nextFloat() * 3.0F + 5.0F)); 
    ArrayList<Particle> arrayList = Lists.newArrayList();
    int n = 52;
    int n2 = -570425345;
    int n3 = 100;
    for (Particle particle : this.particles) {
      double d = particle.x + Math.sin((particle.ticks / 2.0F)) * 50.0D + (-f3 / 5.0F);
      double d2 = (particle.ticks * particle.speed * particle.ticks / 10.0F + -f4 / 5.0F);
      if (d2 < scaledResolution.getScaledHeight()) {
        if (particle.opacity < n)
          particle.opacity += 2.0F; 
        if (particle.opacity > n)
          particle.opacity = n; 
        Color color = new Color(255, 255, 255, (int)particle.opacity);
        float f5 = 1.0F;
        int n4 = (new Color(1.0F, (1.0F - (float)(d2 / scaledResolution.getScaledHeight())) / 2.0F, 1.0F, 1.0F)).getRGB();
        GlStateManager.enableBlend();
        drawBorderedCircle(d, d2, particle.radius * particle.opacity / n, n2, n2);
      } 
      particle.ticks = (float)(particle.ticks + 0.05D);
      if (d2 <= scaledResolution.getScaledHeight() && d2 >= 0.0D && d <= scaledResolution.getScaledWidth() && d >= 0.0D)
        continue; 
      arrayList.add(particle);
    } 
    this.particles.removeAll(arrayList);
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    GlStateManager.enableBlend();
    GlStateManager.disableAlpha();
    this.lastMouseX = GLUtils.getMouseX();
    this.lastMouseY = GLUtils.getMouseY();
  }
  
  public void drawBorderedCircle(double d, double d2, float f, int n, int n2) {
    GL11.glDisable(3553);
    GL11.glBlendFunc(770, 771);
    GL11.glEnable(2848);
    GL11.glPushMatrix();
    GL11.glScalef(0.1F, 0.1F, 0.1F);
    drawCircle(d * 10.0D, d2 * 10.0D, f * 10.0F, n2);
    GL11.glScalef(10.0F, 10.0F, 10.0F);
    GL11.glPopMatrix();
    GL11.glEnable(3553);
    GL11.glDisable(2848);
  }
}
