package animeware.ui.comp;

import java.awt.Color;

import org.lwjgl.opengl.GL11;

import animeware.hud.mod.HudMod;
import animeware.util.font.FontUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.ResourceLocation;

public class ModButtonBlue {
	
	public int x, y, w, h;
	public HudMod m;
	private boolean enabled;
	
	public ModButtonBlue(int x, int y, int w, int h, HudMod m) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.m = m;
		this.enabled = false;
	}
	
	public void draw() {
		Gui.drawRect(x, y, x + w, y + h, new Color(40, 40, 40, 255).getRGB());
        FontUtil.normal.drawString(m.name, x + 2, y + 2, getColor());
        Minecraft.getMinecraft().getTextureManager().bindTexture(new ResourceLocation ("Animeware/background/logo.png"));
	}
	
	private int getColor() {
		if(m.isEnabled()) {
			return new Color(0, 220, 255, 0).getRGB();
		}else {
			return new Color(155, 155, 255, 250).getRGB();
		}

	}
	
	public void onClick(int mouseX, int mouseY, int Button) {
		if(mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y +h) {
			m.toggle();
			System.out.println(m.name);
		}

	}

}
