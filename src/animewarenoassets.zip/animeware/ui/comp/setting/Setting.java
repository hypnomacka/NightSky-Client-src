package animeware.ui.comp.setting;

public class Setting {

	public String name;
	public boolean focused;
	
}
