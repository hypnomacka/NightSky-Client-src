package animeware.ui.comp;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;

import org.lwjgl.opengl.GL11;

import animeware.Animeware;
import animeware.hud.HUDConfigScreen;
import animeware.ui.ClickGUI;
import animeware.ui.ClickGUI2;
import animeware.ui.CosmeticGUI;
import animeware.ui.GuiMultiplayerIngameCGUI;
import animeware.ui.profile.ProfileCGui;
import animeware.util.font.FontUtil;
import animeware.util.render.ColorMode;
import animeware.util.render.DrawUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.server.MinecraftServer;

public class Changelog extends GuiScreen {
	
	@Override
	public void initGui() {
		this.buttonList.add(new HomeCGButton(1, 262, height / 3 - 50, ""));
		this.buttonList.add(new SettingsCGButton(2, 262, height / 3 - 10, ""));
		this.buttonList.add(new CosmeticsCGButton(3, 262, height / 3 + 30, ""));
		this.buttonList.add(new ToggleableCGButton(4, 262, height / 3 + 70, ""));
		this.buttonList.add(new ServersCGButton(5, 262, height / 3 + 110, ""));
		this.buttonList.add(new WebsiteCGButton(6, 262, height / 3 + 150, ""));
		this.buttonList.add(new InfoCGButton(7, 262, height / 3 + 190, ""));
		super.initGui();
	}
	@Override
	protected void actionPerformed(GuiButton button) throws IOException {
		if(button.id == 1) {
			mc.displayGuiScreen(new ClickGUI());
		}
		if(button.id == 2) {
			mc.displayGuiScreen(new HUDConfigScreen());
		}
		if(button.id == 3) {
			mc.displayGuiScreen(new CosmeticGUI(null));
		}
		if(button.id == 4) {
			mc.displayGuiScreen(new ClickGUI2(null));
		}
		if(button.id == 5) {
			mc.displayGuiScreen(new GuiMultiplayerIngameCGUI());
		}
		if(button.id == 6) {
			try {
	 			  Desktop desktop = java.awt.Desktop.getDesktop();
	 			  URI oURL = new URI("http://hynomacka.ddns.net");
	 			  desktop.browse(oURL);
	 			} catch (Exception e) {
	 			  e.printStackTrace();
	 			}
		}
		if(button.id == 7) {
			mc.displayGuiScreen(new Changelog());
		}
		if(button.id == 8) {
			mc.displayGuiScreen(new ClickGUI2(null));
		}
		if(button.id == 9) {
			mc.displayGuiScreen(new ClickGUI());
		}
		if(button.id == 10) {
			mc.displayGuiScreen(new ProfileCGui(null));
		}
	}
	
	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
		GL11.glColor4f(1F, 1F, 1F, 1F);
		Playerdraw(370, 330, 25, 50, 0, mc.thePlayer);		
		ScaledResolution sr = new ScaledResolution(mc);
		DrawUtil.drawRoundedRect(312, 125, sr.getScaledWidth() - 220, sr.getScaledHeight() - 373, 18, ColorMode.getClickGuiMidColor());     //text bg
		DrawUtil.drawRoundedRect(320, 150, sr.getScaledWidth() - 220, sr.getScaledHeight() - 130, 18, ColorMode.getClickGuiColor());       //side		
		DrawUtil.drawRoundedRect(415, 120, sr.getScaledWidth() - 220, sr.getScaledHeight() - 130, 18, ColorMode.getClickGuiColor());      //main bg	
		DrawUtil.drawRoundedRect(420, 125, sr.getScaledWidth() - 225, sr.getScaledHeight() - 135, 18, ColorMode.getClickGuiMidColor());  //main		
		DrawUtil.drawRoundedRect(255, 120, sr.getScaledWidth() - 655, sr.getScaledHeight() - 130, 18, ColorMode.getClickGuiColor());      //second main bg
		DrawUtil.drawRoundedRect(260, 125, sr.getScaledWidth() - 660, sr.getScaledHeight() - 135, 18, ColorMode.getClickGuiMidColor());  //second main
		FontUtil.normal.drawString("Animeware", 340, 135, ColorMode.getRedColor());
		//FontUtil.normal.drawString("A", 340, 135, ColorUtils.astolfoColors(0, 100, 400L));
		//FontUtil.normal.drawString("n", 340 + 7, 135, ColorUtils.astolfoColors(0, 100, 300L));
		//FontUtil.normal.drawString("i", 340 + 13, 135, ColorUtils.astolfoColors(0, 100, 200L));
		//FontUtil.normal.drawString("m", 340 + 15, 135, ColorUtils.astolfoColors(0, 100, 100L));
		//FontUtil.normal.drawString("e", 340 + 23, 135, ColorUtils.astolfoColors(0, 100, 0L));
		//FontUtil.normal.drawString("w", 340 + 29, 135, ColorUtils.astolfoColors(0, 100, -100L));
		//FontUtil.normal.drawString("a", 340 + 36, 135, ColorUtils.astolfoColors(0, 100, -200L));
		//FontUtil.normal.drawString("r", 340 + 42, 135, ColorUtils.astolfoColors(0, 100, -300L));
		//FontUtil.normal.drawString("e", 340 + 46, 135, ColorUtils.astolfoColors(0, 100, -400L));
		FontUtil.normal.drawString("Changelog for "+ Animeware.INSTANCE.NAMEVER, 430, 135, ColorMode.getWhiteColor());
		FontUtil.normal.drawString("-Bug-fixes", 430, 148, ColorMode.getRedColor());
		FontUtil.normal.drawString("", 430, 155, ColorMode.getWhiteColor());
		FontUtil.normal.drawString("-New mods", 430, 158, ColorMode.getRedColor());
		FontUtil.normal.drawString("", 430, 165, ColorMode.getWhiteColor());
		FontUtil.normal.drawString("-Removed second mod page", 430, 168, ColorMode.getRedColor());
		FontUtil.normal.drawString("", 430, 175, ColorMode.getWhiteColor());
		FontUtil.normal.drawString("", 430, 168, ColorMode.getRedColor());
		FontUtil.normal.drawString("", 430, 175, ColorMode.getWhiteColor());
		
		//FontUtil.normal.drawString("-New Mods", 430, 178, ColorMode.getRedColor());
		super.drawScreen(mouseX, mouseY, partialTicks);
	}
	public static void Playerdraw(int posX, int posY, int scale, float mouseX, float mouseY, EntityLivingBase ent)
    {
		if(MinecraftServer.getServer().isSinglePlayer()) {
        GlStateManager.enableColorMaterial();
        GlStateManager.pushMatrix();
        GlStateManager.translate((float)posX, (float)posY, 50.0F);
        GlStateManager.scale((float)(-65), (float)65, (float)65);
        GlStateManager.rotate(180.0F, 0.0F, 0.0F, 1.0F);
        float f = ent.renderYawOffset;
        float f1 = ent.rotationYaw;
        float f2 = ent.rotationPitch;
        float f3 = ent.prevRotationYawHead;
        float f4 = ent.rotationYawHead;
        GlStateManager.rotate(155.0F, 0.0F, 1.0F, 0.0F);
        RenderHelper.enableStandardItemLighting();
        GlStateManager.rotate(-135.0F, 0.0F, 1.0F, 0.0F);
        GlStateManager.rotate(-((float)Math.atan((double)(mouseY / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
        ent.renderYawOffset = (float)Math.atan((double)(mouseX / 40.0F)) * 20.0F;
        ent.rotationYaw = (float)Math.atan((double)(mouseX / 40.0F)) * 40.0F;
        ent.rotationPitch = -((float)Math.atan((double)(mouseY / 40.0F))) * 20.0F;
        ent.rotationYawHead = ent.rotationYaw;
        ent.prevRotationYawHead = ent.rotationYaw;
        GlStateManager.translate(0.0F, 0.0F, 0.0F);
        RenderManager rendermanager = Minecraft.getMinecraft().getRenderManager();
        rendermanager.setPlayerViewY(180.0F);
        rendermanager.setRenderShadow(false);
        rendermanager.renderEntityWithPosYaw(ent, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F);
        rendermanager.setRenderShadow(true);
        ent.renderYawOffset = f;
        ent.rotationYaw = f1;
        ent.rotationPitch = f2;
        ent.prevRotationYawHead = f3;
        ent.rotationYawHead = f4;
        GlStateManager.popMatrix();
        RenderHelper.disableStandardItemLighting();
        GlStateManager.disableRescaleNormal();
        GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
        GlStateManager.disableTexture2D();
        GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
    } else if(Minecraft.getMinecraft().getCurrentServerData() != null) {
    	GlStateManager.enableColorMaterial();
        GlStateManager.pushMatrix();
        GlStateManager.translate((float)posX, (float)posY, 50.0F);
        GlStateManager.scale((float)(-65), (float)65, (float)65);
        GlStateManager.rotate(180.0F, 0.0F, 0.0F, 1.0F);
        float f = ent.renderYawOffset;
        float f1 = ent.rotationYaw;
        float f2 = ent.rotationPitch;
        float f3 = ent.prevRotationYawHead;
        float f4 = ent.rotationYawHead;
        GlStateManager.rotate(155.0F, 0.0F, 1.0F, 0.0F);
        RenderHelper.enableStandardItemLighting();
        GlStateManager.rotate(-135.0F, 0.0F, 1.0F, 0.0F);
        GlStateManager.rotate(-((float)Math.atan((double)(mouseY / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
        ent.renderYawOffset = (float)Math.atan((double)(mouseX / 40.0F)) * 20.0F;
        ent.rotationYaw = (float)Math.atan((double)(mouseX / 40.0F)) * 40.0F;
        ent.rotationPitch = -((float)Math.atan((double)(mouseY / 40.0F))) * 20.0F;
        ent.rotationYawHead = ent.rotationYaw;
        ent.prevRotationYawHead = ent.rotationYaw;
        GlStateManager.translate(0.0F, 0.0F, 0.0F);
        RenderManager rendermanager = Minecraft.getMinecraft().getRenderManager();
        rendermanager.setPlayerViewY(180.0F);
        rendermanager.setRenderShadow(false);
        rendermanager.renderEntityWithPosYaw(ent, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F);
        rendermanager.setRenderShadow(true);
        ent.renderYawOffset = f;
        ent.rotationYaw = f1;
        ent.rotationPitch = f2;
        ent.prevRotationYawHead = f3;
        ent.rotationYawHead = f4;
        GlStateManager.popMatrix();
        RenderHelper.disableStandardItemLighting();
        GlStateManager.disableRescaleNormal();
        GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
        GlStateManager.disableTexture2D();
        GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
	} else {
		
	}
    }

}
