package animeware.ui.login;

import java.awt.Color;
import java.io.IOException;

import org.lwjgl.input.Keyboard;

import animeware.cosmetic.SessionChanger;
import animeware.gui.alt.Alt;
import animeware.gui.alt.AltLoginThread;
import animeware.mainmenu.MainMenu;
import animeware.mainmenu.components.ClassicButton;
import animeware.mainmenu.components.MicrosoftButton;
import animeware.mainmenu.components.QuitButton;
import animeware.util.font.FontUtil;
import animeware.util.render.DrawUtil;
import animeware.util.websockets.SocketClient;
import animeware.util.websockets.user.CheckName;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;

public final class AnimewareLoginScreen extends GuiScreen {
    private PasswordField password;
    private GuiScreen previousScreen;
    //private UserLoginThread thread;
    public static GuiTextField username;
    public AltLoginThread loginThread;
    public Alt selectedAlt = null;
	private AltLoginThread thread;

    public AnimewareLoginScreen() {
        this.previousScreen = previousScreen;
    }

    @Override
    protected void actionPerformed(GuiButton button) {
        switch (button.id) {
            case 0: {
            	//System.out.println(SocketClient.client.request("start_animeware", mc.thePlayer.getGameProfile().getName() + ":true"));
            	//System.out.println(SocketClient.client.request("start_animeware", mc.thePlayer.getGameProfile().getName() + ":owns"));
            	if(this.username.getText() == "" && this.password.getText() == "" || this.username.getText() == " " && this.password.getText() == " ") {
                //this.thread = new AltLoginThread(this.username.getText(), this.password.getText());
                //this.thread.start();
            	} else {
            		this.thread = new AltLoginThread(this.username.getText(), this.password.getText());
                    this.thread.start();
                    CheckName.DoCheckNameOnLogin();
                    }
            	
                break;
            }            
            case 1: {
            	//System.out.println(SocketClient.client.request("start_animeware", mc.thePlayer.getGameProfile().getName() + ":true"));
            	//System.out.println(SocketClient.client.request("start_animeware", mc.thePlayer.getGameProfile().getName() + ":owns"));
            	SessionChanger.getInstance().setUserMicrosoft(this.username.getText(), this.password.getText());
            	break;
            }   
            case 2: {
            	mc.displayGuiScreen(new MainMenu());          
            	break;
            }
    		}
    		
        }
    @Override
    public void initGui() {
        int var3 = height / 4 + 24;
        this.username = new GuiTextField(var3, this.mc.fontRendererObj, width / 2 - 90, 165, 200, 20);
        this.password = new PasswordField(this.mc.fontRendererObj, width / 2 - 90, 200, 200, 20);
        this.buttonList.add(new ClassicButton(0, width / 2 - 90, var3 + 72 + 12, "Login"));
        this.buttonList.add(new MicrosoftButton(1, width / 2 - 65, var3 - 22, "Microsoft Login"));
        this.buttonList.add(new QuitButton(2, width / 2 - 90, var3 - 22, ""));
        //this.buttonList.add(new GuiButton(666, width / 2 - 100, var3 + 72 + 12 + 24, "Back"));
        //this.buttonList.add(new GuiButton(1, 370, height / 2 + 27, "Singleplayer"));

        this.username.setFocused(true);
        Keyboard.enableRepeatEvents(true);
    }
        
    

    @Override
    public void drawScreen(int x2, int y2, float z2) {
        //this.drawDefaultBackground();
    	ScaledResolution sr = new ScaledResolution(mc);
    	GlStateManager.enableAlpha();
		GlStateManager.enableBlend();
    	DrawUtil.drawRoundedRect(325, 90, sr.getScaledWidth() -310, sr.getScaledHeight() - 220, 10, new Color(30, 30, 30, 150).getRGB());
    	
        this.username.drawTextBox();
        this.password.drawTextBox();
        //FontUtil.normal.drawCenteredString("Animeware Client Login", width / 2, 130, -1);
        //FontUtil.normal.drawCenteredString(this.thread == null ? (Object)((Object)EnumChatFormatting.GRAY) + "Idle..." : this.thread.getStatus(), width / 2, 143, -1);
        if (this.username.getText().isEmpty()) {
        	FontUtil.normal.drawString("Mail", width / 2 - 88, 173, -7829368);
        }
        if (this.password.getText().isEmpty()) {
        	FontUtil.normal.drawString("Password", width / 2 - 88, 208, -7829368);
        }
        
        super.drawScreen(x2, y2, z2);
    }

    

    @Override
    protected void keyTyped(char character, int key) {
        try {
            super.keyTyped(character, key);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        if (character == '\t') {
            if (!this.username.isFocused() && !this.password.isFocused()) {
                this.username.setFocused(true);
            } else {
                this.username.setFocused(this.password.isFocused());
                this.password.setFocused(!this.username.isFocused());
            }
        }
        if (character == '\r') {
            this.actionPerformed((GuiButton)this.buttonList.get(0));
        }
        this.username.textboxKeyTyped(character, key);
        this.password.textboxKeyTyped(character, key);
    }

    @Override
    protected void mouseClicked(int x2, int y2, int button) {
        try {
            super.mouseClicked(x2, y2, button);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        this.username.mouseClicked(x2, y2, button);
        this.password.mouseClicked(x2, y2, button);
    }

    @Override
    public void onGuiClosed() {
        Keyboard.enableRepeatEvents(false);
    }

    @Override
    public void updateScreen() {
        this.username.updateCursorCounter();
        this.password.updateCursorCounter();
    }
    
    
}

