package animeware.ui.login.Comp;

import java.awt.Color;
import java.io.IOException;

import org.lwjgl.input.Keyboard;

import animeware.mainmenu.notdoneyet;
import animeware.mainmenu.components.ClassicButton;
import animeware.mainmenu.components.MicrosoftButton;
import animeware.ui.login.PasswordField;
import animeware.ui.login.UserLoginThread;
import animeware.util.font.FontUtil;
import animeware.util.render.DrawUtil;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.gui.ScaledResolution;

public final class AnimewareLoginScreenMic extends GuiScreen {
    private PasswordField password;
    private GuiScreen previousScreen;
    private UserLoginThread thread;
    private GuiTextField username;

    public AnimewareLoginScreenMic() {
        this.previousScreen = previousScreen;
    }

    @Override
    protected void actionPerformed(GuiButton button) {
        switch (button.id) {
            case 0: {
                this.thread = new UserLoginThread(this.username.getText(), this.password.getText());
                this.thread.start();
                break;
            }
            case 1: {
            	mc.displayGuiScreen(new notdoneyet());
            	break;
            }
    		}
    		
        }
    @Override
    public void initGui() {
        int var3 = height / 4 + 24;
        this.username = new GuiTextField(var3, this.mc.fontRendererObj, width / 2 - 110, 165, 200, 20);
        this.password = new PasswordField(this.mc.fontRendererObj, width / 2 - 110, 200, 200, 20);
        this.buttonList.add(new ClassicButton(0, width / 2 - 110, var3 + 72 + 12, "Login"));
        this.buttonList.add(new MicrosoftButton(1, width / 2 - 110, var3 - 22, "Microsoft Login"));
        //this.buttonList.add(new GuiButton(666, width / 2 - 100, var3 + 72 + 12 + 24, "Back"));
        //this.buttonList.add(new GuiButton(1, 370, height / 2 + 27, "Singleplayer"));

        this.username.setFocused(true);
        Keyboard.enableRepeatEvents(true);
    }
        
    

    @Override
    public void drawScreen(int x2, int y2, float z2) {
        //this.drawDefaultBackground();
    	ScaledResolution sr = new ScaledResolution(mc);
    	DrawUtil.drawRoundedRect(290, 90, sr.getScaledWidth() -310, sr.getScaledHeight() - 220, 1, new Color(30, 30, 30, 90).getRGB());
    	
        this.username.drawTextBox();
        this.password.drawTextBox();
        //FontUtil.normal.drawCenteredString("Animeware Client Login", width / 2, 130, -1);
        //FontUtil.normal.drawCenteredString(this.thread == null ? (Object)((Object)EnumChatFormatting.GRAY) + "Idle..." : this.thread.getStatus(), width / 2, 143, -1);
        if (this.username.getText().isEmpty()) {
        	FontUtil.normal.drawString("Username", width / 2 - 96, 173, -7829368);
        }
        if (this.password.getText().isEmpty()) {
        	FontUtil.normal.drawString("Password", width / 2 - 96, 208, -7829368);
        }
        
        super.drawScreen(x2, y2, z2);
    }

    

    @Override
    protected void keyTyped(char character, int key) {
    	
        /*try {
            super.keyTyped(character, key);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        if (character == '\t') {
            if (!this.username.isFocused() && !this.password.isFocused()) {
                this.username.setFocused(true);
            } else {
                this.username.setFocused(this.password.isFocused());
                this.password.setFocused(!this.username.isFocused());
            }
        }
        if (character == '\r') {
            this.actionPerformed((GuiButton)this.buttonList.get(0));
        }
        this.username.textboxKeyTyped(character, key);
        this.password.textboxKeyTyped(character, key);*/
    }

    @Override
    protected void mouseClicked(int x2, int y2, int button) {
        try {
            super.mouseClicked(x2, y2, button);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        this.username.mouseClicked(x2, y2, button);
        this.password.mouseClicked(x2, y2, button);
    }

    @Override
    public void onGuiClosed() {
        Keyboard.enableRepeatEvents(false);
    }

    @Override
    public void updateScreen() {
        this.username.updateCursorCounter();
        this.password.updateCursorCounter();
    }
}

