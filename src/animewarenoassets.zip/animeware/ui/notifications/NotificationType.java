package animeware.ui.notifications;

public enum NotificationType {
    INFO, WARNING, ERROR;
}
