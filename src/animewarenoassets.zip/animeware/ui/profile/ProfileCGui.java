package animeware.ui.profile;

import java.awt.Color;
import java.io.IOException;

import org.lwjgl.opengl.GL11;

import animeware.Animeware;
import animeware.hud.mod.HudMod;
import animeware.ui.ClickGUI;
import animeware.ui.comp.ClickGUIButtonDark;
import animeware.ui.comp.LilButtonCG;
import animeware.ui.comp.XCGButton;
import animeware.util.font.FontUtil;
import animeware.util.render.ColorMode;
import animeware.util.render.DrawUtil;
import animeware.util.render.RoundedUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.server.MinecraftServer;

public class ProfileCGui extends GuiScreen{
	/*     */   private final GuiScreen field_146598_a;
	/*  40 */   private static String Cape = "Cape";
	            private static String QuavCape = "QuavCape";
	/*  41 */   private static String Wings = "Wings";
	/*  42 */   private static String ToggleSprint = "Toggle Sprint";
	/*  43 */   private static String Halo = "Halo";
	/*  44 */   private static String FPS = "FPS";
	/*  45 */   private static String Keystrokes = "Keystrokes";
	/*  46 */   private static String Ping = "Ping";
	/*  47 */   private static String ArmorStatus = "Armor Status";
	/*  48 */   private static String Time = "Time";
	/*  49 */   private static String PotionStatus = "Potion Status";
	/*  50 */   private static String ModPosition = "ModPosition";
	/*     */   
	/*     */   private GuiButton field_146596_f;
	/*     */   
	/*     */   private GuiButton field_146597_g;
	/*     */   
	/*  56 */   private String field_146599_h = "survival";
	/*     */   private boolean field_146600_i;
	
	public int x, y, w, h;
	public HudMod m;
	private boolean enabled;
	/*     */   
	/*     */   public ProfileCGui(GuiScreen p_i1055_1_) {
	/*  60 */     this.field_146598_a = p_i1055_1_;
	/*     */   } 
	/*     */   public void initGui() {
		if(Minecraft.getMinecraft().session.getUsername().equals("hypnomacka")) {
	             if (Animeware.OwnerCape) {
		/*  73 */       this.buttonList.add(new ClickGUIButtonDark(1, this.width / 2 - 51, this.height / 2 - 120, 120, 20, 
		/*  74 */             I18n.format("�4Owner Cape", new Object[0])));
		/*  75 */     } else if (!Animeware.OwnerCape) {
		/*  76 */       this.buttonList.add(new ClickGUIButtonDark(1, this.width / 2 - 51, this.height / 2 - 120, 120, 20, 
		/*  77 */             I18n.format("Owner Cape", new Object[0])));
		/*     */     }
	             if (Animeware.DevCape) {
	         		/*  73 */       this.buttonList.add(new ClickGUIButtonDark(2, this.width / 2 - 51, this.height / 2 - 90, 120, 20, 
	         		/*  74 */             I18n.format("�4Staff Cape", new Object[0])));
	         		/*  75 */     } else if (!Animeware.DevCape) {
	         		/*  76 */       this.buttonList.add(new ClickGUIButtonDark(2, this.width / 2 - 51, this.height / 2 - 90, 120, 20, 
	         		/*  77 */             I18n.format("Staff Cape", new Object[0])));
	         		/*     */     }
	             if (Animeware.YTCape) {
		         		/*  73 */       this.buttonList.add(new ClickGUIButtonDark(3, this.width / 2 - 51, this.height / 2 - 60, 120, 20, 
		         		/*  74 */             I18n.format("�4YT Cape", new Object[0])));
		         		/*  75 */     } else if (!Animeware.YTCape) {
		         		/*  76 */       this.buttonList.add(new ClickGUIButtonDark(3, this.width / 2 - 51, this.height / 2 - 60, 120, 20, 
		         		/*  77 */             I18n.format("YT Cape", new Object[0])));
		         		/*     */     }
		} else if(Minecraft.getMinecraft().session.getUsername().equals("KnownAsR3named")) {
			if (Animeware.DevCape) {
         		/*  73 */       this.buttonList.add(new ClickGUIButtonDark(1, this.width / 2 - 51, this.height / 2 - 120, 120, 20, 
         		/*  74 */             I18n.format("�4Staff Cape", new Object[0])));
         		/*  75 */     } else if (!Animeware.DevCape) {
         		/*  76 */       this.buttonList.add(new ClickGUIButtonDark(1, this.width / 2 - 51, this.height / 2 - 120, 120, 20, 
         		/*  77 */             I18n.format("Staff Cape", new Object[0])));
         		/*     */     }
             
		}else if(Minecraft.getMinecraft().session.getUsername().equals("MartoSVK")) {
			if (Animeware.YTCape) {
         		/*  73 */       this.buttonList.add(new ClickGUIButtonDark(1, this.width / 2 - 51, this.height / 2 - 120, 120, 20, 
         		/*  74 */             I18n.format("�4YT Cape", new Object[0])));
         		/*  75 */     } else if (!Animeware.YTCape) {
         		/*  76 */       this.buttonList.add(new ClickGUIButtonDark(1, this.width / 2 - 51, this.height / 2 - 120, 120, 20, 
         		/*  77 */             I18n.format("YT Cape", new Object[0])));
         		/*     */     }
             
		}
	             
	             
	             
	            this.buttonList.add(new XCGButton(100, this.width / 2 - 188, this.height / 2 - 110, ""));
	     		
	     		
	             
	/*     */     
	/* 132 */     //this.buttonList.add(new GuiButton(1022, this.width / 2 - 91, this.height / 2 + 104, 180, 20, 
	/* 133 */           //I18n.format("", new Object[0]))); 
	/*     */   }
	/*     */   protected void actionPerformed(GuiButton button) throws IOException {
		if(Minecraft.getMinecraft().session.getUsername().equals("hypnomacka")) {
	/*     */     boolean flag, flag1;
	/* 152 */     switch (button.id) { 
	
	/*     */       case 1:
	/* 198 */         Animeware.OwnerCape = !Animeware.OwnerCape;
	/*     */         
	/* 200 */         if (Animeware.OwnerCape) {
	/* 201 */           this.buttonList.set(0, new ClickGUIButtonDark(1, this.width / 2 - 51, this.height / 2 - 120, 120, 20, 
	/* 202 */                 I18n.format("�4Owner Cape", new Object[0])));
	/* 203 */         } else if (!Animeware.OwnerCape) {
	/* 204 */           this.buttonList.set(0, new ClickGUIButtonDark(1, this.width / 2 - 51, this.height / 2 - 120, 120, 20, 
	/* 205 */                 I18n.format("Owner Cape", new Object[0])));
	/*     */         } 
	break;
	                case 2:
	                  Animeware.DevCape = !Animeware.DevCape;
	/*     */         
	/* 200 */         if (Animeware.DevCape) {
	/* 201 */           this.buttonList.set(1, new ClickGUIButtonDark(2, this.width / 2 - 51, this.height / 2 - 90, 120, 20, 
	/* 202 */                 I18n.format("�4Staff Cape", new Object[0])));
	/* 203 */         } else if (!Animeware.DevCape) {
	/* 204 */           this.buttonList.set(1, new ClickGUIButtonDark(2, this.width / 2 - 51, this.height / 2 - 90, 120, 20, 
	/* 205 */                 I18n.format("Staff Cape", new Object[0])));
	/*     */         }
	break;
	                case 3:
		                  Animeware.YTCape = !Animeware.YTCape;
		/*     */         
		/* 200 */         if (Animeware.YTCape) {
		/* 201 */           this.buttonList.set(2, new ClickGUIButtonDark(3, this.width / 2 - 51, this.height / 2 - 60, 120, 20, 
		/* 202 */                 I18n.format("�4YT Cape", new Object[0])));
		/* 203 */         } else if (!Animeware.YTCape) {
		/* 204 */           this.buttonList.set(2, new ClickGUIButtonDark(3, this.width / 2 - 51, this.height / 2 - 60, 120, 20, 
		/* 205 */                 I18n.format("YT Cape", new Object[0])));
		/*     */         }
		break;
	                
	                
	                case 100: 
			mc.displayGuiScreen(new ClickGUI());
		break;
	                
	                
	/*     */ 
	/*     */       
	/*     */        
       case 1022:
         break;
     }  //this.mc.displayGuiScreen(new HUDConfigScreen());
   }else if(Minecraft.getMinecraft().session.getUsername().equals("KnownAsR3named")) {
	   boolean flag, flag1;
		/* 152 */     switch (button.id) {
   case 1:
		/* 198 */         Animeware.DevCape = !Animeware.DevCape;
		/*     */         
		/* 200 */         if (Animeware.DevCape) {
		/* 201 */           this.buttonList.set(0, new ClickGUIButtonDark(1, this.width / 2 - 51, this.height / 2 - 120, 120, 20, 
		/* 202 */                 I18n.format("�4Staff Cape", new Object[0])));
		/* 203 */         } else if (!Animeware.DevCape) {
		/* 204 */           this.buttonList.set(0, new ClickGUIButtonDark(1, this.width / 2 - 51, this.height / 2 - 120, 120, 20, 
		/* 205 */                 I18n.format("Staff Cape", new Object[0])));
		/*     */         } 
		
		break;
   case 100: 
		mc.displayGuiScreen(new ClickGUI());
	break;
		}
   }else if(Minecraft.getMinecraft().session.getUsername().equals("MartoSVK")) {
	   boolean flag, flag1;
		/* 152 */     switch (button.id) {
   case 1:
		/* 198 */         Animeware.YTCape = !Animeware.YTCape;
		/*     */         
		/* 200 */         if (Animeware.YTCape) {
		/* 201 */           this.buttonList.set(0, new ClickGUIButtonDark(1, this.width / 2 - 51, this.height / 2 - 120, 120, 20, 
		/* 202 */                 I18n.format("�4YT Cape", new Object[0])));
		/* 203 */         } else if (!Animeware.YTCape) {
		/* 204 */           this.buttonList.set(0, new ClickGUIButtonDark(1, this.width / 2 - 51, this.height / 2 - 120, 120, 20, 
		/* 205 */                 I18n.format("YT Cape", new Object[0])));
		/*     */         } 
		
		break;
   case 100: 
		mc.displayGuiScreen(new ClickGUI());
	break;
		}
		
   }else if(Minecraft.getMinecraft().session.getUsername().equals(Minecraft.getMinecraft().session.getUsername())) {
	   boolean flag, flag1;
		/* 152 */     switch (button.id) {   
   case 100: 
		mc.displayGuiScreen(new ClickGUI());
	break;
		}}
		
   }
	  
   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
     //drawDefaultBackground();
	 //Minecraft.getMinecraft().entityRenderer.loadShader(new ResourceLocation("shaders/post/blur.json"));
	 		//FontUtil.normal.drawString("Animeware", 340, 135, ColorMode.getWhiteColor()); 
	 		GL11.glColor4f(1F, 1F, 1F, 1F);
	 		//if(MinecraftServer.getServer().isSinglePlayer()) {
	 		//Playerdraw(370, 330, 25, 50, 0, mc.thePlayer);		
	 		ScaledResolution sr = new ScaledResolution(mc);
	 		/*Discord GUI:*/
	 		//DrawUtil.drawRoundedRect(170, 60, sr.getScaledWidth() - 170, sr.getScaledHeight() - 100, 10, ColorMode.getClickGuiColor());
	 		//DrawUtil.drawRoundedRect(200, 75, sr.getScaledWidth() - 460, sr.getScaledHeight() - 100, 12, ColorMode.getClickGuiMidColor());		
	 	    //Gui.drawRect(300, 75, sr.getScaledWidth() - 170, sr.getScaledHeight() - 100, ColorMode.getClickGuiInnerColor());
	 		//Gui.drawRect(195, 105, sr.getScaledWidth() - 170, sr.getScaledHeight() - 410, ColorMode.getClickGuiColor());
	 		
	 		//DrawUtil.drawRoundedRect(200, 115, sr.getScaledWidth() - 665, sr.getScaledHeight() - 375, 13, ColorMode.getClickGuiInnerColor());
	 		//DrawUtil.drawRoundedRect(203, 110, sr.getScaledWidth() - 663, sr.getScaledHeight() - 385, 14, ColorMode.getClickGuiInnerColor());
	 		//DrawUtil.drawRoundedRect(203, 110, sr.getScaledWidth() - 663, sr.getScaledHeight() - 385, 24, ColorMode.getClickGuiInnerColor());
	 		//DrawUtil.drawRoundedRect(203, 110, sr.getScaledWidth() - 663, sr.getScaledHeight() - 385, 14, ColorMode.getClickGuiInnerColor());
	 		//DrawUtil.drawRoundedRect(203, 210, sr.getScaledWidth() - 663, sr.getScaledHeight() - 395, 14, ColorMode.getClickGuiInnerColor());
	 		
	 		/*NetworkPlayerInfo playerinfo =
	 				mc.getNetHandler().getPlayerInfo(player.getUniqueID());
	 		if(playerinfo != null) {
	 			mc.getTextureManager().bindTexture(playerinfo.getLocationSkin());
	 			GL11.glColor4f(1F, 1F, 1F, 1F);
	 			Gui.drawScaledCustomSizeModalRect((int) x -5, (int) y - 5, 8F, 8F, 8 , 8, 20, 20, 64F, 64F);
	 		}*/
	 		
	 		/*DrawUtil.drawRoundedRect(312, 125, sr.getScaledWidth() - 220, sr.getScaledHeight() - 373, 18, ColorMode.getClickGuiMidColor());     //text bg
	 		DrawUtil.drawRoundedRect(320, 150, sr.getScaledWidth() - 220, sr.getScaledHeight() - 130, 18, ColorMode.getClickGuiColor());       //side		
	 		DrawUtil.drawRoundedRect(415, 120, sr.getScaledWidth() - 220, sr.getScaledHeight() - 130, 18, ColorMode.getClickGuiColor());      //main bg	
	 		DrawUtil.drawRoundedRect(420, 125, sr.getScaledWidth() - 225, sr.getScaledHeight() - 135, 18, ColorMode.getClickGuiMidColor());  //main		
	 		DrawUtil.drawRoundedRect(255, 120, sr.getScaledWidth() - 655, sr.getScaledHeight() - 130, 18, ColorMode.getClickGuiColor());      //second main bg
	 		DrawUtil.drawRoundedRect(260, 125, sr.getScaledWidth() - 660, sr.getScaledHeight() - 135, 18, ColorMode.getClickGuiMidColor());  //second main
	 		//GlStateManager.pushMatrix();
	 		//GlStateManager.scale(0.8, 0.8, 0.8);
	 		FontUtil.normal.drawString("Animeware", 340, 135, ColorMode.getRedColor());*/
	 		

	 		RoundedUtils.drawSmoothRoundedRect((this.width / 2 - 190), (this.height / 2 - 110), (this.width / 2 + 190), (this.height / 2 + 110), 18.0F, new Color(25, 25, 30, 255).getRGB());
			RoundedUtils.drawSmoothRoundedRect((this.width / 2 - 190), (this.height / 2 - 110), (this.width / 2 - 150), (this.height / 2 + 110), 18.0F, new Color(50, 50, 55, 155).getRGB());	    
			RoundedUtils.drawSmoothRoundedRect((this.width / 2 + 90), (this.height / 2 - 110), (this.width / 2 + 190), (this.height / 2 + 110), 18.0F, new Color(50, 50, 55, 155).getRGB());
			RoundedUtils.drawSmoothRoundedRect((this.width / 2 - 185), (this.height / 2 - 78), (this.width / 2 - 155), (this.height / 2 - 76), 4.0F, new Color(100, 100, 105, 255).getRGB());
			
			if(MinecraftServer.getServer().isSinglePlayer()) {
				NetworkPlayerInfo playerInfo = mc.getNetHandler().getPlayerInfo(mc.thePlayer.getUniqueID());
				if(playerInfo != null) {
					//mc.getTextureManager().bindTexture(playerInfo.getLocationSkin());
					GL11.glColor4f(1F, 1F, 1F, 1F);
					//Gui.drawScaledCustomSizeModalRect(330, 365, 8F, 8F, 8, 8, 20, 20, 64F, 64F);
				}
				} else if(Minecraft.getMinecraft().getCurrentServerData() != null) {
					NetworkPlayerInfo playerInfo = mc.getNetHandler().getPlayerInfo(mc.thePlayer.getUniqueID());
					if(playerInfo != null) {
						//mc.getTextureManager().bindTexture(playerInfo.getLocationSkin());
						GL11.glColor4f(1F, 1F, 1F, 1F);
						//Gui.drawScaledCustomSizeModalRect(330, 365, 8F, 8F, 8, 8, 20, 20, 64F, 64F);
				}
				} else {
					
				}
			
	 		
	 		//FontUtil.normal.drawString("A", 340, 135, ColorUtils.astolfoColors(0, 100, 400L));
			//FontUtil.normal.drawString("n", 340 + 7, 135, ColorUtils.astolfoColors(0, 100, 300L));
			//FontUtil.normal.drawString("i", 340 + 13, 135, ColorUtils.astolfoColors(0, 100, 200L));
			//FontUtil.normal.drawString("m", 340 + 15, 135, ColorUtils.astolfoColors(0, 100, 100L));
			//FontUtil.normal.drawString("e", 340 + 23, 135, ColorUtils.astolfoColors(0, 100, 0L));
			//FontUtil.normal.drawString("w", 340 + 29, 135, ColorUtils.astolfoColors(0, 100, -100L));
			//FontUtil.normal.drawString("a", 340 + 36, 135, ColorUtils.astolfoColors(0, 100, -200L));
			//FontUtil.normal.drawString("r", 340 + 42, 135, ColorUtils.astolfoColors(0, 100, -300L));
			//FontUtil.normal.drawString("e", 340 + 46, 135, ColorUtils.astolfoColors(0, 100, -400L));
	 		//mc.getTextureManager().bindTexture(new ResourceLocation ("Animeware/text_white.png"));
	 		//this.drawModalRectWithCustomSizedTexture(345, 95, 0, 0, 250, 250, 250, 250);
     
	   FontUtil.normal.drawString( "", this.width / 2 - 31, this.height / 2 - 120, 
         -1);
     super.drawScreen(mouseX, mouseY, partialTicks);		
   }
   public static void Playerdraw(int posX, int posY, int scale, float mouseX, float mouseY, EntityLivingBase ent)
   {
		if(MinecraftServer.getServer().isSinglePlayer()) {
       GlStateManager.enableColorMaterial();
       GlStateManager.pushMatrix();
       GlStateManager.translate((float)posX, (float)posY, 50.0F);
       GlStateManager.scale((float)(-65), (float)65, (float)65);
       GlStateManager.rotate(180.0F, 15.0F, 0.0F, 1.0F);
       float f = ent.renderYawOffset;
       float f1 = ent.rotationYaw;
       float f2 = ent.rotationPitch;
       float f3 = ent.prevRotationYawHead;
       float f4 = ent.rotationYawHead;
       GlStateManager.rotate(155.0F, 0.0F, 1.0F, 0.0F);
       RenderHelper.enableStandardItemLighting();
       GlStateManager.rotate(-135.0F, 0.0F, 1.0F, 0.0F);
       GlStateManager.rotate(-((float)Math.atan((double)(mouseY / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
       ent.renderYawOffset = (float)Math.atan((double)(mouseX / 40.0F)) * 20.0F;
       ent.rotationYaw = (float)Math.atan((double)(mouseX / 40.0F)) * 40.0F;
       ent.rotationPitch = -((float)Math.atan((double)(mouseY / 40.0F))) * 20.0F;
       ent.rotationYawHead = ent.rotationYaw;
       ent.prevRotationYawHead = ent.rotationYaw;
       GlStateManager.translate(0.0F, 0.0F, 0.0F);
       RenderManager rendermanager = Minecraft.getMinecraft().getRenderManager();
       rendermanager.setPlayerViewY(180.0F);
       rendermanager.setRenderShadow(false);
       rendermanager.renderEntityWithPosYaw(ent, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F);
       rendermanager.setRenderShadow(true);
       ent.renderYawOffset = f;
       ent.rotationYaw = f1;
       ent.rotationPitch = f2;
       ent.prevRotationYawHead = f3;
       ent.rotationYawHead = f4;
       GlStateManager.popMatrix();
       RenderHelper.disableStandardItemLighting();
       GlStateManager.disableRescaleNormal();
       GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
       GlStateManager.disableTexture2D();
       GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
   } else if(Minecraft.getMinecraft().getCurrentServerData() != null) {
   	GlStateManager.enableColorMaterial();
       GlStateManager.pushMatrix();
       GlStateManager.translate((float)posX, (float)posY, 50.0F);
       GlStateManager.scale((float)(-65), (float)65, (float)65);
       GlStateManager.rotate(180.0F, 15.0F, 0.0F, 1.0F);
       float f = ent.renderYawOffset;
       float f1 = ent.rotationYaw;
       float f2 = ent.rotationPitch;
       float f3 = ent.prevRotationYawHead;
       float f4 = ent.rotationYawHead;
       GlStateManager.rotate(155.0F, 0.0F, 1.0F, 0.0F);
       RenderHelper.enableStandardItemLighting();
       GlStateManager.rotate(-135.0F, 0.0F, 1.0F, 0.0F);
       GlStateManager.rotate(-((float)Math.atan((double)(mouseY / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
       ent.renderYawOffset = (float)Math.atan((double)(mouseX / 40.0F)) * 20.0F;
       ent.rotationYaw = (float)Math.atan((double)(mouseX / 40.0F)) * 40.0F;
       ent.rotationPitch = -((float)Math.atan((double)(mouseY / 40.0F))) * 20.0F;
       ent.rotationYawHead = ent.rotationYaw;
       ent.prevRotationYawHead = ent.rotationYaw;
       GlStateManager.translate(0.0F, 0.0F, 0.0F);
       RenderManager rendermanager = Minecraft.getMinecraft().getRenderManager();
       rendermanager.setPlayerViewY(180.0F);
       rendermanager.setRenderShadow(false);
       rendermanager.renderEntityWithPosYaw(ent, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F);
       rendermanager.setRenderShadow(true);
       ent.renderYawOffset = f;
       ent.rotationYaw = f1;
       ent.rotationPitch = f2;
       ent.prevRotationYawHead = f3;
       ent.rotationYawHead = f4;
       GlStateManager.popMatrix();
       RenderHelper.disableStandardItemLighting();
       GlStateManager.disableRescaleNormal();
       GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
       GlStateManager.disableTexture2D();
       GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
	} else {
		
	}
   }
   }
	

