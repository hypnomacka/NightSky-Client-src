package animeware.ui;

import java.awt.Color;
import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;

import org.lwjgl.opengl.GL11;

import animeware.Animeware;
import animeware.hud.HUDConfigScreen;
import animeware.hud.mod.HudMod;
import animeware.ui.ClickGUI;
import animeware.ui.comp.Changelog;
import animeware.ui.comp.ClickGUIButtonDark;
import animeware.ui.comp.ClickGUIButtonLightShort;
import animeware.ui.comp.CosmeticsCGButton;
import animeware.ui.comp.HomeCGButton;
import animeware.ui.comp.InfoCGButton;
import animeware.ui.comp.LilButtonCG;
import animeware.ui.comp.LogoButtonWhite;
import animeware.ui.comp.ServersCGButton;
import animeware.ui.comp.SettingsCGButton;
import animeware.ui.comp.ToggleableCGButton;
import animeware.ui.comp.WebsiteCGButton;
import animeware.ui.comp.XCGButton;
import animeware.ui.profile.ProfileCGui;
import animeware.util.font.FontUtil;
import animeware.util.render.ColorMode;
import animeware.util.render.DrawUtil;
import animeware.util.render.RoundedUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.server.MinecraftServer;

public class ClickGUI2 extends GuiScreen{
	/*     */   private final GuiScreen field_146598_a;
	/*  40 */   private static String Cape = "Cape";
	            private static String QuavCape = "QuavCape";
	/*  41 */   private static String Wings = "Wings";
	/*  42 */   private static String ToggleSprint = "Toggle Sprint";
	/*  43 */   private static String Halo = "Halo";
	/*  44 */   private static String FPS = "FPS";
	/*  45 */   private static String Keystrokes = "Keystrokes";
	/*  46 */   private static String Ping = "Ping";
	/*  47 */   private static String ArmorStatus = "Armor Status";
	/*  48 */   private static String Time = "Time";
	/*  49 */   private static String PotionStatus = "Potion Status";
	/*  50 */   private static String ModPosition = "ModPosition";
	/*     */   
	/*     */   private GuiButton field_146596_f;
	/*     */   
	/*     */   private GuiButton field_146597_g;
	/*     */   
	/*  56 */   private String field_146599_h = "survival";
	/*     */   private boolean field_146600_i;
	
	public int x, y, w, h;
	public HudMod m;
	private boolean enabled;
	/*     */   
	/*     */   public ClickGUI2(GuiScreen p_i1055_1_) {
	/*  60 */     this.field_146598_a = p_i1055_1_;
	/*     */   } 
	/*     */   public void initGui() {
		if(Minecraft.getMinecraft().session.getUsername().equals("hypnomacka")) {
	             if (Animeware.OwnerCape) {
		/*  73 */       this.buttonList.add(new ClickGUIButtonDark(1, this.width / 2 - 51, this.height / 2 - 120, 120, 20, 
		/*  74 */             I18n.format("�4Owner Cape", new Object[0])));
		/*  75 */     } else if (!Animeware.OwnerCape) {
		/*  76 */       this.buttonList.add(new ClickGUIButtonDark(1, this.width / 2 - 51, this.height / 2 - 120, 120, 20, 
		/*  77 */             I18n.format("Owner Cape", new Object[0])));
		/*     */     }
	             if (Animeware.DevCape) {
	         		/*  73 */       this.buttonList.add(new ClickGUIButtonDark(2, this.width / 2 - 51, this.height / 2 - 90, 120, 20, 
	         		/*  74 */             I18n.format("�4Staff Cape", new Object[0])));
	         		/*  75 */     } else if (!Animeware.DevCape) {
	         		/*  76 */       this.buttonList.add(new ClickGUIButtonDark(2, this.width / 2 - 51, this.height / 2 - 90, 120, 20, 
	         		/*  77 */             I18n.format("Staff Cape", new Object[0])));
	         		/*     */     }
	             if (Animeware.YTCape) {
		         		/*  73 */       this.buttonList.add(new ClickGUIButtonDark(3, this.width / 2 - 51, this.height / 2 - 60, 120, 20, 
		         		/*  74 */             I18n.format("�4YT Cape", new Object[0])));
		         		/*  75 */     } else if (!Animeware.YTCape) {
		         		/*  76 */       this.buttonList.add(new ClickGUIButtonDark(3, this.width / 2 - 51, this.height / 2 - 60, 120, 20, 
		         		/*  77 */             I18n.format("YT Cape", new Object[0])));
		         		/*     */     }
	             this.buttonList.add(new LogoButtonWhite(0, this.width / 2 - 188, this.height / 2 - 110, ""));
	     		this.buttonList.add(new HomeCGButton(1, this.width / 2 - 188, this.height / 2 - 70, ""));
	     		this.buttonList.add(new SettingsCGButton(2, this.width / 2 - 188, this.height / 2 - 40, ""));
	     		//this.buttonList.add(new ProfileSettingsButton(0, this.width / 2 - 329, this.height / 2 + 200, ""));
	     		this.buttonList.add(new CosmeticsCGButton(3, this.width / 2 - 188, this.height / 2 - 5, ""));
	     		this.buttonList.add(new ToggleableCGButton(4, this.width / 2 - 188, this.height / 2 + 30, ""));
	     		this.buttonList.add(new ServersCGButton(5, this.width / 2 - 188, this.height / 2 + 60, ""));
	     		//this.buttonList.add(new WebsiteCGButton(6, this.width / 2 - 188, this.height / 2 + 150, ""));
	     		//this.buttonList.add(new InfoCGButton(7, this.width / 2 - 188, this.height / 2 + 190, ""));
	     		//this.buttonList.add(new LilButtonCG(10, this.width / 2 - 188, this.height / 2 + 185, ""));
	     		//this.buttonList.add(new ClickGUIButtonLightShort(8, this.width / 2 - 188, this.height / 2 + 195, ">>"));
	     		//this.buttonList.add(new ClickGUIButtonLightShort(9, this.width / 2 - 188, this.height / 2 + 195, "<<"));
		} else if(Minecraft.getMinecraft().session.getUsername().equals("KnownAsR3named")) {
			if (Animeware.DevCape) {
         		/*  73 */       this.buttonList.add(new ClickGUIButtonDark(1, this.width / 2 - 51, this.height / 2 - 120, 120, 20, 
         		/*  74 */             I18n.format("�4Staff Cape", new Object[0])));
         		/*  75 */     } else if (!Animeware.DevCape) {
         		/*  76 */       this.buttonList.add(new ClickGUIButtonDark(1, this.width / 2 - 51, this.height / 2 - 120, 120, 20, 
         		/*  77 */             I18n.format("Staff Cape", new Object[0])));
         		/*     */     }
			this.buttonList.add(new LogoButtonWhite(0, this.width / 2 - 188, this.height / 2 - 110, ""));
			this.buttonList.add(new HomeCGButton(1, this.width / 2 - 188, this.height / 2 - 70, ""));
			this.buttonList.add(new SettingsCGButton(2, this.width / 2 - 188, this.height / 2 - 40, ""));
			//this.buttonList.add(new ProfileSettingsButton(0, this.width / 2 - 329, this.height / 2 + 200, ""));
			this.buttonList.add(new CosmeticsCGButton(3, this.width / 2 - 188, this.height / 2 - 5, ""));
			this.buttonList.add(new ToggleableCGButton(4, this.width / 2 - 188, this.height / 2 + 30, ""));
			this.buttonList.add(new ServersCGButton(5, this.width / 2 - 188, this.height / 2 + 60, ""));
			//this.buttonList.add(new WebsiteCGButton(6, this.width / 2 - 188, this.height / 2 + 150, ""));
			//this.buttonList.add(new InfoCGButton(7, this.width / 2 - 188, this.height / 2 + 190, ""));
			//this.buttonList.add(new LilButtonCG(10, this.width / 2 - 188, this.height / 2 + 185, ""));
			//this.buttonList.add(new ClickGUIButtonLightShort(8, this.width / 2 - 188, this.height / 2 + 195, ">>"));
			//this.buttonList.add(new ClickGUIButtonLightShort(9, this.width / 2 - 188, this.height / 2 + 195, "<<"));
             
		}else if(Minecraft.getMinecraft().session.getUsername().equals("MartoSVK")) {
			if (Animeware.YTCape) {
         		/*  73 */       this.buttonList.add(new ClickGUIButtonDark(1, this.width / 2 - 51, this.height / 2 - 120, 120, 20, 
         		/*  74 */             I18n.format("�4YT Cape", new Object[0])));
         		/*  75 */     } else if (!Animeware.YTCape) {
         		/*  76 */       this.buttonList.add(new ClickGUIButtonDark(1, this.width / 2 - 51, this.height / 2 - 120, 120, 20, 
         		/*  77 */             I18n.format("YT Cape", new Object[0])));
         		/*     */     }
			this.buttonList.add(new LogoButtonWhite(0, this.width / 2 - 188, this.height / 2 - 110, ""));
			this.buttonList.add(new HomeCGButton(1, this.width / 2 - 188, this.height / 2 - 70, ""));
			this.buttonList.add(new SettingsCGButton(2, this.width / 2 - 188, this.height / 2 - 40, ""));
			//this.buttonList.add(new ProfileSettingsButton(0, this.width / 2 - 329, this.height / 2 + 200, ""));
			this.buttonList.add(new CosmeticsCGButton(3, this.width / 2 - 188, this.height / 2 - 5, ""));
			this.buttonList.add(new ToggleableCGButton(4, this.width / 2 - 188, this.height / 2 + 30, ""));
			this.buttonList.add(new ServersCGButton(5, this.width / 2 - 188, this.height / 2 + 60, ""));
			//this.buttonList.add(new WebsiteCGButton(6, this.width / 2 - 188, this.height / 2 + 150, ""));
			//this.buttonList.add(new InfoCGButton(7, this.width / 2 - 188, this.height / 2 + 190, ""));
			//this.buttonList.add(new LilButtonCG(10, this.width / 2 - 188, this.height / 2 + 185, ""));
			//this.buttonList.add(new ClickGUIButtonLightShort(8, this.width / 2 - 188, this.height / 2 + 195, ">>"));
			//this.buttonList.add(new ClickGUIButtonLightShort(9, this.width / 2 - 188, this.height / 2 + 195, "<<"));
             
		}else
	             
	             
	             //opravit tlacitka
	            //this.buttonList.add(new XCGButton(100, 262, height / 3 - 50, ""));
			this.buttonList.add(new LogoButtonWhite(0, this.width / 2 - 188, this.height / 2 - 110, ""));
		this.buttonList.add(new HomeCGButton(100, this.width / 2 - 188, this.height / 2 - 70, ""));
		this.buttonList.add(new SettingsCGButton(200, this.width / 2 - 188, this.height / 2 - 40, ""));
		//this.buttonList.add(new ProfileSettingsButton(0, this.width / 2 - 329, this.height / 2 + 200, ""));
		this.buttonList.add(new CosmeticsCGButton(300, this.width / 2 - 188, this.height / 2 - 5, ""));
		this.buttonList.add(new ToggleableCGButton(400, this.width / 2 - 188, this.height / 2 + 30, ""));
		this.buttonList.add(new ServersCGButton(500, this.width / 2 - 188, this.height / 2 + 60, ""));
		//this.buttonList.add(new WebsiteCGButton(6, this.width / 2 - 188, this.height / 2 + 150, ""));
		//this.buttonList.add(new InfoCGButton(7, this.width / 2 - 188, this.height / 2 + 190, ""));
		//this.buttonList.add(new LilButtonCG(10, this.width / 2 - 188, this.height / 2 + 185, ""));
		//this.buttonList.add(new ClickGUIButtonLightShort(8, this.width / 2 - 188, this.height / 2 + 195, ">>"));
		//this.buttonList.add(new ClickGUIButtonLightShort(9, this.width / 2 - 188, this.height / 2 + 195, "<<"));
	     		
	     		
	             
	/*     */     
	/* 132 */     //this.buttonList.add(new GuiButton(1022, this.width / 2 - 91, this.height / 2 + 104, 180, 20, 
	/* 133 */           //I18n.format("", new Object[0]))); 
	/*     */   }
	/*     */   protected void actionPerformed(GuiButton button) throws IOException {
		if(Minecraft.getMinecraft().session.getUsername().equals("hypnomacka")) {
	/*     */     boolean flag, flag1;
	/* 152 */     switch (button.id) { 
	
	/*     */       case 1:
	/* 198 */         Animeware.OwnerCape = !Animeware.OwnerCape;
	/*     */         
	/* 200 */         if (Animeware.OwnerCape) {
	/* 201 */           this.buttonList.set(0, new ClickGUIButtonDark(1, this.width / 2 - 51, this.height / 2 - 120, 120, 20, 
	/* 202 */                 I18n.format("�4Owner Cape", new Object[0])));
	/* 203 */         } else if (!Animeware.OwnerCape) {
	/* 204 */           this.buttonList.set(0, new ClickGUIButtonDark(1, this.width / 2 - 51, this.height / 2 - 120, 120, 20, 
	/* 205 */                 I18n.format("Owner Cape", new Object[0])));
	/*     */         } 
	break;
	                case 2:
	                  Animeware.DevCape = !Animeware.DevCape;
	/*     */         
	/* 200 */         if (Animeware.DevCape) {
	/* 201 */           this.buttonList.set(1, new ClickGUIButtonDark(2, this.width / 2 - 51, this.height / 2 - 90, 120, 20, 
	/* 202 */                 I18n.format("�4Staff Cape", new Object[0])));
	/* 203 */         } else if (!Animeware.DevCape) {
	/* 204 */           this.buttonList.set(1, new ClickGUIButtonDark(2, this.width / 2 - 51, this.height / 2 - 90, 120, 20, 
	/* 205 */                 I18n.format("Staff Cape", new Object[0])));
	/*     */         }
	break;
	                case 3:
		                  Animeware.YTCape = !Animeware.YTCape;
		/*     */         
		/* 200 */         if (Animeware.YTCape) {
		/* 201 */           this.buttonList.set(2, new ClickGUIButtonDark(3, this.width / 2 - 51, this.height / 2 - 60, 120, 20, 
		/* 202 */                 I18n.format("�4YT Cape", new Object[0])));
		/* 203 */         } else if (!Animeware.YTCape) {
		/* 204 */           this.buttonList.set(2, new ClickGUIButtonDark(3, this.width / 2 - 51, this.height / 2 - 60, 120, 20, 
		/* 205 */                 I18n.format("YT Cape", new Object[0])));
		/*     */         }
		break;
	                
	                
	                case 100: 
	        			mc.displayGuiScreen(new ClickGUI());
	        		break;
	        	                case 200:
	        			mc.displayGuiScreen(new HUDConfigScreen());
	        			break;
	        	                case 300:
	        			mc.displayGuiScreen(new CosmeticGUI(null));
	        			break;
	        	                case 400:
	        			mc.displayGuiScreen(new ClickGUI2(null));
	        			break;
	        	                case 500:
	        			mc.displayGuiScreen(new GuiMultiplayerIngame());
	        			break;
	        		case 600:
	        			try {
	        	 			  Desktop desktop = java.awt.Desktop.getDesktop();
	        	 			  URI oURL = new URI("https://github.com/hypnomacka");
	        	 			  desktop.browse(oURL);
	        	 			} catch (Exception e) {
	        	 			  e.printStackTrace();
	        	 			}
	        			break;
	        		case 700:
	        			mc.displayGuiScreen(new Changelog());
	        			break;
	        		case 800:
	        			mc.displayGuiScreen(new CosmeticGUI2(null));
	        			break;
	        		case 900:
	        				mc.displayGuiScreen(new CosmeticGUI(null));
	        			break;
	        		case 0:
	    				mc.displayGuiScreen(new ProfileCGui(null));
	    			break;
	        	                
	        	/*     */ 
	        	/*     */       
	        	/*     */        
	               case 1022:
	                 break;
     }  //this.mc.displayGuiScreen(new HUDConfigScreen());
   }else if(Minecraft.getMinecraft().session.getUsername().equals("KnownAsR3named")) {
	   boolean flag, flag1;
		/* 152 */     switch (button.id) {
   case 1:
		/* 198 */         Animeware.DevCape = !Animeware.DevCape;
		/*     */         
		/* 200 */         if (Animeware.DevCape) {
		/* 201 */           this.buttonList.set(0, new ClickGUIButtonDark(1, this.width / 2 - 51, this.height / 2 - 120, 120, 20, 
		/* 202 */                 I18n.format("�4Staff Cape", new Object[0])));
		/* 203 */         } else if (!Animeware.DevCape) {
		/* 204 */           this.buttonList.set(0, new ClickGUIButtonDark(1, this.width / 2 - 51, this.height / 2 - 120, 120, 20, 
		/* 205 */                 I18n.format("Staff Cape", new Object[0])));
		/*     */         } 
		
		break;
   case 100: 
		mc.displayGuiScreen(new ClickGUI());
	break;
               case 200:
		mc.displayGuiScreen(new HUDConfigScreen());
		break;
               case 300:
		mc.displayGuiScreen(new CosmeticGUI(null));
		break;
               case 400:
		mc.displayGuiScreen(new ClickGUI2(null));
		break;
               case 500:
		mc.displayGuiScreen(new GuiMultiplayerIngame());
		break;
	case 600:
		try {
			  Desktop desktop = java.awt.Desktop.getDesktop();
			  URI oURL = new URI("https://github.com/hypnomacka");
			  desktop.browse(oURL);
			} catch (Exception e) {
			  e.printStackTrace();
			}
		break;
	case 700:
		mc.displayGuiScreen(new Changelog());
		break;
	case 800:
		mc.displayGuiScreen(new CosmeticGUI2(null));
		break;
	case 900:
			mc.displayGuiScreen(new CosmeticGUI(null));
		break;
	case 0:
		mc.displayGuiScreen(new ProfileCGui(null));
	break;
               
/*     */ 
/*     */       
/*     */        
  case 1022:
    break;
	
		}
   }else if(Minecraft.getMinecraft().session.getUsername().equals("MartoSVK")) {
	   boolean flag, flag1;
		/* 152 */     switch (button.id) {
   case 1:
		/* 198 */         Animeware.YTCape = !Animeware.YTCape;
		/*     */         
		/* 200 */         if (Animeware.YTCape) {
		/* 201 */           this.buttonList.set(0, new ClickGUIButtonDark(1, this.width / 2 - 51, this.height / 2 - 120, 120, 20, 
		/* 202 */                 I18n.format("�4YT Cape", new Object[0])));
		/* 203 */         } else if (!Animeware.YTCape) {
		/* 204 */           this.buttonList.set(0, new ClickGUIButtonDark(1, this.width / 2 - 51, this.height / 2 - 120, 120, 20, 
		/* 205 */                 I18n.format("YT Cape", new Object[0])));
		/*     */         } 
		
		break;
   case 100: 
		mc.displayGuiScreen(new ClickGUI());
	break;
               case 200:
		mc.displayGuiScreen(new HUDConfigScreen());
		break;
               case 300:
		mc.displayGuiScreen(new CosmeticGUI(null));
		break;
               case 400:
		mc.displayGuiScreen(new ClickGUI2(null));
		break;
               case 500:
		mc.displayGuiScreen(new GuiMultiplayerIngame());
		break;
	case 600:
		try {
			  Desktop desktop = java.awt.Desktop.getDesktop();
			  URI oURL = new URI("https://github.com/hypnomacka");
			  desktop.browse(oURL);
			} catch (Exception e) {
			  e.printStackTrace();
			}
		break;
	case 700:
		mc.displayGuiScreen(new Changelog());
		break;
	case 800:
		mc.displayGuiScreen(new CosmeticGUI2(null));
		break;
	case 900:
			mc.displayGuiScreen(new CosmeticGUI(null));
		break;
	case 0:
		mc.displayGuiScreen(new ProfileCGui(null));
	break;
               
/*     */ 
/*     */       
/*     */        
  case 1022:
    break;
		}
		
   }else if(Minecraft.getMinecraft().session.getUsername().equals(Minecraft.getMinecraft().session.getUsername())) {
	   boolean flag, flag1;
		/* 152 */     switch (button.id) {   
		case 100: 
			mc.displayGuiScreen(new ClickGUI());
		break;
	                case 200:
			mc.displayGuiScreen(new HUDConfigScreen());
			break;
	                case 300:
			mc.displayGuiScreen(new CosmeticGUI(null));
			break;
	                case 400:
			mc.displayGuiScreen(new ClickGUI2(null));
			break;
	                case 500:
			mc.displayGuiScreen(new GuiMultiplayerIngame());
			break;
		case 600:
			try {
	 			  Desktop desktop = java.awt.Desktop.getDesktop();
	 			  URI oURL = new URI("http://hypnomacka.ddns.net");
	 			  desktop.browse(oURL);
	 			} catch (Exception e) {
	 			  e.printStackTrace();
	 			}
			break;
		case 700:
			mc.displayGuiScreen(new Changelog());
			break;
		case 800:
			mc.displayGuiScreen(new CosmeticGUI2(null));
			break;
		case 900:
				mc.displayGuiScreen(new CosmeticGUI(null));
			break;
		case 0:
			mc.displayGuiScreen(new ProfileCGui(null));
		break;
	                
	/*     */ 
	/*     */       
	/*     */        
       case 1022:
         break;
		}}
		
   }
	  
   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
     //drawDefaultBackground();
	 //Minecraft.getMinecraft().entityRenderer.loadShader(new ResourceLocation("shaders/post/blur.json"));
	 		//FontUtil.normal.drawString("Animeware", 340, 135, ColorMode.getWhiteColor()); 
	 		GL11.glColor4f(1F, 1F, 1F, 1F);
	 		//if(MinecraftServer.getServer().isSinglePlayer()) {
	 		//Playerdraw(370, 330, 25, 50, 0, mc.thePlayer);		
	 		ScaledResolution sr = new ScaledResolution(mc);
	 		/*Discord GUI:*/
	 		//DrawUtil.drawRoundedRect(170, 60, sr.getScaledWidth() - 170, sr.getScaledHeight() - 100, 10, ColorMode.getClickGuiColor());
	 		//DrawUtil.drawRoundedRect(200, 75, sr.getScaledWidth() - 460, sr.getScaledHeight() - 100, 12, ColorMode.getClickGuiMidColor());		
	 	    //Gui.drawRect(300, 75, sr.getScaledWidth() - 170, sr.getScaledHeight() - 100, ColorMode.getClickGuiInnerColor());
	 		//Gui.drawRect(195, 105, sr.getScaledWidth() - 170, sr.getScaledHeight() - 410, ColorMode.getClickGuiColor());
	 		
	 		//DrawUtil.drawRoundedRect(200, 115, sr.getScaledWidth() - 665, sr.getScaledHeight() - 375, 13, ColorMode.getClickGuiInnerColor());
	 		//DrawUtil.drawRoundedRect(203, 110, sr.getScaledWidth() - 663, sr.getScaledHeight() - 385, 14, ColorMode.getClickGuiInnerColor());
	 		//DrawUtil.drawRoundedRect(203, 110, sr.getScaledWidth() - 663, sr.getScaledHeight() - 385, 24, ColorMode.getClickGuiInnerColor());
	 		//DrawUtil.drawRoundedRect(203, 110, sr.getScaledWidth() - 663, sr.getScaledHeight() - 385, 14, ColorMode.getClickGuiInnerColor());
	 		//DrawUtil.drawRoundedRect(203, 210, sr.getScaledWidth() - 663, sr.getScaledHeight() - 395, 14, ColorMode.getClickGuiInnerColor());
	 		
	 		/*NetworkPlayerInfo playerinfo =
	 				mc.getNetHandler().getPlayerInfo(player.getUniqueID());
	 		if(playerinfo != null) {
	 			mc.getTextureManager().bindTexture(playerinfo.getLocationSkin());
	 			GL11.glColor4f(1F, 1F, 1F, 1F);
	 			Gui.drawScaledCustomSizeModalRect((int) x -5, (int) y - 5, 8F, 8F, 8 , 8, 20, 20, 64F, 64F);
	 		}*/
	 		

	 		RoundedUtils.drawSmoothRoundedRect((this.width / 2 - 190), (this.height / 2 - 110), (this.width / 2 + 190), (this.height / 2 + 110), 18.0F, new Color(25, 25, 30, 255).getRGB());
			RoundedUtils.drawSmoothRoundedRect((this.width / 2 - 190), (this.height / 2 - 110), (this.width / 2 - 150), (this.height / 2 + 110), 18.0F, new Color(50, 50, 55, 155).getRGB());	    
			RoundedUtils.drawSmoothRoundedRect((this.width / 2 + 90), (this.height / 2 - 110), (this.width / 2 + 190), (this.height / 2 + 110), 18.0F, new Color(50, 50, 55, 155).getRGB());
			RoundedUtils.drawSmoothRoundedRect((this.width / 2 - 185), (this.height / 2 - 78), (this.width / 2 - 155), (this.height / 2 - 76), 4.0F, new Color(100, 100, 105, 255).getRGB());
			
			if(MinecraftServer.getServer().isSinglePlayer()) {
				NetworkPlayerInfo playerInfo = mc.getNetHandler().getPlayerInfo(mc.thePlayer.getUniqueID());
				if(playerInfo != null) {
					//mc.getTextureManager().bindTexture(playerInfo.getLocationSkin());
					GL11.glColor4f(1F, 1F, 1F, 1F);
					//Gui.drawScaledCustomSizeModalRect(330, 365, 8F, 8F, 8, 8, 20, 20, 64F, 64F);
				}
				} else if(Minecraft.getMinecraft().getCurrentServerData() != null) {
					NetworkPlayerInfo playerInfo = mc.getNetHandler().getPlayerInfo(mc.thePlayer.getUniqueID());
					if(playerInfo != null) {
						//mc.getTextureManager().bindTexture(playerInfo.getLocationSkin());
						GL11.glColor4f(1F, 1F, 1F, 1F);
						//Gui.drawScaledCustomSizeModalRect(330, 365, 8F, 8F, 8, 8, 20, 20, 64F, 64F);
				}
				} else {
					
				}
			
	 		//FontUtil.normal.drawString("A", 340, 135, ColorUtils.astolfoColors(0, 100, 400L));
			//FontUtil.normal.drawString("n", 340 + 7, 135, ColorUtils.astolfoColors(0, 100, 300L));
			//FontUtil.normal.drawString("i", 340 + 13, 135, ColorUtils.astolfoColors(0, 100, 200L));
			//FontUtil.normal.drawString("m", 340 + 15, 135, ColorUtils.astolfoColors(0, 100, 100L));
			//FontUtil.normal.drawString("e", 340 + 23, 135, ColorUtils.astolfoColors(0, 100, 0L));
			//FontUtil.normal.drawString("w", 340 + 29, 135, ColorUtils.astolfoColors(0, 100, -100L));
			//FontUtil.normal.drawString("a", 340 + 36, 135, ColorUtils.astolfoColors(0, 100, -200L));
			//FontUtil.normal.drawString("r", 340 + 42, 135, ColorUtils.astolfoColors(0, 100, -300L));
			//FontUtil.normal.drawString("e", 340 + 46, 135, ColorUtils.astolfoColors(0, 100, -400L));
	 		//mc.getTextureManager().bindTexture(new ResourceLocation ("Animeware/text_white.png"));
	 		//this.drawModalRectWithCustomSizedTexture(345, 95, 0, 0, 250, 250, 250, 250);
     
	   FontUtil.normal.drawString( "", this.width / 2 - 31, this.height / 2 - 120, 
         -1);
     super.drawScreen(mouseX, mouseY, partialTicks);		
   }
   public static void Playerdraw(int posX, int posY, int scale, float mouseX, float mouseY, EntityLivingBase ent)
   {
		if(MinecraftServer.getServer().isSinglePlayer()) {
       GlStateManager.enableColorMaterial();
       GlStateManager.pushMatrix();
       GlStateManager.translate((float)posX, (float)posY, 50.0F);
       GlStateManager.scale((float)(-65), (float)65, (float)65);
       GlStateManager.rotate(180.0F, 15.0F, 0.0F, 1.0F);
       float f = ent.renderYawOffset;
       float f1 = ent.rotationYaw;
       float f2 = ent.rotationPitch;
       float f3 = ent.prevRotationYawHead;
       float f4 = ent.rotationYawHead;
       GlStateManager.rotate(155.0F, 0.0F, 1.0F, 0.0F);
       RenderHelper.enableStandardItemLighting();
       GlStateManager.rotate(-135.0F, 0.0F, 1.0F, 0.0F);
       GlStateManager.rotate(-((float)Math.atan((double)(mouseY / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
       ent.renderYawOffset = (float)Math.atan((double)(mouseX / 40.0F)) * 20.0F;
       ent.rotationYaw = (float)Math.atan((double)(mouseX / 40.0F)) * 40.0F;
       ent.rotationPitch = -((float)Math.atan((double)(mouseY / 40.0F))) * 20.0F;
       ent.rotationYawHead = ent.rotationYaw;
       ent.prevRotationYawHead = ent.rotationYaw;
       GlStateManager.translate(0.0F, 0.0F, 0.0F);
       RenderManager rendermanager = Minecraft.getMinecraft().getRenderManager();
       rendermanager.setPlayerViewY(180.0F);
       rendermanager.setRenderShadow(false);
       rendermanager.renderEntityWithPosYaw(ent, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F);
       rendermanager.setRenderShadow(true);
       ent.renderYawOffset = f;
       ent.rotationYaw = f1;
       ent.rotationPitch = f2;
       ent.prevRotationYawHead = f3;
       ent.rotationYawHead = f4;
       GlStateManager.popMatrix();
       RenderHelper.disableStandardItemLighting();
       GlStateManager.disableRescaleNormal();
       GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
       GlStateManager.disableTexture2D();
       GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
   } else if(Minecraft.getMinecraft().getCurrentServerData() != null) {
   	GlStateManager.enableColorMaterial();
       GlStateManager.pushMatrix();
       GlStateManager.translate((float)posX, (float)posY, 50.0F);
       GlStateManager.scale((float)(-65), (float)65, (float)65);
       GlStateManager.rotate(180.0F, 15.0F, 0.0F, 1.0F);
       float f = ent.renderYawOffset;
       float f1 = ent.rotationYaw;
       float f2 = ent.rotationPitch;
       float f3 = ent.prevRotationYawHead;
       float f4 = ent.rotationYawHead;
       GlStateManager.rotate(155.0F, 0.0F, 1.0F, 0.0F);
       RenderHelper.enableStandardItemLighting();
       GlStateManager.rotate(-135.0F, 0.0F, 1.0F, 0.0F);
       GlStateManager.rotate(-((float)Math.atan((double)(mouseY / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
       ent.renderYawOffset = (float)Math.atan((double)(mouseX / 40.0F)) * 20.0F;
       ent.rotationYaw = (float)Math.atan((double)(mouseX / 40.0F)) * 40.0F;
       ent.rotationPitch = -((float)Math.atan((double)(mouseY / 40.0F))) * 20.0F;
       ent.rotationYawHead = ent.rotationYaw;
       ent.prevRotationYawHead = ent.rotationYaw;
       GlStateManager.translate(0.0F, 0.0F, 0.0F);
       RenderManager rendermanager = Minecraft.getMinecraft().getRenderManager();
       rendermanager.setPlayerViewY(180.0F);
       rendermanager.setRenderShadow(false);
       rendermanager.renderEntityWithPosYaw(ent, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F);
       rendermanager.setRenderShadow(true);
       ent.renderYawOffset = f;
       ent.rotationYaw = f1;
       ent.rotationPitch = f2;
       ent.prevRotationYawHead = f3;
       ent.rotationYawHead = f4;
       GlStateManager.popMatrix();
       RenderHelper.disableStandardItemLighting();
       GlStateManager.disableRescaleNormal();
       GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
       GlStateManager.disableTexture2D();
       GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
	} else {
		
	}
   }
   }
	

