package animeware.cosmetic.impl;

import animeware.Animeware;
import animeware.cosmetic.CapeChecker;
import animeware.cosmetic.Cosmetic;
import animeware.cosmetic.ServerShitCapes;
import animeware.ui.comp.ClickGUIButtonDark;
import animeware.util.render.AnimatedResourceLocation;
import animeware.util.websockets.SocketClient;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.EnumPlayerModelParts;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;

public class Cape extends Cosmetic
{
	public AnimatedResourceLocation gif;
	
    private final RenderPlayer playerRenderer;

    public Cape(RenderPlayer renderPlayer) {
    	super("ZeroTwo Cape", true, renderPlayer);
    	this.playerRenderer = renderPlayer;
    }
    
    
    public boolean shouldCombineTextures()
    {
        return false;
    }   
    	  
    
	@Override
	public void render(AbstractClientPlayer entitylivingbaseIn, float limbSwing, float limbSwingAmount, float partialTicks,
			float ageInTicks, float netHeadYaw, float headPitch, float scale) {
		gif = new AnimatedResourceLocation("Animeware/cosmetic/capes/anim/lightning", 10, 5);
		if (entitylivingbaseIn.hasPlayerInfo() && !entitylivingbaseIn.isInvisible() && entitylivingbaseIn.isWearing(EnumPlayerModelParts.CAPE)/* && CapeChecker.ownsZeroTwoCape(entitylivingbaseIn)*/)
        {
			//gif = new AnimatedResourceLocation("Animeware/cosmetic/capes/anim/lightning", 10, 5);
        	//if(CosmeticController.shouldZeroTwoCape(entitylivingbaseIn) && entitylivingbaseIn == Minecraft.getMinecraft().thePlayer) {
            GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
            //if (Animeware.QuickCape && ServerShitCapes.isWearingCape1(((AbstractClientPlayer) entitylivingbaseIn).getGameProfile().getName())) {
            if (Animeware.QuickCape && CapeChecker.ownsZeroTwoCape(entitylivingbaseIn)) {
                this.playerRenderer.bindTexture(new ResourceLocation("Animeware/cosmetic/capes/quick.png"));
              } else if (Animeware.PlanetsCape && CapeChecker.ownsZeroTwoCape(entitylivingbaseIn)) {
                this.playerRenderer.bindTexture(new ResourceLocation("Animeware/cosmetic/capes/planetscape.png"));
              } else if (Animeware.QuavCape && CapeChecker.ownsZeroTwoCape(entitylivingbaseIn)) {
                this.playerRenderer.bindTexture(new ResourceLocation("Animeware/cosmetic/capes/quav_cape.png"));
              } else if (Animeware.ReptyllCape && CapeChecker.ownsZeroTwoCape(entitylivingbaseIn)) {
                this.playerRenderer.bindTexture(new ResourceLocation("Animeware/cosmetic/capes/reptyll.png"));
              } else if (Animeware.SwordCape && CapeChecker.ownsZeroTwoCape(entitylivingbaseIn)) {
                this.playerRenderer.bindTexture(new ResourceLocation("Animeware/cosmetic/capes/swordcape.png"));
              } else if (Animeware.EmeraldCape && CapeChecker.ownsZeroTwoCape(entitylivingbaseIn)) {
                this.playerRenderer.bindTexture(new ResourceLocation("Animeware/cosmetic/capes/emeraldcape.png"));
              } else if (Animeware.LCape && CapeChecker.ownsZeroTwoCape(entitylivingbaseIn)) {
                this.playerRenderer.bindTexture(new ResourceLocation("Animeware/cosmetic/capes/lcape.png"));
              } else if (Animeware.NitroCape && CapeChecker.ownsZeroTwoCape(entitylivingbaseIn)) {
                this.playerRenderer.bindTexture(new ResourceLocation("Animeware/cosmetic/capes/nitro.png"));
              } else if (Animeware.DarkCape && CapeChecker.ownsZeroTwoCape(entitylivingbaseIn)) {
                this.playerRenderer.bindTexture(new ResourceLocation("Animeware/cosmetic/capes/darkcape.png"));
              } else if (Animeware.Cape && CapeChecker.ownsZeroTwoCape(entitylivingbaseIn)) {
                this.playerRenderer.bindTexture(new ResourceLocation("Animeware/cosmetic/capes/cape.png"));
              } else if (Animeware.YTCape && (boolean)SocketClient.isPurple(((AbstractClientPlayer) entitylivingbaseIn).getGameProfile().getName())) {
                this.playerRenderer.bindTexture(new ResourceLocation("Animeware/cosmetic/capes/yt.png"));
              } else if (Animeware.DevCape && (boolean)SocketClient.isDev(((AbstractClientPlayer) entitylivingbaseIn).getGameProfile().getName())) {
                this.playerRenderer.bindTexture(new ResourceLocation("Animeware/cosmetic/capes/devcape.png"));
              } else if (Animeware.OwnerCape && (boolean)SocketClient.isOwner(((AbstractClientPlayer) entitylivingbaseIn).getGameProfile().getName())) {
                this.playerRenderer.bindTexture(new ResourceLocation("Animeware/cosmetic/capes/ownercape.png"));
              } else if (Animeware.GradientBlack && CapeChecker.ownsZeroTwoCape(entitylivingbaseIn)) {
                this.playerRenderer.bindTexture(new ResourceLocation("Animeware/cosmetic/capes/gradientblack.png"));
              } else if (Animeware.GradientBlue && CapeChecker.ownsZeroTwoCape(entitylivingbaseIn)) {
                this.playerRenderer.bindTexture(new ResourceLocation("Animeware/cosmetic/capes/gradientblue.png"));
              } else if (Animeware.GradientGreen && CapeChecker.ownsZeroTwoCape(entitylivingbaseIn)) {
                this.playerRenderer.bindTexture(new ResourceLocation("Animeware/cosmetic/capes/gradientgreen.png"));
              } else if (Animeware.GradientPurple && CapeChecker.ownsZeroTwoCape(entitylivingbaseIn)) {
                this.playerRenderer.bindTexture(new ResourceLocation("Animeware/cosmetic/capes/gradientpurple.png"));
              } else if (Animeware.GradientRed && CapeChecker.ownsZeroTwoCape(entitylivingbaseIn)) {
                this.playerRenderer.bindTexture(new ResourceLocation("Animeware/cosmetic/capes/gradientred.png"));
              } else if (Animeware.tanjirocape && CapeChecker.ownsZeroTwoCape(entitylivingbaseIn)) {
                this.playerRenderer.bindTexture(new ResourceLocation("Animeware/cosmetic/capes/tanjirocape.png"));
              } else if (Animeware.kocho2cape && CapeChecker.ownsZeroTwoCape(entitylivingbaseIn)) {
                this.playerRenderer.bindTexture(new ResourceLocation("Animeware/cosmetic/capes/kocho2cape.png"));
              } else if (Animeware.kocho3cape && CapeChecker.ownsZeroTwoCape(entitylivingbaseIn)) {
                this.playerRenderer.bindTexture(new ResourceLocation("Animeware/cosmetic/capes/kocho3cape.png"));
              } else if (Animeware.dseyes2cape && CapeChecker.ownsZeroTwoCape(entitylivingbaseIn)) {
                this.playerRenderer.bindTexture(new ResourceLocation("Animeware/cosmetic/capes/dseyes2cape.png"));
              } else if (Animeware.dseyescape && CapeChecker.ownsZeroTwoCape(entitylivingbaseIn)) {
                this.playerRenderer.bindTexture(new ResourceLocation("Animeware/cosmetic/capes/dseyescape.png"));
              } else if (Animeware.wintercape && CapeChecker.ownsZeroTwoCape(entitylivingbaseIn)) {
                this.playerRenderer.bindTexture(new ResourceLocation("Animeware/cosmetic/capes/wintercape.png"));
              } else {
                this.playerRenderer.bindTexture(new ResourceLocation("Animeware/cosmetic/capes/blank.png"));
              }
            GlStateManager.pushMatrix();
            GlStateManager.translate(0.0F, 0.0F, 0.125F);
            double d0 = entitylivingbaseIn.prevChasingPosX + (entitylivingbaseIn.chasingPosX - entitylivingbaseIn.prevChasingPosX) * (double)partialTicks - (entitylivingbaseIn.prevPosX + (entitylivingbaseIn.posX - entitylivingbaseIn.prevPosX) * (double)partialTicks);
            double d1 = entitylivingbaseIn.prevChasingPosY + (entitylivingbaseIn.chasingPosY - entitylivingbaseIn.prevChasingPosY) * (double)partialTicks - (entitylivingbaseIn.prevPosY + (entitylivingbaseIn.posY - entitylivingbaseIn.prevPosY) * (double)partialTicks);
            double d2 = entitylivingbaseIn.prevChasingPosZ + (entitylivingbaseIn.chasingPosZ - entitylivingbaseIn.prevChasingPosZ) * (double)partialTicks - (entitylivingbaseIn.prevPosZ + (entitylivingbaseIn.posZ - entitylivingbaseIn.prevPosZ) * (double)partialTicks);
            float f = entitylivingbaseIn.prevRenderYawOffset + (entitylivingbaseIn.renderYawOffset - entitylivingbaseIn.prevRenderYawOffset) * partialTicks;
            double d3 = (double)MathHelper.sin(f * (float)Math.PI / 180.0F);
            double d4 = (double)(-MathHelper.cos(f * (float)Math.PI / 180.0F));
            float f1 = (float)d1 * 10.0F;
            f1 = MathHelper.clamp_float(f1, -6.0F, 32.0F);
            float f2 = (float)(d0 * d3 + d2 * d4) * 100.0F;
            float f3 = (float)(d0 * d4 - d2 * d3) * 100.0F;

            if (f2 < 0.0F)
            {
                f2 = 0.0F;
            }

            float f4 = entitylivingbaseIn.prevCameraYaw + (entitylivingbaseIn.cameraYaw - entitylivingbaseIn.prevCameraYaw) * partialTicks;
            f1 = f1 + MathHelper.sin((entitylivingbaseIn.prevDistanceWalkedModified + (entitylivingbaseIn.distanceWalkedModified - entitylivingbaseIn.prevDistanceWalkedModified) * partialTicks) * 6.0F) * 32.0F * f4;

            if (entitylivingbaseIn.isSneaking())
            {
                f1 += 25.0F;
            }
            if (entitylivingbaseIn.isSneaking())
            {
                //f1 += 25.0F;
                GlStateManager.translate(0.0F, 0.142F, -0.0178F);
                //GlStateManager.translate(0.0F, 0.0F, 0.0F);
            }

            GlStateManager.rotate(6.0F + f2 / 2.0F + f1, 1.0F, 0.0F, 0.0F);
            GlStateManager.rotate(f3 / 2.0F, 0.0F, 0.0F, 1.0F);
            GlStateManager.rotate(-f3 / 2.0F, 0.0F, 1.0F, 0.0F);
            GlStateManager.rotate(180.0F, 0.0F, 1.0F, 0.0F);
            this.playerRenderer.getMainModel().renderCape(0.0625F);
            GlStateManager.popMatrix();
        	}
        }
	}
