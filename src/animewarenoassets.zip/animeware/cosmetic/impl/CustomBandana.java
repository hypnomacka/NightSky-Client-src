package animeware.cosmetic.impl;

public class CustomBandana {

}
