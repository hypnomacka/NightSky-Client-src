package animeware.cosmetic.impl.CosmeticMods;

import animeware.Animeware;
import animeware.cosmetic.CosmeticModule;
import animeware.hud.mod.HudMod;
import net.minecraft.util.ResourceLocation;

public class Halo extends CosmeticModule {

	public Halo() {
		super("Halo", new ResourceLocation("Animeware/icons/blank.png"));
	}
	@Override
	public void onEnable() {
       Animeware.Halo = true;
		//super.onEnable();
	}
	@Override
	public void onDisable() {
	  Animeware.Halo = false;
		//super.onDisable();
	}

}
