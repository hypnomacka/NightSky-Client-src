package animeware.cosmetic.impl.CosmeticMods;

import animeware.Animeware;
import animeware.cosmetic.CosmeticModule;
import animeware.hud.mod.HudMod;
import net.minecraft.util.ResourceLocation;

public class kocho3cape extends CosmeticModule {

	public kocho3cape() {
		super("Kocho Cape 2", new ResourceLocation("Animeware/icons/cape.png"));
	}
	@Override
	public void onEnable() {
       Animeware.kocho3cape = true;
		//super.onEnable();
	}
	@Override
	public void onDisable() {
	  Animeware.kocho3cape = false;
		//super.onDisable();
	}

}
