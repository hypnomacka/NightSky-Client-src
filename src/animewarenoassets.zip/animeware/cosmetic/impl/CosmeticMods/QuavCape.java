package animeware.cosmetic.impl.CosmeticMods;

import animeware.Animeware;
import animeware.cosmetic.CosmeticModule;
import animeware.hud.mod.HudMod;
import net.minecraft.util.ResourceLocation;

public class QuavCape extends CosmeticModule {

	public QuavCape() {
		super("Quav Cape", new ResourceLocation("Animeware/icons/cape.png"));
	}
	@Override
	public void onEnable() {
       Animeware.QuavCape = true;
		//super.onEnable();
	}
	@Override
	public void onDisable() {
	  Animeware.QuavCape = false;
		//super.onDisable();
	}

}
