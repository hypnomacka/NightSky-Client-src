package animeware.cosmetic.impl.CosmeticMods;

import animeware.Animeware;
import animeware.cosmetic.CosmeticModule;
import animeware.hud.mod.HudMod;
import net.minecraft.util.ResourceLocation;

public class dseyes2cape extends CosmeticModule {

	public dseyes2cape() {
		super("Demon eyes Cape", new ResourceLocation("Animeware/icons/cape.png"));
	}
	@Override
	public void onEnable() {
       Animeware.dseyes2cape = true;
		//super.onEnable();
	}
	@Override
	public void onDisable() {
	  Animeware.dseyes2cape = false;
		//super.onDisable();
	}

}
