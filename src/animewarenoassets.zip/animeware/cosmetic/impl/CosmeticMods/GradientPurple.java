package animeware.cosmetic.impl.CosmeticMods;

import animeware.Animeware;
import animeware.cosmetic.CosmeticModule;
import animeware.hud.mod.HudMod;
import net.minecraft.util.ResourceLocation;

public class GradientPurple extends CosmeticModule {

	public GradientPurple() {
		super("GradientPurple Cape", new ResourceLocation("Animeware/icons/cape.png"));
	}
	@Override
	public void onEnable() {
       Animeware.GradientPurple = true;
		//super.onEnable();
	}
	@Override
	public void onDisable() {
	  Animeware.GradientPurple = false;
		//super.onDisable();
	}

}
