package animeware.cosmetic.impl.CosmeticMods;

import animeware.Animeware;
import animeware.cosmetic.CosmeticModule;
import animeware.hud.mod.HudMod;
import net.minecraft.util.ResourceLocation;

public class CosmeticEasterEggs extends CosmeticModule {

	public CosmeticEasterEggs() {
		super("Cosmetic Eggs", new ResourceLocation("Animeware/icons/blank.png"));
	}
	@Override
	public void onEnable() {
       Animeware.CosmeticEasterEggs = true;
		//super.onEnable();
	}
	@Override
	public void onDisable() {
	  Animeware.CosmeticEasterEggs = false;
		//super.onDisable();
	}

}
