package animeware.cosmetic.impl.CosmeticMods;

import animeware.Animeware;
import animeware.cosmetic.CosmeticModule;
import animeware.hud.mod.HudMod;
import net.minecraft.util.ResourceLocation;

public class NitroCape extends CosmeticModule {

	public NitroCape() {
		super("Nitro Cape", new ResourceLocation("Animeware/icons/cape.png"));
	}
	@Override
	public void onEnable() {
       Animeware.NitroCape = true;
		//super.onEnable();
	}
	@Override
	public void onDisable() {
	  Animeware.NitroCape = false;
		//super.onDisable();
	}

}
