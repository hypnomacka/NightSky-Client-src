package animeware.cosmetic.impl.CosmeticMods;

import animeware.Animeware;
import animeware.cosmetic.CosmeticModule;
import animeware.hud.mod.HudMod;
import net.minecraft.util.ResourceLocation;

public class EmeraldCape extends CosmeticModule {

	public EmeraldCape() {
		super("Emerald Cape", new ResourceLocation("Animeware/icons/cape.png"));
	}
	@Override
	public void onEnable() {
       Animeware.EmeraldCape = true;
		//super.onEnable();
	}
	@Override
	public void onDisable() {
	  Animeware.EmeraldCape = false;
		//super.onDisable();
	}

}
