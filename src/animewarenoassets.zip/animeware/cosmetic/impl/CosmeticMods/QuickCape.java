package animeware.cosmetic.impl.CosmeticMods;

import animeware.Animeware;
import animeware.cosmetic.CosmeticModule;
import animeware.hud.mod.HudMod;
import net.minecraft.util.ResourceLocation;

public class QuickCape extends CosmeticModule {

	public QuickCape() {
		super("Quick Cape", new ResourceLocation("Animeware/icons/cape.png"));
	}
	@Override
	public void onEnable() {
       Animeware.QuickCape = true;
		//super.onEnable();
	}
	@Override
	public void onDisable() {
	  Animeware.QuickCape = false;
		//super.onDisable();
	}

}
