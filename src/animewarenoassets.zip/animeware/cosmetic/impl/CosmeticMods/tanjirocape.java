package animeware.cosmetic.impl.CosmeticMods;

import animeware.Animeware;
import animeware.cosmetic.CosmeticModule;
import animeware.hud.mod.HudMod;
import net.minecraft.util.ResourceLocation;

public class tanjirocape extends CosmeticModule {

	public tanjirocape() {
		super("tanjiro Cape", new ResourceLocation("Animeware/icons/cape.png"));
	}
	@Override
	public void onEnable() {
       Animeware.tanjirocape = true;
		//super.onEnable();
	}
	@Override
	public void onDisable() {
	  Animeware.tanjirocape = false;
		//super.onDisable();
	}

}
