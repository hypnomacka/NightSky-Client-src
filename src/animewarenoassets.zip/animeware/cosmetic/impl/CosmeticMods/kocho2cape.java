package animeware.cosmetic.impl.CosmeticMods;

import animeware.Animeware;
import animeware.cosmetic.CosmeticModule;
import animeware.hud.mod.HudMod;
import net.minecraft.util.ResourceLocation;

public class kocho2cape extends CosmeticModule {

	public kocho2cape() {
		super("Kocho Cape", new ResourceLocation("Animeware/icons/cape.png"));
	}
	@Override
	public void onEnable() {
       Animeware.kocho2cape = true;
		//super.onEnable();
	}
	@Override
	public void onDisable() {
	  Animeware.kocho2cape = false;
		//super.onDisable();
	}

}
