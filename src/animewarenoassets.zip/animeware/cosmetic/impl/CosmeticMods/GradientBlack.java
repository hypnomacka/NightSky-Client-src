package animeware.cosmetic.impl.CosmeticMods;

import animeware.Animeware;
import animeware.cosmetic.CosmeticModule;
import animeware.hud.mod.HudMod;
import net.minecraft.util.ResourceLocation;

public class GradientBlack extends CosmeticModule {

	public GradientBlack() {
		super("GradientBlack Cape", new ResourceLocation("Animeware/icons/cape.png"));
	}
	@Override
	public void onEnable() {
       Animeware.GradientBlack = true;
		//super.onEnable();
	}
	@Override
	public void onDisable() {
	  Animeware.GradientBlack = false;
		//super.onDisable();
	}

}
