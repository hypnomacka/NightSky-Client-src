package animeware.cosmetic.impl.CosmeticMods;

import animeware.Animeware;
import animeware.cosmetic.CosmeticModule;
import animeware.hud.mod.HudMod;
import net.minecraft.util.ResourceLocation;

public class GradientRed extends CosmeticModule {

	public GradientRed() {
		super("GradientRed Cape", new ResourceLocation("Animeware/icons/cape.png"));
	}
	@Override
	public void onEnable() {
       Animeware.GradientRed = true;
		//super.onEnable();
	}
	@Override
	public void onDisable() {
	  Animeware.GradientRed = false;
		//super.onDisable();
	}

}
