package animeware.cosmetic.impl.CosmeticMods;

import animeware.Animeware;
import animeware.cosmetic.CosmeticModule;
import animeware.hud.mod.HudMod;
import net.minecraft.util.ResourceLocation;

public class RetardEyes extends CosmeticModule {

	public RetardEyes() {
		super("Retard Eyes", new ResourceLocation("Animeware/icons/blank.png"));
	}
	@Override
	public void onEnable() {
       Animeware.retardEyes = true;
		//super.onEnable();
	}
	@Override
	public void onDisable() {
	  Animeware.retardEyes = false;
		//super.onDisable();
	}

}
