package animeware.cosmetic.impl.CosmeticMods;

import animeware.Animeware;
import animeware.cosmetic.CosmeticModule;
import animeware.hud.mod.HudMod;
import net.minecraft.util.ResourceLocation;

public class CrystalWings extends CosmeticModule {

	public CrystalWings() {
		super("Crystal Wings", new ResourceLocation("Animeware/icons/blank.png"));
	}
	@Override
	public void onEnable() {
       Animeware.CrystalWings = true;
		//super.onEnable();
	}
	@Override
	public void onDisable() {
	  Animeware.CrystalWings = false;
		//super.onDisable();
	}

}
