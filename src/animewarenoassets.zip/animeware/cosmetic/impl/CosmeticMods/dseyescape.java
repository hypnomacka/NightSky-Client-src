package animeware.cosmetic.impl.CosmeticMods;

import animeware.Animeware;
import animeware.cosmetic.CosmeticModule;
import animeware.hud.mod.HudMod;
import net.minecraft.util.ResourceLocation;

public class dseyescape extends CosmeticModule {

	public dseyescape() {
		super("Demon eyes Cape 2", new ResourceLocation("Animeware/icons/cape.png"));
	}
	@Override
	public void onEnable() {
       Animeware.dseyescape = true;
		//super.onEnable();
	}
	@Override
	public void onDisable() {
	  Animeware.dseyescape = false;
		//super.onDisable();
	}

}
