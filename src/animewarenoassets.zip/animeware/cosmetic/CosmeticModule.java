package animeware.cosmetic;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.google.common.collect.Lists;

import animeware.Animeware;
import animeware.event.EventManager;
import animeware.hud.DraggableComponent;
import animeware.ui.comp.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiLabel;
import net.minecraft.util.ResourceLocation;

public class CosmeticModule {
	
	public Minecraft mc = Minecraft.getMinecraft();
	public FontRenderer fr = mc.fontRendererObj;
	protected List<GuiButton> buttonList = Lists.<GuiButton>newArrayList();
	protected List<GuiLabel> labelList = Lists.<GuiLabel>newArrayList();
	
	public List<Setting> settings = new ArrayList<Setting>();
	
	public int lenght = 10;
	public String name;
	//public String description;
	public ResourceLocation iconcos;
	//public boolean isEnabled = false;
	public boolean enabled;
	public DraggableComponent drag;
	
	public int x, y, w, h;
	
	public CosmeticModule(String name, ResourceLocation iconcos) {
		this.name = name;	
		//this.description = description;
		this.iconcos = iconcos;
		
		try {
			this.x = (int) Animeware.INSTANCE.config.config.get(name.toLowerCase() + " x");
			this.y = (int) Animeware.INSTANCE.config.config.get(name.toLowerCase() + " y");
			this.setEnabled( (boolean) Animeware.INSTANCE.config.config.get(name.toLowerCase() + " true"));			
		} catch(NullPointerException e) {
			this.x = x;
			this.y = y;
			this.enabled = false;
		}
		
		drag = new DraggableComponent(this.x, this.y, getWidth(), getHeight(), new Color(0, 0, 0, 0).getRGB());		
	}
	
	
	public int getWidth() {
		
		return 50;

	}
	
	public int getHeight() {
		return 50;

	}
	public ResourceLocation getIcon() {
		return iconcos;
	}
	
	public void draw() {

	}
	
	public void renderDummy(int mouseX, int mouseY) {
		drag.draw(mouseX, mouseY);

	}
	
	public int getX() {
		return drag.getxPosition();
	}
	
	public int getY() {
		return drag.getyPosition();
	}
	
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
		if(enabled) {
			onEnable();
		}
		else {
			onDisable();
		}
	}
	public void setDisabled(boolean enabled) {
		this.enabled = !enabled;
		if(!enabled) {
			onDisable();
		}
		else {
			onEnable();
		}
	}
	
	public void onEnable() {EventManager.register(this);}
	
	public void toggle() {
		this.setEnabled(!enabled);

	}
	
	public void addSettings(Setting... settings) {
		this.settings.addAll(Arrays.asList(settings));
	}
	
	public boolean isEnabled() {
		return enabled;
	}
	public boolean isDisabled() {
		return !enabled;
	}


	public void onDisable() {
		Animeware.INSTANCE.eventManager.unregister(this);

	}
	public void drawScreen(int mouseX, int mouseY, float partialTicks)
    {
        for (int i = 0; i < this.buttonList.size(); ++i)
        {
            ((GuiButton)this.buttonList.get(i)).drawButton(this.mc, mouseX, mouseY);
        }

        for (int j = 0; j < this.labelList.size(); ++j)
        {
            ((GuiLabel)this.labelList.get(j)).drawLabel(this.mc, mouseX, mouseY);
        }
    }
	//@Override
	public String getToggled() {
		return "Toggled";
	}
	public void Notif() {
		
	}

	
}



	

	

