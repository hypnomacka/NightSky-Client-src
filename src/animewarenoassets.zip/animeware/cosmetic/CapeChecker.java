package animeware.cosmetic;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;

public class CapeChecker {
	
	public static boolean ownsOwnerCape(AbstractClientPlayer entitylivingbaseIn) {
		if(entitylivingbaseIn.getName().equals("hypnomacka")) {
			return true;
		} 
	
	
	
	
		else return false;
	}
	public static boolean ownsYtCape(AbstractClientPlayer entitylivingbaseIn) {
		if(entitylivingbaseIn.getName().equals("hypnomacka")) {
			return true;
		} else if(entitylivingbaseIn.getName().equals("MartoSVK")) {
			return true;
		} else if(entitylivingbaseIn.getName().equals("quickDaffy")) {
			return true;
		}
	
	
	
	
		else return false;
	}

	public static boolean ownsQuickCape(AbstractClientPlayer entitylivingbaseIn) {
		/*if(entitylivingbaseIn.getName().equals("hypnomacka")) {
		return true;
	    } else */if(entitylivingbaseIn.getName().equals("quickDaffy")) {
			return true;
		}
	
	
	
	
		else return false;
	}	
	public static boolean ownsDevCape(AbstractClientPlayer entitylivingbaseIn) {
		if(entitylivingbaseIn.getName().equals("hypnomacka")) {
		return true;
	    } else if(entitylivingbaseIn.getName().equals("abcdegh8")) {
			return true;
	    } else if(entitylivingbaseIn.getName().equals("KnownAsR3named")) {
			return true;
	    }else if(entitylivingbaseIn.getName().equals("Slepica")) {
			return true;
	    }
	
	
	
	
		else return false;
	}
	
	public static boolean ownsZeroTwoCape(AbstractClientPlayer entitylivingbaseIn) {
		if(entitylivingbaseIn.getName().equals(Minecraft.getMinecraft().getSession().getUsername())) {
			return true;
		} 
	
	
	
	
	
		else return false;
	}
	public static boolean ownsOzhayCape(AbstractClientPlayer entitylivingbaseIn) {
		if(entitylivingbaseIn.getName().equals(Minecraft.getMinecraft().getSession().getUsername())) {
			return true;
		} 
	
	
	
	
	
		else return false;
	}
	public static boolean ownsPlanetsCape(AbstractClientPlayer entitylivingbaseIn) {
		if(entitylivingbaseIn.getName().equals(Minecraft.getMinecraft().getSession().getUsername())) {
			return true;
		} 
	
	
	
	
	
		else return false;
	}
	public static boolean ownsQuavCape(AbstractClientPlayer entitylivingbaseIn) {
		if(entitylivingbaseIn.getName().equals(Minecraft.getMinecraft().getSession().getUsername())) {
			return true;
		} 
	
	
	
	
	
		else return false;
	}
	public static boolean ownsReptyllCape(AbstractClientPlayer entitylivingbaseIn) {
		if(entitylivingbaseIn.getName().equals(Minecraft.getMinecraft().getSession().getUsername())) {
			return true;
		} 
	
	
	
	
	
		else return false;
	}
	public static boolean ownsSwordCape(AbstractClientPlayer entitylivingbaseIn) {
		if(entitylivingbaseIn.getName().equals(Minecraft.getMinecraft().getSession().getUsername())) {
			return true;
		} 
	
	
	
	
	
		else return false;
	}
	public static boolean ownsEmeraldCape(AbstractClientPlayer entitylivingbaseIn) {
		if(entitylivingbaseIn.getName().equals(Minecraft.getMinecraft().getSession().getUsername())) {
			return true;
		} 
	
	
	
	
	
		else return false;
	}
	public static boolean ownsLCape(AbstractClientPlayer entitylivingbaseIn) {
		if(entitylivingbaseIn.getName().equals(Minecraft.getMinecraft().getSession().getUsername())) {
			return true;
		} 
	
	
	
	
	
		else return false;
	}
	public static boolean ownsNitroCape(AbstractClientPlayer entitylivingbaseIn) {
		if(entitylivingbaseIn.getName().equals(Minecraft.getMinecraft().getSession().getUsername())) {
			return true;
		} 
	
	
	
	
	
		else return false;
	}
	public static boolean ownsDarkCape(AbstractClientPlayer entitylivingbaseIn) {
		if(entitylivingbaseIn.getName().equals(Minecraft.getMinecraft().getSession().getUsername())) {
			return true;
		} 
	
	
	
	
	
		else return false;
	}
	public static boolean ownsWings(AbstractClientPlayer entitylivingbaseIn) {
		/*if(entitylivingbaseIn.getName().equals("hypnomacka")) {
		return true;
	} else if(entitylivingbaseIn.getName().equals("quickDaffy")) {
			return true;
		} else if(entitylivingbaseIn.getName().equals("KnownAsR3named")) {
			return true;
		} else if(entitylivingbaseIn.getName().equals("MartoSVK")) {
			return true;
		}*/
		if(entitylivingbaseIn.getName().equals(Minecraft.getMinecraft().getSession().getUsername())) {
			return true;
		} 
	
	
		else return false;
	}
	public static boolean ownsHat(AbstractClientPlayer entitylivingbaseIn) {
		if(entitylivingbaseIn.getName().equals("hypnomacka")) {
		return true;
	    } else if(entitylivingbaseIn.getName().equals("quickDaffy")) {
			return true;
		} else if(entitylivingbaseIn.getName().equals("KnownAsR3named")) {
			return true;
		} else if(entitylivingbaseIn.getName().equals("MartoSVK")) {
			return true;
		}
		if(entitylivingbaseIn.getName().equals(Minecraft.getMinecraft().getSession().getUsername())) {
			return true;
		}
	
	
		else return false;
	}
	public static boolean ownsHalo(AbstractClientPlayer entitylivingbaseIn) {
		/*if(entitylivingbaseIn.getName().equals("hypnomacka")) {
		return true;
	    } else */if(entitylivingbaseIn.getName().equals("MartoSVK")) {
			return true;
		} else if(entitylivingbaseIn.getName().equals("KnownAsR3named")) {
			return true;
		} else if(entitylivingbaseIn.getName().equals("quickDaffy")) {
			return true;
		}
	    if(entitylivingbaseIn.getName().equals(Minecraft.getMinecraft().getSession().getUsername())) {
			return true;
		}
	
	
	
	
		else return false;
	}
	public static boolean ownsBadge(AbstractClientPlayer entitylivingbaseIn) {
		if(entitylivingbaseIn.getName().equals(Minecraft.getMinecraft().getSession().getUsername())) {
			return true;
		}
		else return false; 
	}
	public static boolean ownsDevBadge(AbstractClientPlayer entitylivingbaseIn) {
		if(entitylivingbaseIn.getName().equals("KnownAsR3named")) {
			return true;
		}
		if(entitylivingbaseIn.getName().equals("Slepica")) {
			return true;
		}
		if(entitylivingbaseIn.getName().equals("abcdefgh8")) {
			return true;
		}
		if(entitylivingbaseIn.getName().equals("quickDaffy")) {
			return true;
		}
		else return false; 
	}
	public static boolean ownsMartoBadge(AbstractClientPlayer entitylivingbaseIn) {
		if(entitylivingbaseIn.getName().equals("MartoSVK")) {
			return true;
		}
		else return false; 
	}
	public static boolean ownsOwnerBadge(AbstractClientPlayer entitylivingbaseIn) {
		if(entitylivingbaseIn.getName().equals("hypnomacka")) {
			return true;
		}
		else return false; 
	}
	public static boolean ownsGalaxyWings(AbstractClientPlayer entitylivingbaseIn) {
		if(entitylivingbaseIn.getName().equals("hypnomacka")) {
			return true;
		} else if(entitylivingbaseIn.getName().equals("MartoSVK")) {
			return true;
		} else if(entitylivingbaseIn.getName().equals("KnownAsR3named")) {
			return true;
		} else if(entitylivingbaseIn.getName().equals("quickDaffy")) {
			return true;
		} 
	
	
	
	
	
		else return false;
	}
	
	public static float[] getTopHatColor(AbstractClientPlayer player) {
		return new float[] {1, 1, 1};
	}
	public static float[] getHaloColor(AbstractClientPlayer player) {
		return new float[] {0, 0, 1};
	} 
	

}
