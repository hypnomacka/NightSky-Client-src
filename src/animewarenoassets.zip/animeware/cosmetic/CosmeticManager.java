package animeware.cosmetic;

import java.util.ArrayList;

import animeware.cosmetic.impl.CosmeticMods.*;
import animeware.hud.mod.Mods.FPSMod;


public class CosmeticManager {
	
	public static ArrayList<CosmeticModule> cosmetics = new ArrayList<>();
	
	public Cape zerotwo;
	public DarkCape darkCape;
	public dseyes2cape deamoneyes;
	public dseyescape deamoneyes2;
	public EmeraldCape ecape;
	public GradientBlack gblack;
	public GradientBlue gblue;
	public GradientGreen ggreen;
	public GradientPurple gpurple;
	public GradientRed gred;
	public kocho2cape kcape;
	public kocho3cape kcape2;
	public LCape lcape;
	public NitroCape ncape;
	public PlanetsCape pcape;
	public QuavCape quavcape;
	public QuickCape quickcape;
	public ReptyllCape rcape;
	public SwordCape scape;
	public tanjirocape tcape;
	
	public CrystalWings cwings;
	public DragonWings dwings;
	public GalaxyWings gwings;
	
	public CosmeticEasterEggs eggs;
	public CosmeticWitchHat witchhat;
	public Glasses glasses;
	public Halo halo;
	public RetardEyes retardeyes;
	
	public CosmeticManager() {
		cosmetics = new ArrayList<>();
		cosmetics.add(zerotwo = new Cape());
		cosmetics.add(darkCape = new DarkCape());
		cosmetics.add(deamoneyes = new dseyes2cape());
		cosmetics.add(deamoneyes2 = new dseyescape());
		cosmetics.add(ecape = new EmeraldCape());
		cosmetics.add(gblack = new GradientBlack());
		cosmetics.add(gblue = new GradientBlue());
		cosmetics.add(ggreen = new GradientGreen());
		cosmetics.add(gpurple = new GradientPurple());
		cosmetics.add(gred = new GradientRed());
		cosmetics.add(kcape = new kocho2cape());
		cosmetics.add(kcape2 = new kocho3cape());
		cosmetics.add(lcape = new LCape());
		cosmetics.add(ncape = new NitroCape());
		cosmetics.add(pcape = new PlanetsCape());
		cosmetics.add(quavcape = new QuavCape());
		cosmetics.add(quickcape = new QuickCape());
		cosmetics.add(rcape = new ReptyllCape());
		cosmetics.add(scape = new SwordCape());
		cosmetics.add(tcape = new tanjirocape());
		
		cosmetics.add(cwings = new CrystalWings());
		cosmetics.add(dwings = new DragonWings());
		cosmetics.add(gwings = new GalaxyWings());
		
		cosmetics.add(eggs = new CosmeticEasterEggs());
		cosmetics.add(witchhat = new CosmeticWitchHat());
		cosmetics.add(glasses = new Glasses());
		cosmetics.add(halo = new Halo());
		cosmetics.add(retardeyes = new RetardEyes());
		
	}	
	public static ArrayList<CosmeticModule> getCosmetics() {
		return cosmetics;
	}
		
			
}


