package animeware.hud;

import java.io.IOException;

import animeware.Animeware;
import animeware.hud.mod.HudMod;
import animeware.mainmenu.components.ClassicButton;
import animeware.ui.ClickGUI;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.util.ResourceLocation;

public class HUDConfigScreen extends GuiScreen {
	
	private HudMod hudMod;
	
	@Override
	public void initGui() {
		super.initGui();
		//Minecraft.getMinecraft().entityhudMod..loadShader(new ResourceLocation("shaders/post/blur.json"));
		this.buttonList.add(new ClassicButton(69, this.width / 2 - 50, this.height / 2 - 10, 100, 20, "Open GUI"));
		//this.buttonList.add(new ClassicButton(70, this.width / 2 - 50, this.height / 2 + 12, 100, 20, "Jus test"));
		//this.buttonList.add(new ClassicButton(71, this.width / 2 - 50, this.height / 2 + 32, 100, 20, "Open Cosmetics"));
	}
		
	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
		super.drawDefaultBackground();
		//this.drawOutlinedRect(hudMod.getY(), hudMod.getY(), hudMod.getY(), hudMod.getY(), hudMod.getX(), hudMod.getY());
		//HudMod hudMod = new HudMod(null, mouseY, mouseY);
		//this.drawOutlinedRect(mouseY, mouseY, mouseY, mouseY, mouseX, mouseY);
		//this.drawHollowRect(hudMod.getX(), hudMod.getY(), hudMod.getX() + hudMod.getWidth(), hudMod.getY() + hudMod.getHeight(), 0x33FFFFFF);
		//this.drawHollowRect(hudMod.getX(), hudMod.getY(), hudMod.getWidth(), hudMod.getHeight(), -1);
		//mc.entityhudMod..loadShader(new ResourceLocation("shaders/post/blur.json"));
		//this.drawHollowRect(hudMod.x, hudMod.y, hudMod.x + hudMod.getHeight(), hudMod.y + hudMod.getHeight(), 0x33FFFFFF);
		mc.getTextureManager().bindTexture(new ResourceLocation ("Animeware/logo_text.png"));
		this.drawModalRectWithCustomSizedTexture(355, 70, 0, 0, 250, 250, 250, 250);		
		
		for(HudMod m : Animeware.INSTANCE.hudManager.hudMods) {
			if(m.isEnabled()) {
			m.renderDummy(mouseX, mouseY);
			}
		}
		
		super.drawScreen(mouseX, mouseY, partialTicks);
	}
	
	
	@Override
	protected void actionPerformed(GuiButton button) throws IOException {
		super.actionPerformed(button);
		switch(button.id) {
		case 69:
			mc.displayGuiScreen(new ClickGUI());
			break;
		
		/*case 71:                                            //VYRIESIT!!!!!
			mc.displayGuiScreen(new CosmeticGUI());
			break;*/
		}
	}
	public void drawHollowRect(int x, int y, int w, int h, int color) {

        this.drawHorizontalLine(x, x + w, y, color);
        this.drawHorizontalLine(x, x + w, y + h, color);

        this.drawVerticalLine(x, y + h, y, color);
        this.drawVerticalLine(x + w, y + h, y, color);

    }
	public static void drawOutlinedRect(int left, int top, int right, int bottom, int rectColor, int outlineColor) {
		Gui gui = new Gui();
    	gui.drawRect(left + 1, top, right - 1, bottom, rectColor);
    	gui.drawHorizontalLine(left, right - 1, top, outlineColor);
    	gui.drawHorizontalLine(left, right - 1, bottom, outlineColor);
    	gui.drawVerticalLine(left, top, bottom, outlineColor);
    	gui.drawVerticalLine(right - 1, top, bottom, outlineColor);
    }

}
