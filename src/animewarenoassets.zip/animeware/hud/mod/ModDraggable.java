package animeware.hud.mod;

import animeware.hud.IRenderer;
import animeware.hud.ScreenPosition;
import net.minecraft.util.ResourceLocation;

public abstract class ModDraggable extends HudMod implements IRenderer {
	
	public ModDraggable(String name, String description, ResourceLocation icon, int x, int y) {
		super(name, description, icon, x, y);
		// TODO Auto-generated constructor stub
	}

	protected ScreenPosition pos;
	public boolean isEnabled = false;

	
	@Override
	public ScreenPosition load() {
		return pos;
	}
	
	@Override
	public void save(ScreenPosition pos) {
		this.pos = pos;
	}
	
	public final int getLineOffset(ScreenPosition pos, int lineNum) {
		return pos.getAbsoluteX() + getLineOffset(lineNum);
	}
	
	private int getLineOffset(int lineNum) {
		return (fr.FONT_HEIGHT + 3) * lineNum;
	}

}
