package animeware.hud.mod.Mods;

import java.awt.Color;

import animeware.hud.ScreenPosition;
import animeware.hud.mod.HudMod;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.ResourceLocation;

public class ModDirection extends HudMod {
	
	public ModDirection() {
		super("Direction", "Facing direction", new ResourceLocation("Animeware/icons/direction.png"), 0, 91);
	}

	@Override
	public int getWidth() {
		return fr.getStringWidth("[Direction: north]");
	}

	@Override
	public int getHeight() {
		return fr.FONT_HEIGHT;
	}

	@Override
	public void draw() {
		Gui.drawRect(getX() - 2, getY() - 2, getX() + getWidth(), getY() + getHeight(), new Color(0, 0, 0, 170).getRGB());
			fr.drawStringWithShadow("�8[�fDirection �f" + mc.thePlayer.getHorizontalFacing() + "�8]", getX() + 1, getY() + 1, -1);
}
	
	@Override
	public void renderDummy(int mouseX, int mouseY) {
	
		fr.drawStringWithShadow("�8[�fDirection " + "�fwest" + "�8]", getX() + 1, getY() + 1, -1);
		super.renderDummy(mouseX, mouseY);
}

}
