package animeware.hud.mod.Mods;

import java.awt.Color;

import animeware.Animeware;
import animeware.hud.mod.HudMod;
import animeware.ui.comp.setting.BooleanSetting;
import animeware.ui.comp.setting.ModeSetting;
import animeware.util.ChromaString;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.ResourceLocation;

public class FPSMod extends HudMod {
	
	//public ModeSetting Color = new ModeSetting("Blue", "Cyan", "Purple", "Red");
	public BooleanSetting Blue = new BooleanSetting("Blue", false);
	
	private HudMod hudMod;

	public FPSMod() {
		super("FPS", "Displays fps", new ResourceLocation("Animeware/icons/fps.png"), 0, 1);
		this.addSettings(Blue);
	}
	
	@Override
	public void draw() {
		Gui.drawRect(getX() - 2, getY() - 2, getX() + getWidth(), getY() + getHeight(), new Color(0, 0, 0, 170).getRGB());
		//if(Blue.isEnabled()) {
		//fr.drawStringWithShadow("�8[�1FPS:�f" + mc.getDebugFPS() + "�8]", getX(), getY(), -1);
		//} else {
			fr.drawStringWithShadow("�8[�fFPS:�f" + mc.getDebugFPS() + "�8]", getX(), getY(), -1);
			//ChromaString.drawChromaString("FPS:" + mc.getDebugFPS() + "]", getX(), getY(), -1);
		//}
		//super.draw();
	}
	
	
	@Override
	public void renderDummy(int mouseX, int mouseY) {
		fr.drawStringWithShadow("�8[�fFPS:�f" + mc.getDebugFPS() + "�8]", getX(), getY(), -1);
		//this.drawHollowRect(hudMod.getX(), hudMod.getY(), hudMod.getX() + hudMod.getWidth(), hudMod.getY() + hudMod.getHeight(), 0x33FFFFFF);
		
		super.renderDummy(mouseX, mouseY);
	}

	@Override
	public int getWidth() {
		return fr.getStringWidth("�8[�fFPS:�f" + mc.getDebugFPS() + "�8]");
	}
	
	@Override
	public int getHeight() {
		return fr.FONT_HEIGHT;
	}
	

}

