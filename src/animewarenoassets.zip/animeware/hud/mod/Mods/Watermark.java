package animeware.hud.mod.Mods;

import animeware.Animeware;
import animeware.hud.mod.HudMod;
import net.minecraft.util.ResourceLocation;

public class Watermark extends HudMod {

	public Watermark() {
		super("Watermark", "Displays client watermark", new ResourceLocation("Animeware/icons/iconWhite.png"), 0, 0);
	}
	@Override
	public void onEnable() {
       Animeware.watermark = true;
		//super.onEnable();
	}
	@Override
	public void onDisable() {
	  Animeware.watermark = false;
		//super.onDisable();
	}

}
