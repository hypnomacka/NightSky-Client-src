package animeware.hud.mod.Mods;

import animeware.Animeware;
import animeware.hud.mod.HudMod;
import net.minecraft.util.ResourceLocation;

public class SwordSpin extends HudMod {

	public SwordSpin() {
		super("SwordSpin", "Spins your sword while blocking", new ResourceLocation("Animeware/icons/placeholder.png"), 0, 0);
	}
	@Override
	public void onEnable() {
       Animeware.SwordSpin = true;
		//super.onEnable();
	}
	@Override
	public void onDisable() {
	  Animeware.SwordSpin = false;
		//super.onDisable();
	}

}
