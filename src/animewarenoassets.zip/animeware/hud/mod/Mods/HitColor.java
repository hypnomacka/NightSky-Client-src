package animeware.hud.mod.Mods;

import animeware.Animeware;
import animeware.hud.mod.HudMod;
import net.minecraft.util.ResourceLocation;

public class HitColor extends HudMod {

	public HitColor() {
		super("HitColor", "Changes hit color", new ResourceLocation("Animeware/icons/placeholder.png"), 0, 0);
	}
	@Override
	public void onEnable() {
       Animeware.HitColor = true;
		//super.onEnable();
	}
	@Override
	public void onDisable() {
	  Animeware.HitColor = false;
		//super.onDisable();
	}

}
