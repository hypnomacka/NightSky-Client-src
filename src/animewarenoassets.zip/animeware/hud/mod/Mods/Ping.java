package animeware.hud.mod.Mods;

import java.awt.Color;

import animeware.hud.mod.HudMod;
import net.minecraft.client.gui.Gui;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.ResourceLocation;

public class Ping extends HudMod{

	public Ping() {
		super("Ping", "Displays ping", new ResourceLocation("Animeware/icons/pingdisplay.png"), 0, 41);
	}
	
	@Override
	public void draw() {
		Gui.drawRect(getX() - 2, getY() - 2, getX() + getWidth(), getY() + getHeight(), new Color(0, 0, 0, 170).getRGB());
		if(!MinecraftServer.getServer().isSinglePlayer()) {
		fr.drawStringWithShadow("�8[�fPing:�f" + mc.getNetHandler().getPlayerInfo(mc.thePlayer.getUniqueID()).getResponseTime() + "ms�8]", getX(), getY(), -1);
		} else {
			fr.drawStringWithShadow("�8[�fPing:�f00ms�8]", getX(), getY(), -1);
		}
		super.draw();
	}
	
	@Override
	public void renderDummy(int mouseX, int mouseY) {
		fr.drawStringWithShadow("�8[�fPing:�f00ms�8]", getX(), getY(), -1);
		
		super.renderDummy(mouseX, mouseY);
	}

	@Override
	public int getWidth() {
		return fr.getStringWidth("�8[�fPing:�f00ms�8]");
	}
	
	@Override
	public int getHeight() {
		return fr.FONT_HEIGHT;
	}

}
