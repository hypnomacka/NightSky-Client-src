package animeware.hud.mod.Mods;

import java.awt.Color;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import animeware.hud.mod.HudMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.ResourceLocation;

public class TimeMod extends HudMod {
    public TimeMod() {
		super("TimeMod", "Displays real time", new ResourceLocation("Animeware/icons/timedisplay.png"), 0, 61);
	}

	@Override
    public void draw() {
  
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm");
        LocalTime localTime = LocalTime.now();
        String time = dtf.format(localTime);
        //Minecraft.getMinecraft().fontRendererObj.drawString(time, getX(), getY(), -1);
        Gui.drawRect(getX() - 2, getY() - 2, getX() + getWidth(), getY() + getHeight(), new Color(0, 0, 0, 170).getRGB());
        fr.drawStringWithShadow("�8[�f" + time + "�8]", getX(), getY(), -1);
    }
	@Override
	public void renderDummy(int mouseX, int mouseY) {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm");
        LocalTime localTime = LocalTime.now();
        String time = dtf.format(localTime);
		fr.drawStringWithShadow("�8[�f" + time + "�8]", getX(), getY(), -1);
		
		super.renderDummy(mouseX, mouseY);
	}

    @Override
    public int getWidth() {
    	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm");
        LocalTime localTime = LocalTime.now();
        String time = dtf.format(localTime);
    	return fr.getStringWidth("�8[�f" + time + "�8]");
    }

    @Override
    public int getHeight() {
        return 10;
    }
}
