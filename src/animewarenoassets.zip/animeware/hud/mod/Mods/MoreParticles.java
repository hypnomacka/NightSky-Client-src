package animeware.hud.mod.Mods;

import animeware.Animeware;
import animeware.hud.mod.HudMod;
import net.minecraft.util.ResourceLocation;

public class MoreParticles extends HudMod {

	public MoreParticles() {
		super("MoreParticles", "Multiplies particles", new ResourceLocation("Animeware/icons/placeholder.png"), 0, 0);
	}
	@Override
	public void onEnable() {
       Animeware.MoreParticles = true;
		//super.onEnable();
	}
	@Override
	public void onDisable() {
	  Animeware.MoreParticles = false;
		//super.onDisable();
	}

}
