package animeware.hud.mod.Mods;

import animeware.Animeware;
import animeware.hud.mod.HudMod;
import net.minecraft.util.ResourceLocation;

public class TNTTimer extends HudMod {

	public TNTTimer() {
		super("TNTTimer", "Displays time until TNT explodes", new ResourceLocation("Animeware/icons/timedisplay.png"), 0, 0);
	}
	@Override
	public void onEnable() {
       Animeware.TNTTimer = true;
		//super.onEnable();
	}
	@Override
	public void onDisable() {
	  Animeware.TNTTimer = false;
		//super.onDisable();
	}

}
