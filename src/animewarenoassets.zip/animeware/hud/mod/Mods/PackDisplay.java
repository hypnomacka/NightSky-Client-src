package animeware.hud.mod.Mods;

import java.awt.Color;

import animeware.hud.mod.HudMod;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.ResourceLocation;
import optifine.Config;

public class PackDisplay extends HudMod {

	public PackDisplay() {
		super("PackDisplay", "Shows active pack", new ResourceLocation("Animeware/icons/packoverlay.png"), 0, 71);
	}
	
	@Override
	public void draw() {
		String pack = "";
		if(!Config.getResourcePackNames().equalsIgnoreCase("default"))
			pack = Config.getResourcePackNames().split(",")[Config.getResourcePacks().length -1];
        else
            pack = "default";
		Gui.drawRect(getX() - 2, getY() - 2, getX() + getWidth(), getY() + getHeight(), new Color(0, 0, 0, 170).getRGB());
		if(!Config.getResourcePackNames().equals("default")) {
			fr.drawStringWithShadow("�8[�fPack: " + pack + "�8]", getX(), getY(), -1);
		} else {
			fr.drawStringWithShadow("", getX(), getY(), -1);
		}
		
		super.draw();
	}
	
	
	@Override
	public void renderDummy(int mouseX, int mouseY) {
		
		fr.drawStringWithShadow("�8[�fPack: Uchiha Pack�8]", getX(), getY(), -1);
		
		super.renderDummy(mouseX, mouseY);
	}

	@Override
	public int getWidth() {
		String pack = "";
		if(!Config.getResourcePackNames().equalsIgnoreCase("default"))
			pack = Config.getResourcePackNames().split(",")[Config.getResourcePacks().length -1];
        else
            pack = "default";
		return fr.getStringWidth("�8[�fPack: " + pack + "�8]");
	}
	
	@Override
	public int getHeight() {
		return fr.FONT_HEIGHT;
	}	
}
