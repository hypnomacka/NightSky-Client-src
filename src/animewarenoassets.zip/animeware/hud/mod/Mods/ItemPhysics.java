package animeware.hud.mod.Mods;

import animeware.Animeware;
import animeware.hud.mod.HudMod;
import net.minecraft.util.ResourceLocation;

public class ItemPhysics extends HudMod {

	public ItemPhysics() {
		super("ItemPhysics", "Adds physics to your items", new ResourceLocation("Animeware/icons/itemphysics.png"), 0, 0);
	}
	@Override
	public void onEnable() {
       Animeware.itemphys = true;
		//super.onEnable();
	}
	@Override
	public void onDisable() {
	  Animeware.itemphys = false;
		//super.onDisable();
	}

}
