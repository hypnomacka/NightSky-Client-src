package animeware.hud.mod.Mods;

import java.awt.Color;

import animeware.hud.ScreenPosition;
import animeware.hud.mod.HudMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.ResourceLocation;

public class MemUsage extends HudMod {

    public MemUsage() {
		super("Memory", "Memory usage", new ResourceLocation("Animeware/icons/memoryusage.png"), 50, 137);
	}

    @Override
    public int getWidth() {
        Runtime runtime = Runtime.getRuntime();
        String str = "Mem: " + (runtime.totalMemory() - runtime.freeMemory()) * 100L / runtime.maxMemory() + "% ";
        return fr.getStringWidth(str) + 8;
    }

    @Override
    public int getHeight() {
        return fr.FONT_HEIGHT + 9;
    }

    @Override
    public void draw() {
        //Gui.drawRect(getX(), getY(), getX() + getWidth(), getY() + getHeight(), new Color(0, 0, 0, 50).getRGB());
    	Gui.drawRect(getX() + 3, getY() + 3, getX() + getWidth() - 5, getY() + getHeight() - 4, new Color(0, 0, 0, 170).getRGB());
        
        Runtime runtime = Runtime.getRuntime();
        String str = "Mem: " + (runtime.totalMemory() - runtime.freeMemory()) * 100L / runtime.maxMemory() + "% ";
        
        fr.drawString(str, getX() + 6, getY() + 5, -1);
    }
    
    @Override
    public void renderDummy(int mouseX, int mouseY) {
        Runtime runtime = Runtime.getRuntime();
        String str = "Mem: " + (runtime.totalMemory() - runtime.freeMemory()) * 100L / runtime.maxMemory() + "% ";
        
        fr.drawString(str, getX() + 6, getY() + 5, -1);
        super.renderDummy(mouseX, mouseY);
    }

}