package animeware.hud.mod.Mods;

import animeware.Animeware;
import animeware.event.EventTarget;
import animeware.event.impl.EventUpdate;
import animeware.hud.mod.HudMod;
import net.minecraft.util.ResourceLocation;

public class TimeChanger extends HudMod {

	public TimeChanger() {
		super("TimeChanger", "Changes world time", new ResourceLocation("Animeware/icons/timechanger.png"), 0, 0);
	}
	
	@Override
	public void onEnable() {
		
		
		
		
       Animeware.timechanger = true;
		//super.onEnable();
	}
	@Override
	public void onDisable() {
		//mc.thePlayer.setSprinting(false);
		
	  Animeware.timechanger = false;
		//super.onDisable();
	}

}
