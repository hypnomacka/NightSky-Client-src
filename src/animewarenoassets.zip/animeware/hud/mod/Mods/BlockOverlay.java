package animeware.hud.mod.Mods;

import animeware.Animeware;
import animeware.hud.mod.HudMod;
import net.minecraft.util.ResourceLocation;

public class BlockOverlay extends HudMod {

	public BlockOverlay() {
		super("BlockOverlay", "Shows overlay over blocks", new ResourceLocation("Animeware/icons/blockoverlay.png"), 0, 0);
	}
	@Override
	public void onEnable() {
       Animeware.BlockOverlayWhite = true;
		//super.onEnable();
	}
	@Override
	public void onDisable() {
	  Animeware.BlockOverlayWhite = false;
		//super.onDisable();
	}

}
