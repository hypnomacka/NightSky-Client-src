package animeware.hud.mod.Mods;

import animeware.Animeware;
import animeware.hud.mod.HudMod;
import net.minecraft.util.ResourceLocation;

public class SmallSword extends HudMod {

	public SmallSword() {
		super("SmallSword", "Makes held items small", new ResourceLocation("Animeware/icons/placeholder.png"), 0, 0);
	}
	@Override
	public void onEnable() {
       Animeware.SmallSword = true;
		//super.onEnable();
	}
	@Override
	public void onDisable() {
	  Animeware.SmallSword = false;
		//super.onDisable();
	}

}
