package animeware.hud.mod;

public enum Side {
	
	LEFT,
	RIGHT,
	CLIENT;

}
