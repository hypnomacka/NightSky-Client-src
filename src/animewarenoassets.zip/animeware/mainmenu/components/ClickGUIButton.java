package animeware.mainmenu.components;



import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;

import java.awt.Color;

import org.lwjgl.opengl.GL11;

import animeware.util.render.DrawUtil;

public class ClickGUIButton extends GuiButton {
  protected boolean hovered;
  
  //public static VoyageFontFromAsset font = new VoyageFontFromAsset(new ResourceLocation("Voyage/font/AntipastoPro-DemiBold_trial.ttf"), 23.0F);
  private FontRenderer font = Minecraft.getMinecraft().fontRendererObj;
  
  public ClickGUIButton(int buttonId, int x, int y, int widthIn, int heightIn, String buttonText) {
    super(buttonId, x, y, widthIn, heightIn, buttonText);
    this.width = 2;
    this.height = 2;
    this.enabled = true;
    this.visible = true;
    this.id = buttonId;
    this.xPosition = x;
    this.yPosition = y;
    this.width = widthIn;
    this.height = heightIn;
    this.displayString = buttonText;
  }
  
  public ClickGUIButton(int buttonId, int x, int y, String buttonText) {
    this(buttonId, x, y, 70, 20, buttonText);
  }
  
  public void drawButton(Minecraft mc, int mouseX, int mouseY)
  {
      if (this.visible)
      {
          FontRenderer fontrenderer = mc.fontRendererObj;
          mc.getTextureManager().bindTexture(buttonTextures);
          GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
          this.hovered = mouseX >= this.xPosition && mouseY >= this.yPosition && mouseX < this.xPosition + this.width && mouseY < this.yPosition + this.height;
          int i = this.getHoverState(this.hovered);
          GlStateManager.enableBlend();
          GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
          GlStateManager.blendFunc(770, 771);
          //this.drawTexturedModalRect(this.xPosition, this.yPosition, 0, 46 + i * 20, this.width / 2, this.height);
          //this.drawTexturedModalRect(this.xPosition + this.width / 2, this.yPosition, 200 - this.width / 2, 46 + i * 20, this.width / 2, this.height);
          
          Gui.drawRect(this.xPosition, this.yPosition, this.xPosition + this.width, this.yPosition + this.height, new Color(0,0,0, 170).getRGB());
          this.mouseDragged(mc, mouseX, mouseY);
          int j = 14737632;

          if (!this.enabled)
          {
              j = 10526880;
          }
          else if (this.hovered)
          {
              j = new Color(0,255,255,255).getRGB();
          }

          this.drawCenteredString(fontrenderer, this.displayString, this.xPosition + this.width / 2, this.yPosition + (this.height - 5) / 2, j);
      }
  }
  
  public boolean isMouseOver() {
    return this.hovered;
  }
}
