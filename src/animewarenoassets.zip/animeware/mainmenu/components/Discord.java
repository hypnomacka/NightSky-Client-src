package animeware.mainmenu.components;



import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;

import java.awt.Color;

import org.lwjgl.opengl.GL11;

import animeware.util.render.DrawUtil;

public class Discord extends GuiButton {
  protected boolean hovered;
  
  //public static VoyageFontFromAsset font = new VoyageFontFromAsset(new ResourceLocation("Voyage/font/AntipastoPro-DemiBold_trial.ttf"), 23.0F);
  private FontRenderer font = Minecraft.getMinecraft().fontRendererObj;
  
  public Discord(int buttonId, int x, int y, int widthIn, int heightIn, String buttonText) {
    super(buttonId, x, y, widthIn, heightIn, buttonText);
    this.width = 2;
    this.height = 2;
    this.enabled = true;
    this.visible = true;
    this.id = buttonId;
    this.xPosition = x;
    this.yPosition = y;
    this.width = widthIn;
    this.height = heightIn;
    this.displayString = buttonText;
  }
  
  public Discord(int buttonId, int x, int y, String buttonText) {
    this(buttonId, 370, 20 / 2 + 85, 20, 20, buttonText);
  }
  
  public void drawDiscord(Minecraft mc, int mouseX, int mouseY)
  {
      if (this.visible)
      {                   
          mc.getTextureManager().bindTexture(new ResourceLocation ("Animeware/icons/discord.png"));
          this.drawModalRectWithCustomSizedTexture(0, 0, 0, 0, this.width, this.height, this.width, this.height);
          this.mouseDragged(mc, mouseX, mouseY);          
      }
  }
  
  public boolean isMouseOver() {
    return this.hovered;
  }
}
