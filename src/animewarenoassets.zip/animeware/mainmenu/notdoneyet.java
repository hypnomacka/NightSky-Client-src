package animeware.mainmenu;

import java.awt.Color;
import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;

import org.lwjgl.opengl.GL11;

import animeware.gui.alt.GuiAltManager;
import animeware.gui.cosmetic.GuiCosmetics;
import animeware.hud.HUDConfigScreen;
import animeware.mainmenu.components.AltButton;
import animeware.mainmenu.components.ClassicButton;
import animeware.mainmenu.components.CosmeticButton;
import animeware.mainmenu.components.DisButton;
import animeware.mainmenu.components.LilButton;
import animeware.mainmenu.components.QuitButton;
import animeware.mainmenu.components.SettingsButton;
import animeware.mainmenu.components.WebsiteButton;
import animeware.ui.ClickGUI;
import animeware.ui.login.AnimewareLoginScreen;
import animeware.util.font.FontUtil;
import animeware.util.render.DrawUtil;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSelectWorld;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.ResourceLocation;

public class notdoneyet extends GuiScreen {
	
	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
		GL11.glColor4f(1, 1, 1, 1);
		mc.getTextureManager().bindTexture(new ResourceLocation ("Animeware/background/strom.png"));
		this.drawModalRectWithCustomSizedTexture(0, 0, 0, 0, this.width, this.height, this.width, this.height);
		mc.getTextureManager().bindTexture(new ResourceLocation ("Animeware/nothing.png"));
		this.drawModalRectWithCustomSizedTexture(345, 95, 0, 0, 250, 250, 250, 250);
		FontUtil.normal.drawString("Not done yet sorry" ,0 + 420, this.height - 255, -1);
		super.drawScreen(mouseX, mouseY, partialTicks);
	}		
}
