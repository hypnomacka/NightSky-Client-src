package animeware.mainmenu;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.util.Calendar;
import java.util.Date;

import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import animeware.Animeware;
import animeware.gui.alt.GuiAltManager;
import animeware.mainmenu.components.AltButton;
import animeware.mainmenu.components.ClassicButton;
import animeware.mainmenu.components.CosmeticButton;
import animeware.mainmenu.components.DisButton;
import animeware.mainmenu.components.LilButton;
import animeware.mainmenu.components.LilButton2;
import animeware.mainmenu.components.QuitButton;
import animeware.mainmenu.components.SettingsButton;
import animeware.mainmenu.components.WebsiteButton;
import animeware.ui.ClickGUI;
import animeware.ui.CosmeticGUI;
import animeware.ui.login.AnimewareLoginScreen;
import animeware.ui.particle.ParticleEngine;
import animeware.util.font.FontUtil;
import animeware.util.render.AnimatedResourceLocation;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiButtonLanguage;
import net.minecraft.client.gui.GuiLanguage;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSelectWorld;
import net.minecraft.client.gui.GuiYesNo;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.demo.DemoWorldServer;
import net.minecraft.world.storage.ISaveFormat;
import net.minecraft.world.storage.WorldInfo;

public class MainMenu extends GuiScreen {
	
	private final Object threadLock = new Object();
	
	private String splashText;
	private String openGLWarning1;
	private String openGLWarning2;
	private DynamicTexture viewportTexture;
	 //private static final ResourceLocation minecraftTitleTextures = new ResourceLocation("textures/gui/title/minecraft.png");
	 private float updateCounter;
	 private int field_92024_r;
	    private int field_92023_s;
	    private int field_92022_t;
	    private int field_92021_u;
	    private int field_92020_v;
	    private int field_92019_w;
	    private ResourceLocation backgroundTexture;
	    private int panoramaTimer;
	    public ParticleEngine engine = new ParticleEngine();
	    
	    private AnimatedResourceLocation gif;
	    
	    private int bgid = 0;
	
	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
		
		if(!Animeware.ban) {
		//mc.getTextureManager().bindTexture(new ResourceLocation ("Animeware/background/strom.png"));
		//mc.getTextureManager().bindTexture(new AnimatedResourceLocation ("Animeware/cosmetics/gifcapes", 19, 2));
		//this.drawModalRectWithCustomSizedTexture(0, 0, 0, 0, this.width, this.height, this.width, this.height);
		this.drawModalRectWithCustomSizedTexture(-21 + (Mouse.getX() / 90), ((Mouse.getY() * -1 / 90)), 0, 0, width + 20, height + 20, width + 21, height + 20);
		
		
		/*if(bgid == 0) {
			this.mc.getTextureManager().bindTexture(new ResourceLocation("Animeware/background/strom.png"));
			this.drawModalRectWithCustomSizedTexture(-21 + (Mouse.getX() / 90), ((Mouse.getY() * -1 / 90)), 0, 0, width + 20, height + 20, width + 21, height + 20);
		} else if(bgid == 1) {
			this.mc.getTextureManager().bindTexture(new ResourceLocation("Animeware/background/bg.jpg"));
			this.drawModalRectWithCustomSizedTexture(-21 + (Mouse.getX() / 90), ((Mouse.getY() * -1 / 90)), 0, 0, width + 20, height + 20, width + 21, height + 20);
		} else if(bgid == 2) {
			this.mc.getTextureManager().bindTexture(new ResourceLocation("Animeware/background/bg1.png"));
			this.drawModalRectWithCustomSizedTexture(-21 + (Mouse.getX() / 90), ((Mouse.getY() * -1 / 90)), 0, 0, width + 20, height + 20, width + 21, height + 20);
		} else if(bgid == 3) {
			this.mc.getTextureManager().bindTexture(new ResourceLocation("Animeware/background/bg2.png"));
			this.drawModalRectWithCustomSizedTexture(-21 + (Mouse.getX() / 90), ((Mouse.getY() * -1 / 90)), 0, 0, width + 20, height + 20, width + 21, height + 20);
		} else if(bgid == 4) {
			this.mc.getTextureManager().bindTexture(new ResourceLocation("Animeware/background/bg3.png"));
			this.drawModalRectWithCustomSizedTexture(-21 + (Mouse.getX() / 90), ((Mouse.getY() * -1 / 90)), 0, 0, width + 20, height + 20, width + 21, height + 20);
		} else if(bgid == 5) {
			this.mc.getTextureManager().bindTexture(new ResourceLocation("Animeware/background/bg4.png"));
			this.drawModalRectWithCustomSizedTexture(-21 + (Mouse.getX() / 90), ((Mouse.getY() * -1 / 90)), 0, 0, width + 20, height + 20, width + 21, height + 20);
		} else if(bgid == 6) {
			this.mc.getTextureManager().bindTexture(new ResourceLocation("Animeware/background/bg5.png"));
			this.drawModalRectWithCustomSizedTexture(-21 + (Mouse.getX() / 90), ((Mouse.getY() * -1 / 90)), 0, 0, width + 20, height + 20, width + 21, height + 20);
		} else if(bgid == 7) {
			this.mc.getTextureManager().bindTexture(new ResourceLocation("Animeware/background/bg6.png"));
			this.drawModalRectWithCustomSizedTexture(-21 + (Mouse.getX() / 90), ((Mouse.getY() * -1 / 90)), 0, 0, width + 20, height + 20, width + 21, height + 20);
		} else if(bgid == 8) {
			this.mc.getTextureManager().bindTexture(new ResourceLocation("Animeware/background/bg7.png"));
			this.drawModalRectWithCustomSizedTexture(-21 + (Mouse.getX() / 90), ((Mouse.getY() * -1 / 90)), 0, 0, width + 20, height + 20, width + 21, height + 20);
		} else if(bgid == 9) {
			this.mc.getTextureManager().bindTexture(new ResourceLocation("Animeware/background/bg8.jpg"));
			this.drawModalRectWithCustomSizedTexture(-21 + (Mouse.getX() / 90), ((Mouse.getY() * -1 / 90)), 0, 0, width + 20, height + 20, width + 21, height + 20);
		}
		this.drawModalRectWithCustomSizedTexture(-21 + (Mouse.getX() / 90), ((Mouse.getY() * -1 / 90)), 0, 0, width + 20, height + 20, width + 21, height + 20);
		Gui.drawModalRectWithCustomSizedTexture(0, 0, 0, 0, width, height, width, height);*/
		
		this.mc.getTextureManager().bindTexture(new ResourceLocation("Animeware/background/old/bg5.png"));
		Gui.drawModalRectWithCustomSizedTexture(0, 0, 0, 0, width, height, width, height);
		
		GL11.glColor4f(1, 1, 1, 1);
		GlStateManager.enableAlpha();
		GlStateManager.enableBlend();
		mc.getTextureManager().bindTexture(new ResourceLocation ("Animeware/logo_text.png"));
		//gif.update();
    	//mc.getTextureManager().bindTexture(gif.getTexture());
		this.drawModalRectWithCustomSizedTexture(365, 95, 0, 0, 250, 250, 250, 250);
		FontUtil.normal.drawString(Animeware.INSTANCE.NAME + " " + Animeware.INSTANCE.VERSION ,0 + 3, this.height - 15, -1);
		FontUtil.normal.drawString("Copyright Mojang Studios" ,0 + 825, this.height - 15, -1);
		GlStateManager.pushMatrix();
		//GlStateManager.translate(width/2f, height/2f, 0);
		GlStateManager.scale(3, 3, 1);
		//GlStateManager.translate(-(width/2f), -(height/2f), 0);
		//this.drawCenteredString(mc.fontRendererObj, Animeware.INSTANCE.NAME, 37, height / 2 - 197, -1);
		GlStateManager.popMatrix();
		//mc.fontRendererObj.drawStringWithShadow(Animeware.INSTANCE.VERSION, width/2f - 275, height/2f - 65, -1);
		//FontUtil.normal.drawString("6", 60, 120, ColorUtils.astolfoColors(0, 100, -700L));
		
		
		super.drawScreen(mouseX, mouseY, partialTicks);
		} else {
			
		}
		super.drawScreen(mouseX, mouseY, partialTicks);
	}
	@Override
	public void updateScreen()
    {
        ++this.panoramaTimer;
    }
	
	@Override
	public void initGui() {
		if(!Animeware.ban) {
		gif = new AnimatedResourceLocation("Animeware/cosmetic/capes/anim/lightning", 10, 5);
		Animeware.INSTANCE.getDiscordRP().update("Main Menu", "Version: " + Animeware.INSTANCE.VERSION);
		int i = 24;
        int j = this.height / 4 + 48;
		//this.buttonList.add(new ClassicButton(1, 370, height / 2 + 25, "Singleplayer"));
		//this.buttonList.add(new GuiButton(0, this.width / 2 - 100, 72 + 1, 98, 30, ("options")));
		//this.buttonList.add(new ClassicButton(2, 370, height / 2 + 51, "Multiplayer"));
        
		
		this.buttonList.add(new QuitButton(4, this.width / 2 + 450, this.height / 2 - 262, ""));
		//this.buttonList.add(new GuiButton(4, 370, height / 2 + 85, "Quit"));
		this.buttonList.add(new AltButton(6, this.width / 2 - 470, this.height / 2 - 262, ""));
		//this.buttonList.add(new GuiButton(6, 370, height / 2 + 85, "Discord‍"));
		//this.buttonList.add(new DisButton(5, this.width / 2 - 452, this.height / 2 + 235, ""));
		//this.buttonList.add(new Discord(8, 370, height / 2 + 85, ""));
		//this.buttonList.add(new LilButton(7, this.width / 2 - 512, this.height / 2 + 235, ""));
		this.buttonList.add(new SettingsButton(3, this.width / 2 + 13, this.height / 2 + 180, ""));
		this.buttonList.add(new CosmeticButton(8, this.width / 2 - 13, this.height / 2 + 180, "")); //235
		//this.buttonList.add(new WebsiteButton(9, this.width / 2 - 542, this.height / 2 + 235, ""));
		//this.buttonList.add(new CosmeticsButton(8, 475, height / 2 + 35, ""));
		//this.buttonList.add(new GuiButton(8, 435, height / 2 + 235, "Login"));
		//this.buttonList.add(new LilButton2(10, 930, height / 2 + 235, "BG"));
		
		this.buttonList.add(new ClassicButton(1, this.width / 2 - 89, this.height / 2 + 35, 200, 20, 
		     	I18n.format("Singleplayer", new Object[0]))); 
     	this.buttonList.add(new ClassicButton(2, this.width / 2 - 89, this.height / 2 + 60, 200, 20, 
     	        I18n.format("Multiplayer", new Object[0])));    	
		
		this.viewportTexture = new DynamicTexture(256, 256);
        this.backgroundTexture = this.mc.getTextureManager().getDynamicTextureLocation("background", this.viewportTexture);

        //this.buttonList.add(new ClassicButton(10, width - 187, 3, 80, 20, "Change BG"));


        
        //this.buttonList.add(new GuiButton(0, this.width / 2 - 100, 72 + 1, 98, 30, I18n.format("menu.options", new Object[0])));
        //this.buttonList.add(new GuiButton(4, this.width / 2 + 2, j + 72 + 12, 98, 20, I18n.format("menu.quit", new Object[0])));
        //this.buttonList.add(new GuiButtonLanguage(5, this.width / 2 - 124, j + 72 + 12));

        synchronized (this.threadLock)
        {
            this.field_92023_s = this.fontRendererObj.getStringWidth(this.openGLWarning1);
            this.field_92024_r = this.fontRendererObj.getStringWidth(this.openGLWarning2);
            int k = Math.max(this.field_92023_s, this.field_92024_r);
            this.field_92022_t = (this.width - k) / 2;
            this.field_92021_u = ((GuiButton)this.buttonList.get(0)).yPosition - 24;
            this.field_92020_v = this.field_92022_t + k;
            this.field_92019_w = this.field_92021_u + 24;
        }

        this.mc.func_181537_a(false);
		
		
		}else {
			this.buttonList.add(new ClassicButton(4, this.width / 2 - 92, this.height / 2 + 25, 200, 20, 
			     	I18n.format("Banned", new Object[0])));
		}
		super.initGui();
	}
	
	@Override
	protected void actionPerformed(GuiButton button) throws IOException {			
		if(button.id == 1) {
			mc.displayGuiScreen(new GuiSelectWorld(this));
		}
		if(button.id == 2) {
			mc.displayGuiScreen(new GuiMultiplayer(this));
		}
		if(button.id == 3) {
			mc.displayGuiScreen(new GuiOptions(this, mc.gameSettings));
		}
		if(button.id == 4) {
			mc.shutdown();
		}
		if(button.id == 6) {
			mc.displayGuiScreen(new AnimewareLoginScreen());
		}
		
		if(button.id == 5) {					
		try {
 			  Desktop desktop = java.awt.Desktop.getDesktop();
 			  URI oURL = new URI("https://discord.gg/bCYU3DrW");
 			  desktop.browse(oURL);
 			} catch (Exception e) {
 			  e.printStackTrace();
 			}
      }
		if(button.id == 7) {
			this.mc.displayGuiScreen(new ClickGUI());
		}
		if(button.id == 8) {
			mc.displayGuiScreen(new CosmeticGUI(null));
		}
		if(button.id == 9) {					
			try {
	 			  Desktop desktop = java.awt.Desktop.getDesktop();
	 			  URI oURL = new URI("https://github.com/hypnomacka");
	 			  desktop.browse(oURL);
	 			} catch (Exception e) {
	 			  e.printStackTrace();
	 			}
			
	      }
		
		if(button.id == 10) {
			bgid++;
			if(bgid == 9) {
				bgid = 0;
			}
		}
		
	
		
		//if(button.id == 8) {
			
		//}
		//if(button.id == 8) {
			//this.mc.displayGuiScreen(new AnimewareLoginScreen());
		//}
		
		super.actionPerformed(button);
	}
		

}

