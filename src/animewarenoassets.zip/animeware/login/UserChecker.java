package animeware.login;

import animeware.Animeware;
import animeware.util.backend.AntiCheat;

public class UserChecker {
	
	
	public boolean isUser() {
		String hwid =  AntiCheat.getHWID();
		
		for(User u : Animeware.getInstance().getUsers().getUsers()) {
			if(u.getHwid() == hwid) {
				return true;
			}
			else return false;
		}
		return false;

	}
	

}
