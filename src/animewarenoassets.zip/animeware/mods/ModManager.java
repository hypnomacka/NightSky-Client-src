package animeware.mods;

import java.util.ArrayList;

public class ModManager {
	
	//public ToggleSprint togglesprint;
	
	public ArrayList<Mod> mods;
	
	public ModManager() {
		mods = new ArrayList<>();
		/*if(Animeware.ToggleSprint) {
			Animeware.INSTANCE.modManager.togglesprint.setEnabled(true);
		}*/
		//mods.add(togglesprint = new ToggleSprint());
	}

}
