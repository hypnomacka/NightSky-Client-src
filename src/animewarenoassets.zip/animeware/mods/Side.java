package animeware.mods;

public enum Side {
	
	LEFT,
	RIGHT;

}
