package animeware.event.impl;

import animeware.event.Event;

public class ClientTick extends Event {

}
