package animeware.util.socket.packet.impl;


import animeware.util.socket.packet.Packet;
import net.minecraft.client.Minecraft;

public class GPacketCommand extends Packet {

    public String ircMessage;

    public GPacketCommand(String message) {
        this.ircMessage = message;
    }

    @Override
    public String getSendMessage() {
        return "command;nick:" + Minecraft.getMinecraft().thePlayer.getName() +";message:" + ircMessage;
    }
}
