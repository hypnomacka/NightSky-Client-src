package animeware.util.socket.packet.impl;

import animeware.util.socket.packet.Packet;
import net.minecraft.client.Minecraft;

public class GPacketKeepAlive extends Packet {

    @Override
    public String getSendMessage() {
        return "keepalive;username:" + Minecraft.getMinecraft().thePlayer.getName();
    }
}
