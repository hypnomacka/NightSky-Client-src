package animeware.util.socket.packet.impl;

import animeware.cosmetic.impl.Capes;
import animeware.util.socket.packet.Packet;
import net.minecraft.client.Minecraft;

public class GPacketChangeCape extends Packet {

    public Capes cape;

    public GPacketChangeCape(Capes cape) {
        this.cape = cape;
    }

    @Override
    public String getSendMessage() {
        return "changecape;uuid:" + Minecraft.getMinecraft().thePlayer.getUniqueID() + ";capename:" + cape.getID();
    }
}
