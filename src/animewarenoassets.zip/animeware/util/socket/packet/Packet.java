package animeware.util.socket.packet;

public class Packet {

    public String packetName;

    public String getSendMessage() {
        return packetName;
    }

}
