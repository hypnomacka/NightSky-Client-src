package animeware.util.socket;

import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;

import animeware.Animeware;
import animeware.event.EventTarget;
import animeware.event.impl.EventChat;
import animeware.event.impl.EventUpdate;
import animeware.util.misc.Encryption;
import animeware.util.misc.Timer;
import animeware.util.socket.packet.Packet;
import animeware.util.socket.packet.impl.GPacketCommand;
import animeware.util.socket.packet.impl.GPacketIRCMessage;
import animeware.util.socket.packet.impl.GPacketKeepAlive;
import animeware.util.socket.packet.impl.GPacketLogIn;
import net.minecraft.client.Minecraft;

public class NetworkClient {

    public String host;
    public int port;
    public Socket socket;

    public boolean loggedInToServer;

    public Timer keepAliveTimer;

    public Thread receivedMessageThread;

    public NetworkClient(String host, int port) {
        this.host = host;
        this.port = port;

        loggedInToServer = false;
    }

    public void connect() throws Exception {
        keepAliveTimer = new Timer();
        socket = new Socket(host, port);
        System.out.println("Client successfully connected to server!");
        keepAliveTimer.reset();

        receivedMessageThread = new Thread(new ReceivedMessagesHandler(socket.getInputStream()));
        receivedMessageThread.start();

        //socket.close();
    }

    public void disconnect() throws Exception {
        socket.close();
        receivedMessageThread.interrupt();
    }

    public void sendIRCMessage(String message) throws IOException {
        if(!loggedInToServer) {
            //Glacier.sendMessage("You are not connected to the Glacier Client servers!");
            return;
        }
        this.sendPacket(new GPacketIRCMessage(message));
    }

    public void sendCommand(String message) throws IOException {
        if(!loggedInToServer) {
            //Glacier.sendMessage("You are not connected to the Glacier Client servers!");
            return;
        }
        this.sendPacket(new GPacketCommand(message));
    }

    public void sendPacket(Packet p) throws IOException {
        if(!loggedInToServer) {
            return;
        }
        PrintStream output = new PrintStream(socket.getOutputStream());
        output.println(Encryption.encrypt(p.getSendMessage(), Animeware.encryptionString));
    }

    @EventTarget
    public void onChat(EventChat e) {
        String message = e.getMessage();

        if (!message.startsWith("-"))
            return;

        e.setCancelled(true);

        message = message.substring("-".length());

        try {
            sendIRCMessage(message);
            System.out.println("sent irc message");
        } catch (IOException ioException) {
            ioException.printStackTrace();
            //Glacier.sendMessage("The IRC seems to be down or locked right now. Check back in later!");
        }

    }

    @EventTarget
    public void onUpdate(EventUpdate e) {

        if(!loggedInToServer && Minecraft.getMinecraft().thePlayer != null) {
            try {
                GPacketLogIn loginPacket = new GPacketLogIn();
                PrintStream output = new PrintStream(socket.getOutputStream());
                output.println(Encryption.encrypt(loginPacket.getSendMessage(), Animeware.encryptionString));
                System.out.println("Sent login packet.");
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            loggedInToServer = true;
        }

        if(keepAliveTimer.hasTimeElapsed(30000, true)) {
            try {
                sendPacket(new GPacketKeepAlive());
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        }
    }
    /*public static boolean isUser(String username) {
    	String[] arguments = Animeware.networkClient.request("isUser", username).toString().split(":");
        if(arguments[0].equals("true")) {
            //System.out.println("returned as true for user " + username);
        	return true;
        } else if (arguments[0].equals("false")) {
        	//System.out.println("returned as false for user " + username);
        	return false;
        } else {
        	System.out.println("there was an error for " + username);
        	return false;
        }
    }*/
}