package animeware.util.config;

import java.io.File;
import java.io.IOException;

import animeware.Animeware;
import animeware.hud.mod.HudMod;

public class Config {
	
	public File configFolder = new File("Animeware");
	public File modsFolder = new File("Animeware/Mods");
	static File TOGGLE_DIR = new File("Animeware/Mods/Button.java", "Toggle");
	
	public Configuration config, configToSave = ConfigurationAPI.newConfiguration(new File("Animeware/Mods/ModConfiguration.java"));
	
	public static void init() {
	    if(!TOGGLE_DIR.exists()) { TOGGLE_DIR.mkdirs(); }
	}
	public void saveModConfig() {
		
		if(!configFolder.exists()) {
			configFolder.mkdirs();
		}

		if(!modsFolder.exists()) {
			modsFolder.mkdirs();
		}
		
		System.out.println("Saving Mod Config");
		
		for(HudMod m : Animeware.INSTANCE.hudManager.hudMods) {
			configToSave.set(m.name.toLowerCase() + " x", m.getX());
			configToSave.set(m.name.toLowerCase() + " y", m.getY());
			configToSave.set(m.name.toLowerCase() + " true", m.isEnabled());
		}
		
		try {
			configToSave.save();
		} catch (IOException e) {			
			e.printStackTrace();
		}
	}
	
	public void loadModConfig() {
		System.out.println("Loading Mod Config");
		try {
			config = ConfigurationAPI.loadExistingConfiguration(new File("Animeware/Mods/ModConfiguration.java"));
		} catch (IOException e) {			
			e.printStackTrace();
		}
		

	}

}
