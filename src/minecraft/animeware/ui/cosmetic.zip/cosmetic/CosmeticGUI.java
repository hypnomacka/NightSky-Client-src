package animeware.ui.cosmetic;

import java.awt.Color;
import java.util.ArrayList;

import animeware.Animeware;
import animeware.cosmetic.impl.Cape;
import animeware.cosmetic.impl.DevCape;
import animeware.cosmetic.impl.OwnerCape;
import animeware.cosmetic.impl.QuickCape;
import animeware.cosmetic.impl.TopHat;
import animeware.cosmetic.impl.YTCape;
import animeware.ui.comp.ModButton;
import animeware.ui.cosmetic.component.CosmeticComponent;
import animeware.util.render.ColorMode;
import animeware.util.render.DrawUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;

public class CosmeticGUI extends GuiScreen {
	
	Minecraft mc = Minecraft.getMinecraft();
	
	FontRenderer font = mc.fontRendererObj;
	ArrayList<CosmeticComponent> cosButtons = new ArrayList<CosmeticComponent>();
	
	@Override
	public boolean doesGuiPauseGame() {
		return true;
	}
		
	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
		this.drawDefaultBackground();
		DrawUtil.drawRoundedRect(50, 50, 900, 475, 10, new Color(0, 0, 0, 150).getRGB());
		
		DrawUtil.drawRoundedRect(50, 20, 205, 50, 10, ColorMode.getBgColor()); // 0, 0, 0, 150
		DrawUtil.setColor(-1);
		font.drawString("Cosmetics", 60, 25, new Color(255, 255, 255, 255).getRGB());
		GlStateManager.pushMatrix();
		GlStateManager.scale(0.8, 0.8, 0.8);
		font.drawString("Capes, hats, and other cosmetics.", 75, 45, -1);
		GlStateManager.popMatrix();
		Gui.drawRect(60, 35, 130, 34, -1);
		
		
		//this.cosButtons.add(new CosmeticComponent(270, 105, 55, 80, Animeware.INSTANCE.cosmeticController.shouldRenderOwnerCape));
		if(Cape.ownsCosmetic()) {cosButtons.add(new CosmeticComponent(mouseX, mouseY, 75, 75, new Cape(null), 1));}
		if(TopHat.ownsCosmetic()) {cosButtons.add(new CosmeticComponent(mouseX, mouseY, 150, 75, new TopHat(null), 1));}
		if(DevCape.ownsCosmetic()) {cosButtons.add(new CosmeticComponent(mouseX, mouseY, 200, 75, new DevCape(null), 1));}
		if(OwnerCape.ownsCosmetic()) {cosButtons.add(new CosmeticComponent(mouseX, mouseY, 325, 75, new OwnerCape(null), 1));}
		if(QuickCape.ownsCosmetic()) {cosButtons.add(new CosmeticComponent(mouseX, mouseY, 450, 75, new QuickCape(null), 1));}
		if(YTCape.ownsCosmetic()) {cosButtons.add(new CosmeticComponent(mouseX, mouseY, 575, 75, new YTCape(null), 1));}
	}
	@Override
	public void mouseClicked(int mouseX, int mouseY, int button) {
		for(CosmeticComponent cos : cosButtons) {
			cos.onClick(mouseX, mouseY);
		}
	}
}
