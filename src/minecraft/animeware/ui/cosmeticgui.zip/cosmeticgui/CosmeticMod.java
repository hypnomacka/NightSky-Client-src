package animeware.ui.cosmeticgui;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.google.common.collect.Lists;

import animeware.Animeware;
import animeware.hud.DraggableComponent;
import animeware.hud.ScreenPosition;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiLabel;

public class CosmeticMod {
	
	public Minecraft mc = Minecraft.getMinecraft();
	public FontRenderer fr = mc.fontRendererObj;
	protected List<GuiButton> buttonList = Lists.<GuiButton>newArrayList();
	protected List<GuiLabel> labelList = Lists.<GuiLabel>newArrayList();
	
	
	public String name;
	public boolean enabled;
	public DraggableComponent drag;
	
	public int x, y;
	
	public CosmeticMod(String name, int x, int y) {
		this.name = name;		
		
		try {
			this.x = (int) Animeware.INSTANCE.config.config.get(name.toLowerCase() + " x");
			this.y = (int) Animeware.INSTANCE.config.config.get(name.toLowerCase() + " y");
			this.setEnabled((boolean) Animeware.INSTANCE.config.config.get(name.toLowerCase() + " enbled"));			
		} catch(NullPointerException e) {
			this.x = x;
			this.y = y;
			this.enabled = false;
		}
		
		drag = new DraggableComponent(x, y, getWidth(), getHeight(), new Color(0, 0, 0, 0).getRGB());
		
	}
	
	
	public int getWidth() {
		return 50;

	}
	
	public int getHeight() {
		return 50;

	}
	
	public void draw() {

	}
	
	public void renderDummy(int mouseX, int mouseY) {
		drag.draw(mouseX, mouseY);

	}
	
	public int getX() {
		return drag.getxPosition();
	}
	
	public int getY() {
		return drag.getyPosition();
	}
	
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	
	public void toggle() {
		this.setEnabled(!enabled);

	}
	
	public boolean isEnabled() {
		return enabled;
	}


	public void onDisable() {
		Animeware.INSTANCE.eventManager.unregister(this);

	}
	public void drawScreen(int mouseX, int mouseY, float partialTicks)
    {
        for (int i = 0; i < this.buttonList.size(); ++i)
        {
            ((GuiButton)this.buttonList.get(i)).drawButton(this.mc, mouseX, mouseY);
        }

        for (int j = 0; j < this.labelList.size(); ++j)
        {
            ((GuiLabel)this.labelList.get(j)).drawLabel(this.mc, mouseX, mouseY);
        }
    }
	

	
	}



	

	

