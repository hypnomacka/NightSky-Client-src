package animeware.ui.cosmeticgui;

import java.util.ArrayList;

import animeware.cosmetic.Cosmetic;
import animeware.cosmetic.impl.Cape;
import animeware.cosmetic.impl.Halo;
import animeware.cosmetic.impl.OwnerCape;
import animeware.ui.cosmeticgui.comp.CosmeticComponent;

public class CosmeticManager {
	
	public static ArrayList<Cosmetic> cosmetics = new ArrayList<Cosmetic>();
	
	public Cape cape;
	public OwnerCape ownerCape;
	
	public void addCosmetics() {
		cosmetics = new ArrayList<>();
		
		cape = new Cape(null);
		cosmetics.add(cape);
		
		ownerCape = new OwnerCape(null);
		cosmetics.add(ownerCape);
		
	}
	public static ArrayList<Cosmetic> getCosmetics() {
		return cosmetics;
	}
	/*public void renderCosmetics(int mouseX, int mouseY, int button) {
		for(CosmeticComponent cos : cosmetics) {
			cos.onClick(mouseX, mouseY);
		}
	}*/

}
