package animeware.ui.cosmeticgui;

import java.io.IOException;
import java.util.ArrayList;

import animeware.Animeware;
import animeware.cosmetic.impl.Cape;
import animeware.ui.comp.ModButton;
import animeware.ui.cosmeticgui.comp.CosmeticComponent;
import animeware.ui.cosmeticgui.comp.CosmeticModButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.ResourceLocation;

public class CosmeticGui extends GuiScreen {
	
	ArrayList<CosmeticComponent> cosButtons = new ArrayList<CosmeticComponent>();
	
	@Override
	public boolean doesGuiPauseGame() {
		return false;
	}
	
	/*@Override
	public void initGui(int mouseX, int mouseY, float partialTicks) {
		super.initGui();
		//this.buttonList.add(new ClickGuiRect(69, 250, height / 2 - 170, ""));
		if(Cape.ownsCosmetic()) {cosButtons.add(new CosmeticComponent(mouseX, mouseY, 75, 75, new Cape(null), 1));}		
	}*/
	
	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
		ScaledResolution sr = new ScaledResolution(mc);
		super.drawScreen(mouseX, mouseY, partialTicks);
		
		//Gui.drawRect(254, 90, sr.getScaledWidth() - 277, sr.getScaledHeight() - 105, new Color(0, 0, 0, 170).getRGB());
		//Gui.drawRect(251, 90, sr.getScaledWidth() - 274, sr.getScaledHeight() - 434, new Color(0, 0, 0, 170).getRGB());
		//Gui.drawRect(251, 419, sr.getScaledWidth() - 274, sr.getScaledHeight() - 108, new Color(0, 0, 0, 170).getRGB());
		mc.getTextureManager().bindTexture(new ResourceLocation ("Animeware/clickgui/bg1.png"));
		this.drawModalRectWithCustomSizedTexture(0, 0, 0, 0, this.width, this.height, this.width, this.height);
		super.drawScreen(mouseX, mouseY, partialTicks);
		
		if(Cape.ownsCosmetic()) {cosButtons.add(new CosmeticComponent(mouseX, mouseY, 75, 75, new Cape(null), 1));}
				
	}
	
	@Override
	protected void mouseClicked(int mouseX, int mouseY, int button) {
		for(CosmeticComponent cos : cosButtons) {
			cos.onClick(mouseX, mouseY);
		}
	}

}


