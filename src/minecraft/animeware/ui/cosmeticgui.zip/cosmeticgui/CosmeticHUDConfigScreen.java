package animeware.ui.cosmeticgui;

import java.io.IOException;

import animeware.Animeware;
import animeware.cosmetic.Cosmetic;
import animeware.hud.mod.HudMod;
import animeware.mainmenu.components.ClickGuiButton1;
import animeware.ui.ClickGUI;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

public class CosmeticHUDConfigScreen extends GuiScreen {
	
	@Override
	public void initGui() {
		super.initGui();
		this.buttonList.add(new ClickGuiButton1(69, this.width / 2 - 50, this.height / 2 - 10, 100, 20, "Open Cosmetics"));
	}
		
	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
		super.drawDefaultBackground();
		
		/*for(Cosmetic cos : Animeware.INSTANCE.cManager.cosmetics) {
			if(cos.isEnabled()) {
			cos.renderDummy(mouseX, mouseY);
			}
		}*/
		
		super.drawScreen(mouseX, mouseY, partialTicks);
	}
	
	@Override
	protected void actionPerformed(GuiButton button) throws IOException {
		super.actionPerformed(button);
		switch(button.id) {
		case 69:
			mc.displayGuiScreen(new CosmeticGui());
		}
	}

}
